<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 354916799,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 354916800,
		'to' => 370724399,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 370724400,
		'to' => 386452799,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 386452800,
		'to' => 402260399,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 402260400,
		'to' => 417988799,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 417988800,
		'to' => 433796399,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 433796400,
		'to' => 449611199,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 449611200,
		'to' => 465343199,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 465343200,
		'to' => 481067999,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 481068000,
		'to' => 496792799,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 496792800,
		'to' => 512517599,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 512517600,
		'to' => 528242399,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 528242400,
		'to' => 543967199,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 543967200,
		'to' => 559691999,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 559692000,
		'to' => 575416799,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 575416800,
		'to' => 591141599,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 591141600,
		'to' => 606866399,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 606866400,
		'to' => 622594799,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 622594800,
		'to' => 638319599,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 638319600,
		'to' => 654649199,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 654649200,
		'to' => 670373999,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 670374000,
		'to' => 701819999,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 701820000,
		'to' => 717533999,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 717534000,
		'to' => 733273199,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 733273200,
		'to' => 748997999,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 748998000,
		'to' => 764722799,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 764722800,
		'to' => 780447599,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 780447600,
		'to' => 796172399,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 796172400,
		'to' => 811897199,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 811897200,
		'to' => 828226799,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 828226800,
		'to' => 846370799,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 846370800,
		'to' => 859676399,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 859676400,
		'to' => 877820399,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 877820400,
		'to' => 891125999,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 891126000,
		'to' => 909269999,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 909270000,
		'to' => 922575599,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 922575600,
		'to' => 941324399,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 941324400,
		'to' => 954025199,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 954025200,
		'to' => 972773999,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 972774000,
		'to' => 985474799,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 985474800,
		'to' => 1004223599,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1004223600,
		'to' => 1017529199,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1017529200,
		'to' => 1035673199,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1035673200,
		'to' => 1048978799,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1048978800,
		'to' => 1067122799,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1067122800,
		'to' => 1080428399,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1080428400,
		'to' => 1099177199,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1099177200,
		'to' => 1111877999,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1111878000,
		'to' => 1130626799,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1130626800,
		'to' => 1143327599,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1143327600,
		'to' => 1162076399,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1162076400,
		'to' => 1174777199,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1174777200,
		'to' => 1193525999,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1193526000,
		'to' => 1206831599,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1206831600,
		'to' => 1224975599,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1224975600,
		'to' => 1238281199,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1238281200,
		'to' => 1256425199,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1256425200,
		'to' => 1269730799,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1269730800,
		'to' => 1288479599,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1288479600,
		'to' => 1301180399,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1301180400,
		'to' => 1319929199,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1319929200,
		'to' => 1332629999,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1332630000,
		'to' => 1351378799,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1351378800,
		'to' => 1364684399,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1364684400,
		'to' => 1382828399,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1382828400,
		'to' => 1396133999,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1396134000,
		'to' => 1414277999,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1414278000,
		'to' => 1427583599,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1427583600,
		'to' => 1445727599,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1445727600,
		'to' => 1459033199,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1459033200,
		'to' => 1477781999,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1477782000,
		'to' => 1490482799,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1490482800,
		'to' => 1509231599,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1509231600,
		'to' => 1521932399,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1521932400,
		'to' => 1540681199,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1540681200,
		'to' => 1553986799,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1553986800,
		'to' => 1572130799,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1572130800,
		'to' => 1585436399,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1585436400,
		'to' => 1603580399,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1603580400,
		'to' => 1616885999,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1616886000,
		'to' => 1635634799,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1635634800,
		'to' => 1648335599,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1648335600,
		'to' => 1667084399,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1667084400,
		'to' => 1679785199,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1679785200,
		'to' => 1698533999,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1698534000,
		'to' => 1711839599,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1711839600,
		'to' => 1729983599,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1729983600,
		'to' => 1743289199,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1743289200,
		'to' => 1761433199,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1761433200,
		'to' => 1774738799,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1774738800,
		'to' => 1792882799,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1792882800,
		'to' => 1806188399,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1806188400,
		'to' => 1824937199,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1824937200,
		'to' => 1837637999,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1837638000,
		'to' => 1856386799,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1856386800,
		'to' => 1869087599,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1869087600,
		'to' => 1887836399,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1887836400,
		'to' => 1901141999,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1901142000,
		'to' => 1919285999,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1919286000,
		'to' => 1932591599,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1932591600,
		'to' => 1950735599,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1950735600,
		'to' => 1964041199,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1964041200,
		'to' => 1982789999,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1982790000,
		'to' => 1995490799,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1995490800,
		'to' => 2014239599,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 2014239600,
		'to' => 2026940399,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 2026940400,
		'to' => 2045689199,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 2045689200,
		'to' => 2058389999,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 2058390000,
		'to' => 2077138799,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 2077138800,
		'to' => 2090444399,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 2090444400,
		'to' => 2108588399,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 2108588400,
		'to' => 2121893999,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 2121894000,
		'to' => 2140037999,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 2140038000,
		'to' => 2147483647,
		'offset' => 10800,
		'dst' => false
	)
);
