<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 10533599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 10533600,
		'to' => 23835599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 23835600,
		'to' => 41983199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 41983200,
		'to' => 55285199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 55285200,
		'to' => 74037599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 74037600,
		'to' => 87339599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 87339600,
		'to' => 107909999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 107910000,
		'to' => 121219199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 121219200,
		'to' => 133919999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 133920000,
		'to' => 152675999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 152676000,
		'to' => 165362399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 165362400,
		'to' => 183502799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 183502800,
		'to' => 202427999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 202428000,
		'to' => 215557199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 215557200,
		'to' => 228866399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 228866400,
		'to' => 245797199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 245797200,
		'to' => 260315999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 260316000,
		'to' => 277246799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 277246800,
		'to' => 308779199,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 308779200,
		'to' => 323827199,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 323827200,
		'to' => 340228799,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 340228800,
		'to' => 354671999,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 354672000,
		'to' => 371678399,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 371678400,
		'to' => 386121599,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 386121600,
		'to' => 403127999,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 403128000,
		'to' => 428446799,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 428446800,
		'to' => 433886399,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 433886400,
		'to' => 482792399,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 482792400,
		'to' => 496702799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 496702800,
		'to' => 512524799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 512524800,
		'to' => 528249599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 528249600,
		'to' => 543974399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 543974400,
		'to' => 559699199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 559699200,
		'to' => 575423999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 575424000,
		'to' => 591148799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 591148800,
		'to' => 606873599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 606873600,
		'to' => 622598399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 622598400,
		'to' => 638323199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 638323200,
		'to' => 654652799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 654652800,
		'to' => 670373999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 670374000,
		'to' => 686098799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 686098800,
		'to' => 701823599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 701823600,
		'to' => 717548399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 717548400,
		'to' => 733273199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 733273200,
		'to' => 748997999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 748998000,
		'to' => 764722799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 764722800,
		'to' => 780447599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 780447600,
		'to' => 796172399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 796172400,
		'to' => 811897199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 811897200,
		'to' => 828226799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 828226800,
		'to' => 846370799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 846370800,
		'to' => 859676399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 859676400,
		'to' => 877820399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 877820400,
		'to' => 891125999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 891126000,
		'to' => 909269999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 909270000,
		'to' => 922575599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 922575600,
		'to' => 941324399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 941324400,
		'to' => 954025199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 954025200,
		'to' => 972773999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 972774000,
		'to' => 985474799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 985474800,
		'to' => 1004223599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1004223600,
		'to' => 1017529199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1017529200,
		'to' => 1035673199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1035673200,
		'to' => 1048978799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1048978800,
		'to' => 1067122799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1067122800,
		'to' => 1080428399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1080428400,
		'to' => 1099177199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1099177200,
		'to' => 1111877999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1111878000,
		'to' => 1130626799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1130626800,
		'to' => 1143327599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1143327600,
		'to' => 1162076399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1162076400,
		'to' => 1167602399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1167602400,
		'to' => 1174784399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1174784400,
		'to' => 1193533199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1193533200,
		'to' => 1206838799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1206838800,
		'to' => 1224982799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1224982800,
		'to' => 1238288399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1238288400,
		'to' => 1256432399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1256432400,
		'to' => 1269737999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1269738000,
		'to' => 1288486799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1288486800,
		'to' => 1301273999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1301274000,
		'to' => 1319936399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1319936400,
		'to' => 1332637199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1332637200,
		'to' => 1351385999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1351386000,
		'to' => 1364691599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1364691600,
		'to' => 1382835599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1382835600,
		'to' => 1396141199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1396141200,
		'to' => 1414285199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1414285200,
		'to' => 1427590799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1427590800,
		'to' => 1445734799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1445734800,
		'to' => 1459040399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1459040400,
		'to' => 1477789199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1477789200,
		'to' => 1490489999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1490490000,
		'to' => 1509238799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1509238800,
		'to' => 1521939599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1521939600,
		'to' => 1540688399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1540688400,
		'to' => 1553993999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1553994000,
		'to' => 1572137999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1572138000,
		'to' => 1585443599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1585443600,
		'to' => 1603587599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1603587600,
		'to' => 1616893199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1616893200,
		'to' => 1635641999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1635642000,
		'to' => 1648342799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1648342800,
		'to' => 1667091599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1667091600,
		'to' => 1679792399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1679792400,
		'to' => 1698541199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1698541200,
		'to' => 1711846799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1711846800,
		'to' => 1729990799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1729990800,
		'to' => 1743296399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1743296400,
		'to' => 1761440399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1761440400,
		'to' => 1774745999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1774746000,
		'to' => 1792889999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1792890000,
		'to' => 1806195599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1806195600,
		'to' => 1824944399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1824944400,
		'to' => 1837645199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1837645200,
		'to' => 1856393999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1856394000,
		'to' => 1869094799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1869094800,
		'to' => 1887843599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1887843600,
		'to' => 1901149199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1901149200,
		'to' => 1919293199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1919293200,
		'to' => 1932598799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1932598800,
		'to' => 1950742799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1950742800,
		'to' => 1964048399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1964048400,
		'to' => 1982797199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1982797200,
		'to' => 1995497999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1995498000,
		'to' => 2014246799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 2014246800,
		'to' => 2026947599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 2026947600,
		'to' => 2045696399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 2045696400,
		'to' => 2058397199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 2058397200,
		'to' => 2077145999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 2077146000,
		'to' => 2090451599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 2090451600,
		'to' => 2108595599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 2108595600,
		'to' => 2121901199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 2121901200,
		'to' => 2140045199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 2140045200,
		'to' => 2147483647,
		'offset' => 7200,
		'dst' => false
	)
);
