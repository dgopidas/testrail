<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 354920399,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 354920400,
		'to' => 370727999,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 370728000,
		'to' => 386456399,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 386456400,
		'to' => 402263999,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 402264000,
		'to' => 417992399,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 417992400,
		'to' => 433799999,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 433800000,
		'to' => 449614799,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 449614800,
		'to' => 465346799,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 465346800,
		'to' => 481071599,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 481071600,
		'to' => 496796399,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 496796400,
		'to' => 512521199,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 512521200,
		'to' => 528245999,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 528246000,
		'to' => 543970799,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 543970800,
		'to' => 559695599,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 559695600,
		'to' => 575420399,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 575420400,
		'to' => 591145199,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 591145200,
		'to' => 606869999,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 606870000,
		'to' => 622598399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 622598400,
		'to' => 638323199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 638323200,
		'to' => 654652799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 654652800,
		'to' => 670377599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 670377600,
		'to' => 686102399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 686102400,
		'to' => 701827199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 701827200,
		'to' => 717551999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 717552000,
		'to' => 733276799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 733276800,
		'to' => 749001599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 749001600,
		'to' => 764726399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 764726400,
		'to' => 780451199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 780451200,
		'to' => 796175999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 796176000,
		'to' => 811900799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 811900800,
		'to' => 828230399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 828230400,
		'to' => 846374399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 846374400,
		'to' => 859679999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 859680000,
		'to' => 877823999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 877824000,
		'to' => 891129599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 891129600,
		'to' => 906411599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 906411600,
		'to' => 909277199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 909277200,
		'to' => 922582799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 922582800,
		'to' => 941331599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 941331600,
		'to' => 941407199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 941407200,
		'to' => 1017536399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1017536400,
		'to' => 1035680399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1035680400,
		'to' => 1048985999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1048986000,
		'to' => 1067129999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1067130000,
		'to' => 1080435599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1080435600,
		'to' => 1099184399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1099184400,
		'to' => 1111885199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1111885200,
		'to' => 1130633999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1130634000,
		'to' => 1143334799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1143334800,
		'to' => 1162083599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1162083600,
		'to' => 1174784399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1174784400,
		'to' => 1193533199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1193533200,
		'to' => 1206838799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1206838800,
		'to' => 1224982799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1224982800,
		'to' => 1238288399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1238288400,
		'to' => 1256432399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1256432400,
		'to' => 1269737999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1269738000,
		'to' => 1288486799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1288486800,
		'to' => 1301187599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1301187600,
		'to' => 1319936399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1319936400,
		'to' => 1332637199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1332637200,
		'to' => 1351385999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1351386000,
		'to' => 1364691599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1364691600,
		'to' => 1382835599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1382835600,
		'to' => 1396141199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1396141200,
		'to' => 1414285199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1414285200,
		'to' => 1427590799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1427590800,
		'to' => 1445734799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1445734800,
		'to' => 1459040399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1459040400,
		'to' => 1477789199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1477789200,
		'to' => 1490489999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1490490000,
		'to' => 1509238799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1509238800,
		'to' => 1521939599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1521939600,
		'to' => 1540688399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1540688400,
		'to' => 1553993999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1553994000,
		'to' => 1572137999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1572138000,
		'to' => 1585443599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1585443600,
		'to' => 1603587599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1603587600,
		'to' => 1616893199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1616893200,
		'to' => 1635641999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1635642000,
		'to' => 1648342799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1648342800,
		'to' => 1667091599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1667091600,
		'to' => 1679792399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1679792400,
		'to' => 1698541199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1698541200,
		'to' => 1711846799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1711846800,
		'to' => 1729990799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1729990800,
		'to' => 1743296399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1743296400,
		'to' => 1761440399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1761440400,
		'to' => 1774745999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1774746000,
		'to' => 1792889999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1792890000,
		'to' => 1806195599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1806195600,
		'to' => 1824944399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1824944400,
		'to' => 1837645199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1837645200,
		'to' => 1856393999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1856394000,
		'to' => 1869094799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1869094800,
		'to' => 1887843599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1887843600,
		'to' => 1901149199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1901149200,
		'to' => 1919293199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1919293200,
		'to' => 1932598799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1932598800,
		'to' => 1950742799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1950742800,
		'to' => 1964048399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1964048400,
		'to' => 1982797199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1982797200,
		'to' => 1995497999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1995498000,
		'to' => 2014246799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 2014246800,
		'to' => 2026947599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 2026947600,
		'to' => 2045696399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 2045696400,
		'to' => 2058397199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 2058397200,
		'to' => 2077145999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 2077146000,
		'to' => 2090451599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 2090451600,
		'to' => 2108595599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 2108595600,
		'to' => 2121901199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 2121901200,
		'to' => 2140045199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 2140045200,
		'to' => 2147483647,
		'offset' => 7200,
		'dst' => false
	)
);
