<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 354920399,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 354920400,
		'to' => 370727999,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 370728000,
		'to' => 386456399,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 386456400,
		'to' => 402263999,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 402264000,
		'to' => 417992399,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 417992400,
		'to' => 433799999,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 433800000,
		'to' => 449614799,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 449614800,
		'to' => 465346799,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 465346800,
		'to' => 481071599,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 481071600,
		'to' => 496796399,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 496796400,
		'to' => 512521199,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 512521200,
		'to' => 528245999,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 528246000,
		'to' => 543970799,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 543970800,
		'to' => 559695599,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 559695600,
		'to' => 575420399,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 575420400,
		'to' => 591145199,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 591145200,
		'to' => 606869999,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 606870000,
		'to' => 622594799,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 622594800,
		'to' => 638319599,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 638319600,
		'to' => 654649199,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 654649200,
		'to' => 670373999,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 670374000,
		'to' => 686102399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 686102400,
		'to' => 701816399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 701816400,
		'to' => 717537599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 717537600,
		'to' => 733276799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 733276800,
		'to' => 749001599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 749001600,
		'to' => 764726399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 764726400,
		'to' => 780451199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 780451200,
		'to' => 796175999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 796176000,
		'to' => 811900799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 811900800,
		'to' => 828230399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 828230400,
		'to' => 846374399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 846374400,
		'to' => 859679999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 859680000,
		'to' => 877823999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 877824000,
		'to' => 891129599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 891129600,
		'to' => 909273599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 909273600,
		'to' => 922579199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 922579200,
		'to' => 941327999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 941328000,
		'to' => 954028799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 954028800,
		'to' => 972777599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 972777600,
		'to' => 985478399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 985478400,
		'to' => 1004227199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1004227200,
		'to' => 1017532799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1017532800,
		'to' => 1035676799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1035676800,
		'to' => 1048982399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1048982400,
		'to' => 1067126399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1067126400,
		'to' => 1080431999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1080432000,
		'to' => 1099180799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1099180800,
		'to' => 1111881599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1111881600,
		'to' => 1130630399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1130630400,
		'to' => 1143331199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1143331200,
		'to' => 1162079999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1162080000,
		'to' => 1174780799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1174780800,
		'to' => 1193529599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1193529600,
		'to' => 1206835199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1206835200,
		'to' => 1224979199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1224979200,
		'to' => 1238284799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1238284800,
		'to' => 1256428799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1256428800,
		'to' => 1269734399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1269734400,
		'to' => 1288483199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1288483200,
		'to' => 1301183999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1301184000,
		'to' => 1319932799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1319932800,
		'to' => 1332633599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1332633600,
		'to' => 1351382399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1351382400,
		'to' => 1364687999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1364688000,
		'to' => 1382831999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1382832000,
		'to' => 1396137599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1396137600,
		'to' => 1414281599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1414281600,
		'to' => 1427587199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1427587200,
		'to' => 1445731199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1445731200,
		'to' => 1459036799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1459036800,
		'to' => 1477785599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1477785600,
		'to' => 1490486399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1490486400,
		'to' => 1509235199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1509235200,
		'to' => 1521935999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1521936000,
		'to' => 1540684799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1540684800,
		'to' => 1553990399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1553990400,
		'to' => 1572134399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1572134400,
		'to' => 1585439999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1585440000,
		'to' => 1603583999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1603584000,
		'to' => 1616889599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1616889600,
		'to' => 1635638399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1635638400,
		'to' => 1648339199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1648339200,
		'to' => 1667087999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1667088000,
		'to' => 1679788799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1679788800,
		'to' => 1698537599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1698537600,
		'to' => 1711843199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1711843200,
		'to' => 1729987199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1729987200,
		'to' => 1743292799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1743292800,
		'to' => 1761436799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1761436800,
		'to' => 1774742399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1774742400,
		'to' => 1792886399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1792886400,
		'to' => 1806191999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1806192000,
		'to' => 1824940799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1824940800,
		'to' => 1837641599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1837641600,
		'to' => 1856390399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1856390400,
		'to' => 1869091199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1869091200,
		'to' => 1887839999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1887840000,
		'to' => 1901145599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1901145600,
		'to' => 1919289599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1919289600,
		'to' => 1932595199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1932595200,
		'to' => 1950739199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1950739200,
		'to' => 1964044799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1964044800,
		'to' => 1982793599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1982793600,
		'to' => 1995494399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1995494400,
		'to' => 2014243199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 2014243200,
		'to' => 2026943999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 2026944000,
		'to' => 2045692799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 2045692800,
		'to' => 2058393599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 2058393600,
		'to' => 2077142399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 2077142400,
		'to' => 2090447999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 2090448000,
		'to' => 2108591999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 2108592000,
		'to' => 2121897599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 2121897600,
		'to' => 2140041599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 2140041600,
		'to' => 2147483647,
		'offset' => 7200,
		'dst' => false
	)
);
