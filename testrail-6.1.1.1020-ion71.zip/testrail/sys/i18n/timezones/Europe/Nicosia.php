<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 166571999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 166572000,
		'to' => 182293199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 182293200,
		'to' => 200959199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 200959200,
		'to' => 213829199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 213829200,
		'to' => 228866399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 228866400,
		'to' => 243982799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 243982800,
		'to' => 260315999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 260316000,
		'to' => 276123599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 276123600,
		'to' => 291765599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 291765600,
		'to' => 307486799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 307486800,
		'to' => 323819999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 323820000,
		'to' => 338936399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 338936400,
		'to' => 354664799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 354664800,
		'to' => 370385999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 370386000,
		'to' => 386114399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 386114400,
		'to' => 401835599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 401835600,
		'to' => 417563999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 417564000,
		'to' => 433285199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 433285200,
		'to' => 449013599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 449013600,
		'to' => 465339599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 465339600,
		'to' => 481067999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 481068000,
		'to' => 496789199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 496789200,
		'to' => 512517599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 512517600,
		'to' => 528238799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 528238800,
		'to' => 543967199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 543967200,
		'to' => 559688399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 559688400,
		'to' => 575416799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 575416800,
		'to' => 591137999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 591138000,
		'to' => 606866399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 606866400,
		'to' => 622587599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 622587600,
		'to' => 638315999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 638316000,
		'to' => 654641999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 654642000,
		'to' => 670370399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 670370400,
		'to' => 686091599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 686091600,
		'to' => 701819999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 701820000,
		'to' => 717541199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 717541200,
		'to' => 733269599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 733269600,
		'to' => 748990799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 748990800,
		'to' => 764719199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 764719200,
		'to' => 780440399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 780440400,
		'to' => 796168799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 796168800,
		'to' => 811889999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 811890000,
		'to' => 828223199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 828223200,
		'to' => 843944399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 843944400,
		'to' => 859672799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 859672800,
		'to' => 875393999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 875394000,
		'to' => 891122399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 891122400,
		'to' => 909277199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 909277200,
		'to' => 922582799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 922582800,
		'to' => 941331599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 941331600,
		'to' => 954032399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 954032400,
		'to' => 972781199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 972781200,
		'to' => 985481999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 985482000,
		'to' => 1004230799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1004230800,
		'to' => 1017536399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1017536400,
		'to' => 1035680399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1035680400,
		'to' => 1048985999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1048986000,
		'to' => 1067129999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1067130000,
		'to' => 1080435599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1080435600,
		'to' => 1099184399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1099184400,
		'to' => 1111885199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1111885200,
		'to' => 1130633999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1130634000,
		'to' => 1143334799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1143334800,
		'to' => 1162083599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1162083600,
		'to' => 1174784399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1174784400,
		'to' => 1193533199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1193533200,
		'to' => 1206838799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1206838800,
		'to' => 1224982799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1224982800,
		'to' => 1238288399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1238288400,
		'to' => 1256432399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1256432400,
		'to' => 1269737999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1269738000,
		'to' => 1288486799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1288486800,
		'to' => 1301187599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1301187600,
		'to' => 1319936399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1319936400,
		'to' => 1332637199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1332637200,
		'to' => 1351385999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1351386000,
		'to' => 1364691599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1364691600,
		'to' => 1382835599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1382835600,
		'to' => 1396141199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1396141200,
		'to' => 1414285199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1414285200,
		'to' => 1427590799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1427590800,
		'to' => 1445734799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1445734800,
		'to' => 1459040399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1459040400,
		'to' => 1477789199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1477789200,
		'to' => 1490489999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1490490000,
		'to' => 1509238799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1509238800,
		'to' => 1521939599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1521939600,
		'to' => 1540688399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1540688400,
		'to' => 1553993999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1553994000,
		'to' => 1572137999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1572138000,
		'to' => 1585443599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1585443600,
		'to' => 1603587599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1603587600,
		'to' => 1616893199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1616893200,
		'to' => 1635641999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1635642000,
		'to' => 1648342799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1648342800,
		'to' => 1667091599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1667091600,
		'to' => 1679792399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1679792400,
		'to' => 1698541199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1698541200,
		'to' => 1711846799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1711846800,
		'to' => 1729990799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1729990800,
		'to' => 1743296399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1743296400,
		'to' => 1761440399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1761440400,
		'to' => 1774745999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1774746000,
		'to' => 1792889999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1792890000,
		'to' => 1806195599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1806195600,
		'to' => 1824944399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1824944400,
		'to' => 1837645199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1837645200,
		'to' => 1856393999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1856394000,
		'to' => 1869094799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1869094800,
		'to' => 1887843599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1887843600,
		'to' => 1901149199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1901149200,
		'to' => 1919293199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1919293200,
		'to' => 1932598799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1932598800,
		'to' => 1950742799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1950742800,
		'to' => 1964048399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1964048400,
		'to' => 1982797199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1982797200,
		'to' => 1995497999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1995498000,
		'to' => 2014246799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 2014246800,
		'to' => 2026947599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 2026947600,
		'to' => 2045696399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 2045696400,
		'to' => 2058397199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 2058397200,
		'to' => 2077145999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 2077146000,
		'to' => 2090451599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 2090451600,
		'to' => 2108595599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 2108595600,
		'to' => 2121901199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 2121901200,
		'to' => 2140045199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 2140045200,
		'to' => 2147483647,
		'offset' => 7200,
		'dst' => false
	)
);
