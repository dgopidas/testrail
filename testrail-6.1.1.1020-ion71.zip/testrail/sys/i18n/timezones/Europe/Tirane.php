<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 136853999,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 136854000,
		'to' => 149896799,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 149896800,
		'to' => 168130799,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 168130800,
		'to' => 181432799,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 181432800,
		'to' => 199839599,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 199839600,
		'to' => 213141599,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 213141600,
		'to' => 231893999,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 231894000,
		'to' => 244591199,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 244591200,
		'to' => 263257199,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 263257200,
		'to' => 276040799,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 276040800,
		'to' => 294706799,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 294706800,
		'to' => 307490399,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 307490400,
		'to' => 326156399,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 326156400,
		'to' => 339458399,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 339458400,
		'to' => 357087599,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 357087600,
		'to' => 370389599,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 370389600,
		'to' => 389141999,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 389142000,
		'to' => 402443999,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 402444000,
		'to' => 419468399,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 419468400,
		'to' => 433807199,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 433807200,
		'to' => 449621999,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 449622000,
		'to' => 465353999,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 465354000,
		'to' => 481078799,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 481078800,
		'to' => 496803599,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 496803600,
		'to' => 512528399,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 512528400,
		'to' => 528253199,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 528253200,
		'to' => 543977999,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 543978000,
		'to' => 559702799,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 559702800,
		'to' => 575427599,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 575427600,
		'to' => 591152399,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 591152400,
		'to' => 606877199,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 606877200,
		'to' => 622601999,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 622602000,
		'to' => 638326799,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 638326800,
		'to' => 654656399,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 654656400,
		'to' => 670381199,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 670381200,
		'to' => 686105999,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 686106000,
		'to' => 701830799,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 701830800,
		'to' => 717555599,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 717555600,
		'to' => 733280399,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 733280400,
		'to' => 749005199,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 749005200,
		'to' => 764729999,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 764730000,
		'to' => 780454799,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 780454800,
		'to' => 796179599,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 796179600,
		'to' => 811904399,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 811904400,
		'to' => 828233999,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 828234000,
		'to' => 846377999,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 846378000,
		'to' => 859683599,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 859683600,
		'to' => 877827599,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 877827600,
		'to' => 891133199,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 891133200,
		'to' => 909277199,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 909277200,
		'to' => 922582799,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 922582800,
		'to' => 941331599,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 941331600,
		'to' => 954032399,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 954032400,
		'to' => 972781199,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 972781200,
		'to' => 985481999,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 985482000,
		'to' => 1004230799,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1004230800,
		'to' => 1017536399,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1017536400,
		'to' => 1035680399,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1035680400,
		'to' => 1048985999,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1048986000,
		'to' => 1067129999,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1067130000,
		'to' => 1080435599,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1080435600,
		'to' => 1099184399,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1099184400,
		'to' => 1111885199,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1111885200,
		'to' => 1130633999,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1130634000,
		'to' => 1143334799,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1143334800,
		'to' => 1162083599,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1162083600,
		'to' => 1174784399,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1174784400,
		'to' => 1193533199,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1193533200,
		'to' => 1206838799,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1206838800,
		'to' => 1224982799,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1224982800,
		'to' => 1238288399,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1238288400,
		'to' => 1256432399,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1256432400,
		'to' => 1269737999,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1269738000,
		'to' => 1288486799,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1288486800,
		'to' => 1301187599,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1301187600,
		'to' => 1319936399,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1319936400,
		'to' => 1332637199,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1332637200,
		'to' => 1351385999,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1351386000,
		'to' => 1364691599,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1364691600,
		'to' => 1382835599,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1382835600,
		'to' => 1396141199,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1396141200,
		'to' => 1414285199,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1414285200,
		'to' => 1427590799,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1427590800,
		'to' => 1445734799,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1445734800,
		'to' => 1459040399,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1459040400,
		'to' => 1477789199,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1477789200,
		'to' => 1490489999,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1490490000,
		'to' => 1509238799,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1509238800,
		'to' => 1521939599,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1521939600,
		'to' => 1540688399,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1540688400,
		'to' => 1553993999,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1553994000,
		'to' => 1572137999,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1572138000,
		'to' => 1585443599,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1585443600,
		'to' => 1603587599,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1603587600,
		'to' => 1616893199,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1616893200,
		'to' => 1635641999,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1635642000,
		'to' => 1648342799,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1648342800,
		'to' => 1667091599,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1667091600,
		'to' => 1679792399,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1679792400,
		'to' => 1698541199,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1698541200,
		'to' => 1711846799,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1711846800,
		'to' => 1729990799,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1729990800,
		'to' => 1743296399,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1743296400,
		'to' => 1761440399,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1761440400,
		'to' => 1774745999,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1774746000,
		'to' => 1792889999,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1792890000,
		'to' => 1806195599,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1806195600,
		'to' => 1824944399,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1824944400,
		'to' => 1837645199,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1837645200,
		'to' => 1856393999,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1856394000,
		'to' => 1869094799,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1869094800,
		'to' => 1887843599,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1887843600,
		'to' => 1901149199,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1901149200,
		'to' => 1919293199,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1919293200,
		'to' => 1932598799,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1932598800,
		'to' => 1950742799,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1950742800,
		'to' => 1964048399,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1964048400,
		'to' => 1982797199,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1982797200,
		'to' => 1995497999,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1995498000,
		'to' => 2014246799,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 2014246800,
		'to' => 2026947599,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 2026947600,
		'to' => 2045696399,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 2045696400,
		'to' => 2058397199,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 2058397200,
		'to' => 2077145999,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 2077146000,
		'to' => 2090451599,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 2090451600,
		'to' => 2108595599,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 2108595600,
		'to' => 2121901199,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 2121901200,
		'to' => 2140045199,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 2140045200,
		'to' => 2147483647,
		'offset' => 3600,
		'dst' => false
	)
);
