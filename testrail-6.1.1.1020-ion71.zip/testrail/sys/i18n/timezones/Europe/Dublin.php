<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 57722399,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 57722400,
		'to' => 69818399,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 69818400,
		'to' => 89171999,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 89172000,
		'to' => 101267999,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 101268000,
		'to' => 120621599,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 120621600,
		'to' => 132717599,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 132717600,
		'to' => 152071199,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 152071200,
		'to' => 164167199,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 164167200,
		'to' => 183520799,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 183520800,
		'to' => 196221599,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 196221600,
		'to' => 214970399,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 214970400,
		'to' => 227671199,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 227671200,
		'to' => 246419999,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 246420000,
		'to' => 259120799,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 259120800,
		'to' => 278474399,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 278474400,
		'to' => 290570399,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 290570400,
		'to' => 309923999,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 309924000,
		'to' => 322019999,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 322020000,
		'to' => 341373599,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 341373600,
		'to' => 354675599,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 354675600,
		'to' => 372819599,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 372819600,
		'to' => 386125199,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 386125200,
		'to' => 404269199,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 404269200,
		'to' => 417574799,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 417574800,
		'to' => 435718799,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 435718800,
		'to' => 449024399,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 449024400,
		'to' => 467773199,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 467773200,
		'to' => 481078799,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 481078800,
		'to' => 499222799,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 499222800,
		'to' => 512528399,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 512528400,
		'to' => 530672399,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 530672400,
		'to' => 543977999,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 543978000,
		'to' => 562121999,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 562122000,
		'to' => 575427599,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 575427600,
		'to' => 593571599,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 593571600,
		'to' => 606877199,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 606877200,
		'to' => 625625999,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 625626000,
		'to' => 638326799,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 638326800,
		'to' => 657075599,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 657075600,
		'to' => 670381199,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 670381200,
		'to' => 688525199,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 688525200,
		'to' => 701830799,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 701830800,
		'to' => 719974799,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 719974800,
		'to' => 733280399,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 733280400,
		'to' => 751424399,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 751424400,
		'to' => 764729999,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 764730000,
		'to' => 782873999,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 782874000,
		'to' => 796179599,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 796179600,
		'to' => 814323599,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 814323600,
		'to' => 820454399,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 820454400,
		'to' => 828233999,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 828234000,
		'to' => 846377999,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 846378000,
		'to' => 859683599,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 859683600,
		'to' => 877827599,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 877827600,
		'to' => 891133199,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 891133200,
		'to' => 909277199,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 909277200,
		'to' => 922582799,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 922582800,
		'to' => 941331599,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 941331600,
		'to' => 954032399,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 954032400,
		'to' => 972781199,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 972781200,
		'to' => 985481999,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 985482000,
		'to' => 1004230799,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 1004230800,
		'to' => 1017536399,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 1017536400,
		'to' => 1035680399,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 1035680400,
		'to' => 1048985999,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 1048986000,
		'to' => 1067129999,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 1067130000,
		'to' => 1080435599,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 1080435600,
		'to' => 1099184399,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 1099184400,
		'to' => 1111885199,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 1111885200,
		'to' => 1130633999,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 1130634000,
		'to' => 1143334799,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 1143334800,
		'to' => 1162083599,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 1162083600,
		'to' => 1174784399,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 1174784400,
		'to' => 1193533199,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 1193533200,
		'to' => 1206838799,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 1206838800,
		'to' => 1224982799,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 1224982800,
		'to' => 1238288399,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 1238288400,
		'to' => 1256432399,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 1256432400,
		'to' => 1269737999,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 1269738000,
		'to' => 1288486799,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 1288486800,
		'to' => 1301187599,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 1301187600,
		'to' => 1319936399,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 1319936400,
		'to' => 1332637199,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 1332637200,
		'to' => 1351385999,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 1351386000,
		'to' => 1364691599,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 1364691600,
		'to' => 1382835599,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 1382835600,
		'to' => 1396141199,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 1396141200,
		'to' => 1414285199,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 1414285200,
		'to' => 1427590799,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 1427590800,
		'to' => 1445734799,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 1445734800,
		'to' => 1459040399,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 1459040400,
		'to' => 1477789199,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 1477789200,
		'to' => 1490489999,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 1490490000,
		'to' => 1509238799,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 1509238800,
		'to' => 1521939599,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 1521939600,
		'to' => 1540688399,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 1540688400,
		'to' => 1553993999,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 1553994000,
		'to' => 1572137999,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 1572138000,
		'to' => 1585443599,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 1585443600,
		'to' => 1603587599,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 1603587600,
		'to' => 1616893199,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 1616893200,
		'to' => 1635641999,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 1635642000,
		'to' => 1648342799,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 1648342800,
		'to' => 1667091599,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 1667091600,
		'to' => 1679792399,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 1679792400,
		'to' => 1698541199,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 1698541200,
		'to' => 1711846799,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 1711846800,
		'to' => 1729990799,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 1729990800,
		'to' => 1743296399,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 1743296400,
		'to' => 1761440399,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 1761440400,
		'to' => 1774745999,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 1774746000,
		'to' => 1792889999,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 1792890000,
		'to' => 1806195599,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 1806195600,
		'to' => 1824944399,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 1824944400,
		'to' => 1837645199,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 1837645200,
		'to' => 1856393999,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 1856394000,
		'to' => 1869094799,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 1869094800,
		'to' => 1887843599,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 1887843600,
		'to' => 1901149199,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 1901149200,
		'to' => 1919293199,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 1919293200,
		'to' => 1932598799,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 1932598800,
		'to' => 1950742799,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 1950742800,
		'to' => 1964048399,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 1964048400,
		'to' => 1982797199,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 1982797200,
		'to' => 1995497999,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 1995498000,
		'to' => 2014246799,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 2014246800,
		'to' => 2026947599,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 2026947600,
		'to' => 2045696399,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 2045696400,
		'to' => 2058397199,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 2058397200,
		'to' => 2077145999,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 2077146000,
		'to' => 2090451599,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 2090451600,
		'to' => 2108595599,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 2108595600,
		'to' => 2121901199,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 2121901200,
		'to' => 2140045199,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 2140045200,
		'to' => 2147483647,
		'offset' => 0,
		'dst' => false
	)
);
