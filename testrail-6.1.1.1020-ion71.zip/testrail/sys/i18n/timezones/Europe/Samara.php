<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 354916799,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 354916800,
		'to' => 370724399,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 370724400,
		'to' => 386452799,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 386452800,
		'to' => 402260399,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 402260400,
		'to' => 417988799,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 417988800,
		'to' => 433796399,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 433796400,
		'to' => 449611199,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 449611200,
		'to' => 465343199,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 465343200,
		'to' => 481067999,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 481068000,
		'to' => 496792799,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 496792800,
		'to' => 512517599,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 512517600,
		'to' => 528242399,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 528242400,
		'to' => 543967199,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 543967200,
		'to' => 559691999,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 559692000,
		'to' => 575416799,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 575416800,
		'to' => 591141599,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 591141600,
		'to' => 606866399,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 606866400,
		'to' => 622594799,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 622594800,
		'to' => 638319599,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 638319600,
		'to' => 654649199,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 654649200,
		'to' => 670373999,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 670374000,
		'to' => 686102399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 686102400,
		'to' => 687916799,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 687916800,
		'to' => 701809199,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 701809200,
		'to' => 717530399,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 717530400,
		'to' => 733269599,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 733269600,
		'to' => 748994399,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 748994400,
		'to' => 764719199,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 764719200,
		'to' => 780443999,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 780444000,
		'to' => 796168799,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 796168800,
		'to' => 811893599,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 811893600,
		'to' => 828223199,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 828223200,
		'to' => 846367199,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 846367200,
		'to' => 859672799,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 859672800,
		'to' => 877816799,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 877816800,
		'to' => 891122399,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 891122400,
		'to' => 909266399,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 909266400,
		'to' => 922571999,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 922572000,
		'to' => 941320799,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 941320800,
		'to' => 954021599,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 954021600,
		'to' => 972770399,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 972770400,
		'to' => 985471199,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 985471200,
		'to' => 1004219999,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 1004220000,
		'to' => 1017525599,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 1017525600,
		'to' => 1035669599,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 1035669600,
		'to' => 1048975199,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 1048975200,
		'to' => 1067119199,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 1067119200,
		'to' => 1080424799,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 1080424800,
		'to' => 1099173599,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 1099173600,
		'to' => 1111874399,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 1111874400,
		'to' => 1130623199,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 1130623200,
		'to' => 1143323999,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 1143324000,
		'to' => 1162072799,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 1162072800,
		'to' => 1174773599,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 1174773600,
		'to' => 1193522399,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 1193522400,
		'to' => 1206827999,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 1206828000,
		'to' => 1224971999,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 1224972000,
		'to' => 1238277599,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 1238277600,
		'to' => 1256421599,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 1256421600,
		'to' => 1269727199,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 1269727200,
		'to' => 1288479599,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1288479600,
		'to' => 1301180399,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1301180400,
		'to' => 1319929199,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1319929200,
		'to' => 1332629999,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1332630000,
		'to' => 1351378799,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1351378800,
		'to' => 1364684399,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1364684400,
		'to' => 1382828399,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1382828400,
		'to' => 1396133999,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1396134000,
		'to' => 1414277999,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1414278000,
		'to' => 1427583599,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1427583600,
		'to' => 1445727599,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1445727600,
		'to' => 1459033199,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1459033200,
		'to' => 1477781999,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1477782000,
		'to' => 1490482799,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1490482800,
		'to' => 1509231599,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1509231600,
		'to' => 1521932399,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1521932400,
		'to' => 1540681199,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1540681200,
		'to' => 1553986799,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1553986800,
		'to' => 1572130799,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1572130800,
		'to' => 1585436399,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1585436400,
		'to' => 1603580399,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1603580400,
		'to' => 1616885999,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1616886000,
		'to' => 1635634799,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1635634800,
		'to' => 1648335599,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1648335600,
		'to' => 1667084399,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1667084400,
		'to' => 1679785199,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1679785200,
		'to' => 1698533999,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1698534000,
		'to' => 1711839599,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1711839600,
		'to' => 1729983599,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1729983600,
		'to' => 1743289199,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1743289200,
		'to' => 1761433199,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1761433200,
		'to' => 1774738799,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1774738800,
		'to' => 1792882799,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1792882800,
		'to' => 1806188399,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1806188400,
		'to' => 1824937199,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1824937200,
		'to' => 1837637999,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1837638000,
		'to' => 1856386799,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1856386800,
		'to' => 1869087599,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1869087600,
		'to' => 1887836399,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1887836400,
		'to' => 1901141999,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1901142000,
		'to' => 1919285999,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1919286000,
		'to' => 1932591599,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1932591600,
		'to' => 1950735599,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1950735600,
		'to' => 1964041199,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1964041200,
		'to' => 1982789999,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1982790000,
		'to' => 1995490799,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1995490800,
		'to' => 2014239599,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 2014239600,
		'to' => 2026940399,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 2026940400,
		'to' => 2045689199,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 2045689200,
		'to' => 2058389999,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 2058390000,
		'to' => 2077138799,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 2077138800,
		'to' => 2090444399,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 2090444400,
		'to' => 2108588399,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 2108588400,
		'to' => 2121893999,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 2121894000,
		'to' => 2140037999,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 2140038000,
		'to' => 2147483647,
		'offset' => 10800,
		'dst' => false
	)
);
