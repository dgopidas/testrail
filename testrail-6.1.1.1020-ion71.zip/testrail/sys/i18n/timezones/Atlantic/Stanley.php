<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 420609599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 420609600,
		'to' => 433306799,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 433306800,
		'to' => 452051999,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 452052000,
		'to' => 464151599,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 464151600,
		'to' => 483501599,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 483501600,
		'to' => 495601199,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 495601200,
		'to' => 514349999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 514350000,
		'to' => 527054399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 527054400,
		'to' => 545799599,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 545799600,
		'to' => 558503999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 558504000,
		'to' => 577249199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 577249200,
		'to' => 589953599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 589953600,
		'to' => 608698799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 608698800,
		'to' => 621403199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 621403200,
		'to' => 640753199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 640753200,
		'to' => 652852799,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 652852800,
		'to' => 672202799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 672202800,
		'to' => 684907199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 684907200,
		'to' => 703652399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 703652400,
		'to' => 716356799,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 716356800,
		'to' => 735101999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 735102000,
		'to' => 747806399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 747806400,
		'to' => 766551599,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 766551600,
		'to' => 779255999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 779256000,
		'to' => 798001199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 798001200,
		'to' => 810705599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 810705600,
		'to' => 830055599,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 830055600,
		'to' => 842759999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 842760000,
		'to' => 861505199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 861505200,
		'to' => 874209599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 874209600,
		'to' => 892954799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 892954800,
		'to' => 905659199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 905659200,
		'to' => 924404399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 924404400,
		'to' => 937108799,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 937108800,
		'to' => 955853999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 955854000,
		'to' => 968558399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 968558400,
		'to' => 987310799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 987310800,
		'to' => 999410399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 999410400,
		'to' => 1019365199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1019365200,
		'to' => 1030859999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1030860000,
		'to' => 1050814799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1050814800,
		'to' => 1062914399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1062914400,
		'to' => 1082264399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1082264400,
		'to' => 1094363999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1094364000,
		'to' => 1113713999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1113714000,
		'to' => 1125813599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1125813600,
		'to' => 1145163599,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1145163600,
		'to' => 1157263199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1157263200,
		'to' => 1176613199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1176613200,
		'to' => 1188712799,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1188712800,
		'to' => 1208667599,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1208667600,
		'to' => 1220767199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1220767200,
		'to' => 1240117199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1240117200,
		'to' => 1252216799,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1252216800,
		'to' => 1271566799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1271566800,
		'to' => 1283666399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1283666400,
		'to' => 1334465999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1334466000,
		'to' => 1346565599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1346565600,
		'to' => 1366520399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1366520400,
		'to' => 1378015199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1378015200,
		'to' => 1397969999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1397970000,
		'to' => 1410069599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1410069600,
		'to' => 1429419599,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1429419600,
		'to' => 1441519199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1441519200,
		'to' => 1460869199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1460869200,
		'to' => 1472968799,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1472968800,
		'to' => 1492318799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1492318800,
		'to' => 1504418399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1504418400,
		'to' => 1523768399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1523768400,
		'to' => 1535867999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1535868000,
		'to' => 1555822799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1555822800,
		'to' => 1567317599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1567317600,
		'to' => 1587272399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1587272400,
		'to' => 1599371999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1599372000,
		'to' => 1618721999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1618722000,
		'to' => 1630821599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1630821600,
		'to' => 1650171599,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1650171600,
		'to' => 1662271199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1662271200,
		'to' => 1681621199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1681621200,
		'to' => 1693720799,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1693720800,
		'to' => 1713675599,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1713675600,
		'to' => 1725170399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1725170400,
		'to' => 1745125199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1745125200,
		'to' => 1757224799,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1757224800,
		'to' => 1776574799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1776574800,
		'to' => 1788674399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1788674400,
		'to' => 1808024399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1808024400,
		'to' => 1820123999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1820124000,
		'to' => 1839473999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1839474000,
		'to' => 1851573599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1851573600,
		'to' => 1870923599,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1870923600,
		'to' => 1883023199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1883023200,
		'to' => 1902977999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1902978000,
		'to' => 1914472799,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1914472800,
		'to' => 1934427599,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1934427600,
		'to' => 1946527199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1946527200,
		'to' => 1965877199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1965877200,
		'to' => 1977976799,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1977976800,
		'to' => 1997326799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1997326800,
		'to' => 2009426399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 2009426400,
		'to' => 2028776399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 2028776400,
		'to' => 2040875999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 2040876000,
		'to' => 2060225999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 2060226000,
		'to' => 2072325599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 2072325600,
		'to' => 2092280399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 2092280400,
		'to' => 2104379999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 2104380000,
		'to' => 2123729999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 2123730000,
		'to' => 2135829599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 2135829600,
		'to' => 2147483647,
		'offset' => -10800,
		'dst' => true
	)
);
