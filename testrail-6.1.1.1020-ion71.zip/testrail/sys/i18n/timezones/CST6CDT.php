<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 9964799,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 9964800,
		'to' => 25685999,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 25686000,
		'to' => 41414399,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 41414400,
		'to' => 57740399,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 57740400,
		'to' => 73468799,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 73468800,
		'to' => 89189999,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 89190000,
		'to' => 104918399,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 104918400,
		'to' => 120639599,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 120639600,
		'to' => 126691199,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 126691200,
		'to' => 152089199,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 152089200,
		'to' => 162374399,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 162374400,
		'to' => 183538799,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 183538800,
		'to' => 199267199,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 199267200,
		'to' => 215593199,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 215593200,
		'to' => 230716799,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 230716800,
		'to' => 247042799,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 247042800,
		'to' => 262771199,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 262771200,
		'to' => 278492399,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 278492400,
		'to' => 294220799,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 294220800,
		'to' => 309941999,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 309942000,
		'to' => 325670399,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 325670400,
		'to' => 341391599,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 341391600,
		'to' => 357119999,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 357120000,
		'to' => 372841199,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 372841200,
		'to' => 388569599,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 388569600,
		'to' => 404895599,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 404895600,
		'to' => 420019199,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 420019200,
		'to' => 436345199,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 436345200,
		'to' => 452073599,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 452073600,
		'to' => 467794799,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 467794800,
		'to' => 483523199,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 483523200,
		'to' => 499244399,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 499244400,
		'to' => 514972799,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 514972800,
		'to' => 530693999,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 530694000,
		'to' => 544607999,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 544608000,
		'to' => 562143599,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 562143600,
		'to' => 576057599,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 576057600,
		'to' => 594197999,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 594198000,
		'to' => 607507199,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 607507200,
		'to' => 625647599,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 625647600,
		'to' => 638956799,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 638956800,
		'to' => 657097199,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 657097200,
		'to' => 671011199,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 671011200,
		'to' => 688546799,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 688546800,
		'to' => 702460799,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 702460800,
		'to' => 719996399,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 719996400,
		'to' => 733910399,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 733910400,
		'to' => 752050799,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 752050800,
		'to' => 765359999,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 765360000,
		'to' => 783500399,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 783500400,
		'to' => 796809599,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 796809600,
		'to' => 814949999,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 814950000,
		'to' => 828863999,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 828864000,
		'to' => 846399599,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 846399600,
		'to' => 860313599,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 860313600,
		'to' => 877849199,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 877849200,
		'to' => 891763199,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 891763200,
		'to' => 909298799,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 909298800,
		'to' => 923212799,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 923212800,
		'to' => 941353199,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 941353200,
		'to' => 954662399,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 954662400,
		'to' => 972802799,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 972802800,
		'to' => 986111999,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 986112000,
		'to' => 1004252399,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1004252400,
		'to' => 1018166399,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1018166400,
		'to' => 1035701999,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1035702000,
		'to' => 1049615999,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1049616000,
		'to' => 1067151599,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1067151600,
		'to' => 1081065599,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1081065600,
		'to' => 1099205999,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1099206000,
		'to' => 1112515199,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1112515200,
		'to' => 1130655599,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1130655600,
		'to' => 1143964799,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1143964800,
		'to' => 1162105199,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1162105200,
		'to' => 1173599999,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1173600000,
		'to' => 1194159599,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1194159600,
		'to' => 1205049599,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1205049600,
		'to' => 1225609199,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1225609200,
		'to' => 1236499199,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1236499200,
		'to' => 1257058799,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1257058800,
		'to' => 1268553599,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1268553600,
		'to' => 1289113199,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1289113200,
		'to' => 1300003199,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1300003200,
		'to' => 1320562799,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1320562800,
		'to' => 1331452799,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1331452800,
		'to' => 1352012399,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1352012400,
		'to' => 1362902399,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1362902400,
		'to' => 1383461999,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1383462000,
		'to' => 1394351999,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1394352000,
		'to' => 1414911599,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1414911600,
		'to' => 1425801599,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1425801600,
		'to' => 1446361199,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1446361200,
		'to' => 1457855999,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1457856000,
		'to' => 1478415599,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1478415600,
		'to' => 1489305599,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1489305600,
		'to' => 1509865199,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1509865200,
		'to' => 1520755199,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1520755200,
		'to' => 1541314799,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1541314800,
		'to' => 1552204799,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1552204800,
		'to' => 1572764399,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1572764400,
		'to' => 1583654399,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1583654400,
		'to' => 1604213999,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1604214000,
		'to' => 1615708799,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1615708800,
		'to' => 1636268399,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1636268400,
		'to' => 1647158399,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1647158400,
		'to' => 1667717999,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1667718000,
		'to' => 1678607999,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1678608000,
		'to' => 1699167599,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1699167600,
		'to' => 1710057599,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1710057600,
		'to' => 1730617199,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1730617200,
		'to' => 1741507199,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1741507200,
		'to' => 1762066799,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1762066800,
		'to' => 1772956799,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1772956800,
		'to' => 1793516399,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1793516400,
		'to' => 1805011199,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1805011200,
		'to' => 1825570799,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1825570800,
		'to' => 1836460799,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1836460800,
		'to' => 1857020399,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1857020400,
		'to' => 1867910399,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1867910400,
		'to' => 1888469999,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1888470000,
		'to' => 1899359999,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1899360000,
		'to' => 1919919599,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1919919600,
		'to' => 1930809599,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1930809600,
		'to' => 1951369199,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1951369200,
		'to' => 1962863999,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1962864000,
		'to' => 1983423599,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1983423600,
		'to' => 1994313599,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1994313600,
		'to' => 2014873199,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 2014873200,
		'to' => 2025763199,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 2025763200,
		'to' => 2046322799,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 2046322800,
		'to' => 2057212799,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 2057212800,
		'to' => 2077772399,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 2077772400,
		'to' => 2088662399,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 2088662400,
		'to' => 2109221999,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 2109222000,
		'to' => 2120111999,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 2120112000,
		'to' => 2140671599,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 2140671600,
		'to' => 2147483647,
		'offset' => -21600,
		'dst' => false
	)
);
