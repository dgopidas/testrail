<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 9968399,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 9968400,
		'to' => 25689599,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 25689600,
		'to' => 41417999,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 41418000,
		'to' => 57743999,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 57744000,
		'to' => 73472399,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 73472400,
		'to' => 89193599,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 89193600,
		'to' => 104921999,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 104922000,
		'to' => 120643199,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 120643200,
		'to' => 126694799,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 126694800,
		'to' => 152092799,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 152092800,
		'to' => 162377999,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 162378000,
		'to' => 183542399,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 183542400,
		'to' => 199270799,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 199270800,
		'to' => 215596799,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 215596800,
		'to' => 230720399,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 230720400,
		'to' => 247046399,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 247046400,
		'to' => 262774799,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 262774800,
		'to' => 278495999,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 278496000,
		'to' => 294224399,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 294224400,
		'to' => 309945599,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 309945600,
		'to' => 325673999,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 325674000,
		'to' => 341395199,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 341395200,
		'to' => 357123599,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 357123600,
		'to' => 372844799,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 372844800,
		'to' => 388573199,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 388573200,
		'to' => 404899199,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 404899200,
		'to' => 420022799,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 420022800,
		'to' => 436348799,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 436348800,
		'to' => 452077199,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 452077200,
		'to' => 467798399,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 467798400,
		'to' => 483526799,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 483526800,
		'to' => 499247999,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 499248000,
		'to' => 514976399,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 514976400,
		'to' => 530697599,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 530697600,
		'to' => 544611599,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 544611600,
		'to' => 562147199,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 562147200,
		'to' => 576061199,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 576061200,
		'to' => 594201599,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 594201600,
		'to' => 607510799,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 607510800,
		'to' => 625651199,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 625651200,
		'to' => 638960399,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 638960400,
		'to' => 657100799,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 657100800,
		'to' => 671014799,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 671014800,
		'to' => 688550399,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 688550400,
		'to' => 702464399,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 702464400,
		'to' => 719999999,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 720000000,
		'to' => 733913999,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 733914000,
		'to' => 752054399,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 752054400,
		'to' => 765363599,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 765363600,
		'to' => 783503999,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 783504000,
		'to' => 796813199,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 796813200,
		'to' => 814953599,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 814953600,
		'to' => 828867599,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 828867600,
		'to' => 846403199,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 846403200,
		'to' => 860317199,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 860317200,
		'to' => 877852799,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 877852800,
		'to' => 891766799,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 891766800,
		'to' => 909302399,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 909302400,
		'to' => 923216399,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 923216400,
		'to' => 941356799,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 941356800,
		'to' => 954665999,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 954666000,
		'to' => 972806399,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 972806400,
		'to' => 986115599,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 986115600,
		'to' => 1004255999,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1004256000,
		'to' => 1018169999,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1018170000,
		'to' => 1035705599,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1035705600,
		'to' => 1049619599,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1049619600,
		'to' => 1067155199,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1067155200,
		'to' => 1081069199,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1081069200,
		'to' => 1099209599,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1099209600,
		'to' => 1112518799,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1112518800,
		'to' => 1130659199,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1130659200,
		'to' => 1143968399,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1143968400,
		'to' => 1162108799,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1162108800,
		'to' => 1173603599,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1173603600,
		'to' => 1194163199,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1194163200,
		'to' => 1205053199,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1205053200,
		'to' => 1225612799,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1225612800,
		'to' => 1236502799,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1236502800,
		'to' => 1257062399,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1257062400,
		'to' => 1268557199,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1268557200,
		'to' => 1289116799,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1289116800,
		'to' => 1300006799,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1300006800,
		'to' => 1320566399,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1320566400,
		'to' => 1331456399,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1331456400,
		'to' => 1352015999,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1352016000,
		'to' => 1362905999,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1362906000,
		'to' => 1383465599,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1383465600,
		'to' => 1394355599,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1394355600,
		'to' => 1414915199,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1414915200,
		'to' => 1425805199,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1425805200,
		'to' => 1446364799,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1446364800,
		'to' => 1457859599,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1457859600,
		'to' => 1478419199,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1478419200,
		'to' => 1489309199,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1489309200,
		'to' => 1509868799,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1509868800,
		'to' => 1520758799,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1520758800,
		'to' => 1541318399,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1541318400,
		'to' => 1552208399,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1552208400,
		'to' => 1572767999,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1572768000,
		'to' => 1583657999,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1583658000,
		'to' => 1604217599,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1604217600,
		'to' => 1615712399,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1615712400,
		'to' => 1636271999,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1636272000,
		'to' => 1647161999,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1647162000,
		'to' => 1667721599,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1667721600,
		'to' => 1678611599,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1678611600,
		'to' => 1699171199,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1699171200,
		'to' => 1710061199,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1710061200,
		'to' => 1730620799,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1730620800,
		'to' => 1741510799,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1741510800,
		'to' => 1762070399,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1762070400,
		'to' => 1772960399,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1772960400,
		'to' => 1793519999,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1793520000,
		'to' => 1805014799,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1805014800,
		'to' => 1825574399,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1825574400,
		'to' => 1836464399,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1836464400,
		'to' => 1857023999,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1857024000,
		'to' => 1867913999,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1867914000,
		'to' => 1888473599,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1888473600,
		'to' => 1899363599,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1899363600,
		'to' => 1919923199,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1919923200,
		'to' => 1930813199,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1930813200,
		'to' => 1951372799,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1951372800,
		'to' => 1962867599,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1962867600,
		'to' => 1983427199,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1983427200,
		'to' => 1994317199,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1994317200,
		'to' => 2014876799,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 2014876800,
		'to' => 2025766799,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 2025766800,
		'to' => 2046326399,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 2046326400,
		'to' => 2057216399,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 2057216400,
		'to' => 2077775999,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 2077776000,
		'to' => 2088665999,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 2088666000,
		'to' => 2109225599,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 2109225600,
		'to' => 2120115599,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 2120115600,
		'to' => 2140675199,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 2140675200,
		'to' => 2147483647,
		'offset' => -25200,
		'dst' => false
	)
);
