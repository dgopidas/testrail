<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 252435599,
		'offset' => 25200,
		'dst' => false
	),
	array(
		'from' => 252435600,
		'to' => 417974399,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 417974400,
		'to' => 433781999,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 433782000,
		'to' => 449596799,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 449596800,
		'to' => 465317999,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 465318000,
		'to' => 481046399,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 481046400,
		'to' => 496767599,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 496767600,
		'to' => 512495999,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 512496000,
		'to' => 528217199,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 528217200,
		'to' => 543945599,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 543945600,
		'to' => 559666799,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 559666800,
		'to' => 575395199,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 575395200,
		'to' => 591116399,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 591116400,
		'to' => 606844799,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 606844800,
		'to' => 622565999,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 622566000,
		'to' => 638294399,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 638294400,
		'to' => 654620399,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 654620400,
		'to' => 670348799,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 670348800,
		'to' => 686069999,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 686070000,
		'to' => 701798399,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 701798400,
		'to' => 717519599,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 717519600,
		'to' => 733247999,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 733248000,
		'to' => 748969199,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 748969200,
		'to' => 764697599,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 764697600,
		'to' => 780418799,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 780418800,
		'to' => 796147199,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 796147200,
		'to' => 811868399,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 811868400,
		'to' => 828201599,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 828201600,
		'to' => 843922799,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 843922800,
		'to' => 859651199,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 859651200,
		'to' => 875372399,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 875372400,
		'to' => 891100799,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 891100800,
		'to' => 906821999,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 906822000,
		'to' => 988394399,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 988394400,
		'to' => 1001696399,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 1001696400,
		'to' => 1017424799,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 1017424800,
		'to' => 1033145999,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 1033146000,
		'to' => 1048874399,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 1048874400,
		'to' => 1064595599,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 1064595600,
		'to' => 1080323999,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 1080324000,
		'to' => 1096045199,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 1096045200,
		'to' => 1111773599,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 1111773600,
		'to' => 1127494799,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 1127494800,
		'to' => 1143223199,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 1143223200,
		'to' => 1159549199,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 1159549200,
		'to' => 2147483647,
		'offset' => 28800,
		'dst' => false
	)
);
