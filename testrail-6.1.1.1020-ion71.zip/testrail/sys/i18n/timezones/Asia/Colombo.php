<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 832962599,
		'offset' => 19800,
		'dst' => false
	),
	array(
		'from' => 832962600,
		'to' => 846266399,
		'offset' => 23400,
		'dst' => false
	),
	array(
		'from' => 846266400,
		'to' => 1145039399,
		'offset' => 21600,
		'dst' => false
	),
	array(
		'from' => 1145039400,
		'to' => 2147483647,
		'offset' => 19800,
		'dst' => false
	)
);
