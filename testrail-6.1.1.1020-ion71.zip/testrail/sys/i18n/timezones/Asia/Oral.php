<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 354913199,
		'offset' => 18000,
		'dst' => false
	),
	array(
		'from' => 354913200,
		'to' => 370720799,
		'offset' => 21600,
		'dst' => true
	),
	array(
		'from' => 370720800,
		'to' => 386445599,
		'offset' => 21600,
		'dst' => false
	),
	array(
		'from' => 386445600,
		'to' => 402256799,
		'offset' => 21600,
		'dst' => true
	),
	array(
		'from' => 402256800,
		'to' => 417985199,
		'offset' => 18000,
		'dst' => false
	),
	array(
		'from' => 417985200,
		'to' => 433792799,
		'offset' => 21600,
		'dst' => true
	),
	array(
		'from' => 433792800,
		'to' => 449607599,
		'offset' => 18000,
		'dst' => false
	),
	array(
		'from' => 449607600,
		'to' => 465339599,
		'offset' => 21600,
		'dst' => true
	),
	array(
		'from' => 465339600,
		'to' => 481064399,
		'offset' => 18000,
		'dst' => false
	),
	array(
		'from' => 481064400,
		'to' => 496789199,
		'offset' => 21600,
		'dst' => true
	),
	array(
		'from' => 496789200,
		'to' => 512513999,
		'offset' => 18000,
		'dst' => false
	),
	array(
		'from' => 512514000,
		'to' => 528238799,
		'offset' => 21600,
		'dst' => true
	),
	array(
		'from' => 528238800,
		'to' => 543963599,
		'offset' => 18000,
		'dst' => false
	),
	array(
		'from' => 543963600,
		'to' => 559688399,
		'offset' => 21600,
		'dst' => true
	),
	array(
		'from' => 559688400,
		'to' => 575413199,
		'offset' => 18000,
		'dst' => false
	),
	array(
		'from' => 575413200,
		'to' => 591137999,
		'offset' => 21600,
		'dst' => true
	),
	array(
		'from' => 591138000,
		'to' => 606862799,
		'offset' => 18000,
		'dst' => false
	),
	array(
		'from' => 606862800,
		'to' => 622591199,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 622591200,
		'to' => 638315999,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 638316000,
		'to' => 654645599,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 654645600,
		'to' => 662673599,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 662673600,
		'to' => 692827199,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 692827200,
		'to' => 701809199,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 701809200,
		'to' => 717530399,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 717530400,
		'to' => 733269599,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 733269600,
		'to' => 748994399,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 748994400,
		'to' => 764719199,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 764719200,
		'to' => 780443999,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 780444000,
		'to' => 796168799,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 796168800,
		'to' => 811893599,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 811893600,
		'to' => 828223199,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 828223200,
		'to' => 846367199,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 846367200,
		'to' => 859672799,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 859672800,
		'to' => 877816799,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 877816800,
		'to' => 891122399,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 891122400,
		'to' => 909266399,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 909266400,
		'to' => 922571999,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 922572000,
		'to' => 941320799,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 941320800,
		'to' => 954021599,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 954021600,
		'to' => 972770399,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 972770400,
		'to' => 985471199,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 985471200,
		'to' => 1004219999,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 1004220000,
		'to' => 1017525599,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 1017525600,
		'to' => 1035669599,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 1035669600,
		'to' => 1048975199,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 1048975200,
		'to' => 1067119199,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 1067119200,
		'to' => 1080424799,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 1080424800,
		'to' => 1099173599,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 1099173600,
		'to' => 1110830399,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 1110830400,
		'to' => 2147483647,
		'offset' => 18000,
		'dst' => false
	)
);
