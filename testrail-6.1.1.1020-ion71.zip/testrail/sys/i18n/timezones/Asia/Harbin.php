<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 325956599,
		'offset' => 30600,
		'dst' => false
	),
	array(
		'from' => 325956600,
		'to' => 515519999,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 515520000,
		'to' => 527007599,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 527007600,
		'to' => 545155199,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 545155200,
		'to' => 558457199,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 558457200,
		'to' => 576604799,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 576604800,
		'to' => 589906799,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 589906800,
		'to' => 608659199,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 608659200,
		'to' => 621961199,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 621961200,
		'to' => 640108799,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 640108800,
		'to' => 653410799,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 653410800,
		'to' => 671558399,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 671558400,
		'to' => 684860399,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 684860400,
		'to' => 2147483647,
		'offset' => 28800,
		'dst' => false
	)
);
