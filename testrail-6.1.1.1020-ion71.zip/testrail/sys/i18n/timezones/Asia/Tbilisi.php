<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 354916799,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 354916800,
		'to' => 370724399,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 370724400,
		'to' => 386452799,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 386452800,
		'to' => 402260399,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 402260400,
		'to' => 417988799,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 417988800,
		'to' => 433796399,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 433796400,
		'to' => 449611199,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 449611200,
		'to' => 465343199,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 465343200,
		'to' => 481067999,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 481068000,
		'to' => 496792799,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 496792800,
		'to' => 512517599,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 512517600,
		'to' => 528242399,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 528242400,
		'to' => 543967199,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 543967200,
		'to' => 559691999,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 559692000,
		'to' => 575416799,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 575416800,
		'to' => 591141599,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 591141600,
		'to' => 606866399,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 606866400,
		'to' => 622591199,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 622591200,
		'to' => 638315999,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 638316000,
		'to' => 654645599,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 654645600,
		'to' => 670370399,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 670370400,
		'to' => 671140799,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 671140800,
		'to' => 686098799,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 686098800,
		'to' => 694213199,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 694213200,
		'to' => 701816399,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 701816400,
		'to' => 717537599,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 717537600,
		'to' => 733265999,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 733266000,
		'to' => 748987199,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 748987200,
		'to' => 764715599,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 764715600,
		'to' => 780436799,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 780436800,
		'to' => 796161599,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 796161600,
		'to' => 811882799,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 811882800,
		'to' => 828215999,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 828216000,
		'to' => 859661999,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 859662000,
		'to' => 877805999,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 877806000,
		'to' => 891115199,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 891115200,
		'to' => 909255599,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 909255600,
		'to' => 922564799,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 922564800,
		'to' => 941309999,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 941310000,
		'to' => 954014399,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 954014400,
		'to' => 972759599,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 972759600,
		'to' => 985463999,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 985464000,
		'to' => 1004209199,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 1004209200,
		'to' => 1017518399,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 1017518400,
		'to' => 1035658799,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 1035658800,
		'to' => 1048967999,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 1048968000,
		'to' => 1067108399,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 1067108400,
		'to' => 1080417599,
		'offset' => 14400,
		'dst' => false
	),
	array(
		'from' => 1080417600,
		'to' => 1088276399,
		'offset' => 18000,
		'dst' => true
	),
	array(
		'from' => 1088276400,
		'to' => 1099177199,
		'offset' => 14400,
		'dst' => true
	),
	array(
		'from' => 1099177200,
		'to' => 1111877999,
		'offset' => 10800,
		'dst' => false
	),
	array(
		'from' => 1111878000,
		'to' => 2147483647,
		'offset' => 14400,
		'dst' => false
	)
);
