<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 259343999,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 259344000,
		'to' => 275151599,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 275151600,
		'to' => 2147483647,
		'offset' => 28800,
		'dst' => false
	)
);
