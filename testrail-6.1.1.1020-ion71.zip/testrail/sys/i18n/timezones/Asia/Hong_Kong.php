<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 9314999,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 9315000,
		'to' => 25036199,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 25036200,
		'to' => 40764599,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 40764600,
		'to' => 56485799,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 56485800,
		'to' => 72214199,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 72214200,
		'to' => 88540199,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 88540200,
		'to' => 104268599,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 104268600,
		'to' => 119989799,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 119989800,
		'to' => 126041399,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 126041400,
		'to' => 151439399,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 151439400,
		'to' => 167167799,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 167167800,
		'to' => 182888999,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 182889000,
		'to' => 198617399,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 198617400,
		'to' => 214338599,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 214338600,
		'to' => 295385399,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 295385400,
		'to' => 309292199,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 309292200,
		'to' => 2147483647,
		'offset' => 28800,
		'dst' => false
	)
);
