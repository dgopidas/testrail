<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 354902399,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 354902400,
		'to' => 370709999,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 370710000,
		'to' => 386438399,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 386438400,
		'to' => 402245999,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 402246000,
		'to' => 417974399,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 417974400,
		'to' => 433781999,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 433782000,
		'to' => 449596799,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 449596800,
		'to' => 465328799,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 465328800,
		'to' => 481053599,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 481053600,
		'to' => 496778399,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 496778400,
		'to' => 512503199,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 512503200,
		'to' => 528227999,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 528228000,
		'to' => 543952799,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 543952800,
		'to' => 559677599,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 559677600,
		'to' => 575402399,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 575402400,
		'to' => 591127199,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 591127200,
		'to' => 606851999,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 606852000,
		'to' => 622576799,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 622576800,
		'to' => 638301599,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 638301600,
		'to' => 654631199,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 654631200,
		'to' => 670355999,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 670356000,
		'to' => 686084399,
		'offset' => 28800,
		'dst' => true
	),
	array(
		'from' => 686084400,
		'to' => 695761199,
		'offset' => 25200,
		'dst' => false
	),
	array(
		'from' => 695761200,
		'to' => 701794799,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 701794800,
		'to' => 717515999,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 717516000,
		'to' => 733255199,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 733255200,
		'to' => 748979999,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 748980000,
		'to' => 764704799,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 764704800,
		'to' => 780429599,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 780429600,
		'to' => 796154399,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 796154400,
		'to' => 811879199,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 811879200,
		'to' => 828208799,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 828208800,
		'to' => 846352799,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 846352800,
		'to' => 859658399,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 859658400,
		'to' => 877802399,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 877802400,
		'to' => 891107999,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 891108000,
		'to' => 909251999,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 909252000,
		'to' => 922557599,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 922557600,
		'to' => 941306399,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 941306400,
		'to' => 954007199,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 954007200,
		'to' => 972755999,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 972756000,
		'to' => 985456799,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 985456800,
		'to' => 1004205599,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 1004205600,
		'to' => 1017511199,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 1017511200,
		'to' => 1035655199,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 1035655200,
		'to' => 1048960799,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 1048960800,
		'to' => 1067104799,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 1067104800,
		'to' => 1080410399,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 1080410400,
		'to' => 1099159199,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 1099159200,
		'to' => 1111859999,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 1111860000,
		'to' => 1130608799,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 1130608800,
		'to' => 1143309599,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 1143309600,
		'to' => 1162058399,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 1162058400,
		'to' => 1174759199,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 1174759200,
		'to' => 1193507999,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 1193508000,
		'to' => 1206813599,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 1206813600,
		'to' => 1224957599,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 1224957600,
		'to' => 1238263199,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 1238263200,
		'to' => 1256407199,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 1256407200,
		'to' => 1269712799,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 1269712800,
		'to' => 1288461599,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 1288461600,
		'to' => 1301162399,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 1301162400,
		'to' => 1319911199,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 1319911200,
		'to' => 1332611999,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 1332612000,
		'to' => 1351360799,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 1351360800,
		'to' => 1364666399,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 1364666400,
		'to' => 1382810399,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 1382810400,
		'to' => 1396115999,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 1396116000,
		'to' => 1414259999,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 1414260000,
		'to' => 1427565599,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 1427565600,
		'to' => 1445709599,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 1445709600,
		'to' => 1459015199,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 1459015200,
		'to' => 1477763999,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 1477764000,
		'to' => 1490464799,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 1490464800,
		'to' => 1509213599,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 1509213600,
		'to' => 1521914399,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 1521914400,
		'to' => 1540663199,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 1540663200,
		'to' => 1553968799,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 1553968800,
		'to' => 1572112799,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 1572112800,
		'to' => 1585418399,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 1585418400,
		'to' => 1603562399,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 1603562400,
		'to' => 1616867999,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 1616868000,
		'to' => 1635616799,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 1635616800,
		'to' => 1648317599,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 1648317600,
		'to' => 1667066399,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 1667066400,
		'to' => 1679767199,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 1679767200,
		'to' => 1698515999,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 1698516000,
		'to' => 1711821599,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 1711821600,
		'to' => 1729965599,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 1729965600,
		'to' => 1743271199,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 1743271200,
		'to' => 1761415199,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 1761415200,
		'to' => 1774720799,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 1774720800,
		'to' => 1792864799,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 1792864800,
		'to' => 1806170399,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 1806170400,
		'to' => 1824919199,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 1824919200,
		'to' => 1837619999,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 1837620000,
		'to' => 1856368799,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 1856368800,
		'to' => 1869069599,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 1869069600,
		'to' => 1887818399,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 1887818400,
		'to' => 1901123999,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 1901124000,
		'to' => 1919267999,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 1919268000,
		'to' => 1932573599,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 1932573600,
		'to' => 1950717599,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 1950717600,
		'to' => 1964023199,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 1964023200,
		'to' => 1982771999,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 1982772000,
		'to' => 1995472799,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 1995472800,
		'to' => 2014221599,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 2014221600,
		'to' => 2026922399,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 2026922400,
		'to' => 2045671199,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 2045671200,
		'to' => 2058371999,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 2058372000,
		'to' => 2077120799,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 2077120800,
		'to' => 2090426399,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 2090426400,
		'to' => 2108570399,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 2108570400,
		'to' => 2121875999,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 2121876000,
		'to' => 2140019999,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 2140020000,
		'to' => 2147483647,
		'offset' => 28800,
		'dst' => false
	)
);
