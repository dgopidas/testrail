<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 10364399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 10364400,
		'to' => 23587199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 23587200,
		'to' => 41900399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 41900400,
		'to' => 55123199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 55123200,
		'to' => 73522799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 73522800,
		'to' => 86745599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 86745600,
		'to' => 105058799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 105058800,
		'to' => 118281599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 118281600,
		'to' => 136594799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 136594800,
		'to' => 149817599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 149817600,
		'to' => 168130799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 168130800,
		'to' => 181353599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 181353600,
		'to' => 199753199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 199753200,
		'to' => 212975999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 212976000,
		'to' => 231289199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 231289200,
		'to' => 244511999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 244512000,
		'to' => 262825199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 262825200,
		'to' => 276047999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 276048000,
		'to' => 294361199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 294361200,
		'to' => 307583999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 307584000,
		'to' => 325983599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 325983600,
		'to' => 339206399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 339206400,
		'to' => 357519599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 357519600,
		'to' => 370742399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 370742400,
		'to' => 396399599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 396399600,
		'to' => 402278399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 402278400,
		'to' => 426812399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 426812400,
		'to' => 433814399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 433814400,
		'to' => 452213999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 452214000,
		'to' => 465436799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 465436800,
		'to' => 483749999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 483750000,
		'to' => 496972799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 496972800,
		'to' => 515285999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 515286000,
		'to' => 528508799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 528508800,
		'to' => 546821999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 546822000,
		'to' => 560044799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 560044800,
		'to' => 578444399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 578444400,
		'to' => 591667199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 591667200,
		'to' => 610412399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 610412400,
		'to' => 623203199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 623203200,
		'to' => 641516399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 641516400,
		'to' => 654739199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 654739200,
		'to' => 673052399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 673052400,
		'to' => 686275199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 686275200,
		'to' => 704674799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 704674800,
		'to' => 717897599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 717897600,
		'to' => 736210799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 736210800,
		'to' => 749433599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 749433600,
		'to' => 767746799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 767746800,
		'to' => 780969599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 780969600,
		'to' => 799019999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 799020000,
		'to' => 812321999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 812322000,
		'to' => 830469599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 830469600,
		'to' => 843771599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 843771600,
		'to' => 861919199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 861919200,
		'to' => 875221199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 875221200,
		'to' => 893368799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 893368800,
		'to' => 906670799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 906670800,
		'to' => 925423199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 925423200,
		'to' => 938725199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 938725200,
		'to' => 956872799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 956872800,
		'to' => 970174799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 970174800,
		'to' => 988322399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 988322400,
		'to' => 1001624399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1001624400,
		'to' => 1019771999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1019772000,
		'to' => 1033073999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1033074000,
		'to' => 1051221599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1051221600,
		'to' => 1064523599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1064523600,
		'to' => 1083275999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1083276000,
		'to' => 1096577999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1096578000,
		'to' => 1114725599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1114725600,
		'to' => 1128027599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1128027600,
		'to' => 1146175199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1146175200,
		'to' => 1158872399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1158872400,
		'to' => 1177624799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1177624800,
		'to' => 1189112399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1189112400,
		'to' => 1209074399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1209074400,
		'to' => 1219957199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1219957200,
		'to' => 1240523999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1240524000,
		'to' => 1250801999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1250802000,
		'to' => 1272578399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1272578400,
		'to' => 1281473999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1281474000,
		'to' => 1284069599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1284069600,
		'to' => 1285880399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1285880400,
		'to' => 1304027999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1304028000,
		'to' => 1317329999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1317330000,
		'to' => 1335477599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1335477600,
		'to' => 1348779599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1348779600,
		'to' => 1366927199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1366927200,
		'to' => 1380229199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1380229200,
		'to' => 1398376799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1398376800,
		'to' => 1411678799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1411678800,
		'to' => 1429826399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1429826400,
		'to' => 1443128399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1443128400,
		'to' => 1461880799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1461880800,
		'to' => 1475182799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1475182800,
		'to' => 1493330399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1493330400,
		'to' => 1506632399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1506632400,
		'to' => 1524779999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1524780000,
		'to' => 1538081999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1538082000,
		'to' => 1556229599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1556229600,
		'to' => 1569531599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1569531600,
		'to' => 1587679199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1587679200,
		'to' => 1600981199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1600981200,
		'to' => 1619733599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1619733600,
		'to' => 1633035599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1633035600,
		'to' => 1651183199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1651183200,
		'to' => 1664485199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1664485200,
		'to' => 1682632799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1682632800,
		'to' => 1695934799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1695934800,
		'to' => 1714082399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1714082400,
		'to' => 1727384399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1727384400,
		'to' => 1745531999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1745532000,
		'to' => 1758833999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1758834000,
		'to' => 1776981599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1776981600,
		'to' => 1790283599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1790283600,
		'to' => 1809035999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1809036000,
		'to' => 1822337999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1822338000,
		'to' => 1840485599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1840485600,
		'to' => 1853787599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1853787600,
		'to' => 1871935199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1871935200,
		'to' => 1885237199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1885237200,
		'to' => 1903384799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1903384800,
		'to' => 1916686799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1916686800,
		'to' => 1934834399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1934834400,
		'to' => 1948136399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1948136400,
		'to' => 1966888799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1966888800,
		'to' => 1980190799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 1980190800,
		'to' => 1998338399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 1998338400,
		'to' => 2011640399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 2011640400,
		'to' => 2029787999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 2029788000,
		'to' => 2043089999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 2043090000,
		'to' => 2061237599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 2061237600,
		'to' => 2074539599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 2074539600,
		'to' => 2092687199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 2092687200,
		'to' => 2105989199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 2105989200,
		'to' => 2124136799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 2124136800,
		'to' => 2137438799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 2137438800,
		'to' => 2147483647,
		'offset' => 7200,
		'dst' => false
	)
);
