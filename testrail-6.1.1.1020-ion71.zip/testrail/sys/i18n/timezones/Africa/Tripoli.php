<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 378683999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 378684000,
		'to' => 386463599,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 386463600,
		'to' => 402271199,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 402271200,
		'to' => 417999599,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 417999600,
		'to' => 433807199,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 433807200,
		'to' => 449621999,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 449622000,
		'to' => 465429599,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 465429600,
		'to' => 481589999,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 481590000,
		'to' => 496965599,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 496965600,
		'to' => 512953199,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 512953200,
		'to' => 528674399,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 528674400,
		'to' => 544229999,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 544230000,
		'to' => 560037599,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 560037600,
		'to' => 575852399,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 575852400,
		'to' => 591659999,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 591660000,
		'to' => 607388399,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 607388400,
		'to' => 623195999,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 623196000,
		'to' => 641775599,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 641775600,
		'to' => 844034399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 844034400,
		'to' => 860108399,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 860108400,
		'to' => 875915999,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 875916000,
		'to' => 2147483647,
		'offset' => 7200,
		'dst' => false
	)
);
