<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 231202799,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 231202800,
		'to' => 243903599,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 243903600,
		'to' => 262825199,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 262825200,
		'to' => 276044399,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 276044400,
		'to' => 581122799,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 581122800,
		'to' => 591145199,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 591145200,
		'to' => 606869999,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 606870000,
		'to' => 622594799,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 622594800,
		'to' => 641516399,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 641516400,
		'to' => 654649199,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 654649200,
		'to' => 1114901999,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1114902000,
		'to' => 1128038399,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1128038400,
		'to' => 1143334799,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1143334800,
		'to' => 1162083599,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1162083600,
		'to' => 1174784399,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1174784400,
		'to' => 1193533199,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1193533200,
		'to' => 1206838799,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1206838800,
		'to' => 1224982799,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1224982800,
		'to' => 2147483647,
		'offset' => 3600,
		'dst' => false
	)
);
