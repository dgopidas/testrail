<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 41468399,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 41468400,
		'to' => 54773999,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 54774000,
		'to' => 231724799,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 231724800,
		'to' => 246236399,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 246236400,
		'to' => 259545599,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 259545600,
		'to' => 275273999,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 275274000,
		'to' => 309740399,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 309740400,
		'to' => 325468799,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 325468800,
		'to' => 341801999,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 341802000,
		'to' => 357523199,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 357523200,
		'to' => 2147483647,
		'offset' => 3600,
		'dst' => false
	)
);
