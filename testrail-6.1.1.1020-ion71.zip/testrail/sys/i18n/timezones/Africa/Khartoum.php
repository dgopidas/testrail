<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 10360799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 10360800,
		'to' => 24785999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 24786000,
		'to' => 41810399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 41810400,
		'to' => 56321999,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 56322000,
		'to' => 73432799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 73432800,
		'to' => 87944399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 87944400,
		'to' => 104882399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 104882400,
		'to' => 119480399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 119480400,
		'to' => 136331999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 136332000,
		'to' => 151016399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 151016400,
		'to' => 167781599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 167781600,
		'to' => 182552399,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 182552400,
		'to' => 199231199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 199231200,
		'to' => 214174799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 214174800,
		'to' => 230680799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 230680800,
		'to' => 245710799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 245710800,
		'to' => 262735199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 262735200,
		'to' => 277246799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 277246800,
		'to' => 294184799,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 294184800,
		'to' => 308782799,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 308782800,
		'to' => 325634399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 325634400,
		'to' => 340405199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 340405200,
		'to' => 357083999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 357084000,
		'to' => 371941199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 371941200,
		'to' => 388533599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 388533600,
		'to' => 403477199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 403477200,
		'to' => 419983199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 419983200,
		'to' => 435013199,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 435013200,
		'to' => 452037599,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 452037600,
		'to' => 466635599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 466635600,
		'to' => 483487199,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 483487200,
		'to' => 498171599,
		'offset' => 10800,
		'dst' => true
	),
	array(
		'from' => 498171600,
		'to' => 947930399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 947930400,
		'to' => 2147483647,
		'offset' => 10800,
		'dst' => false
	)
);
