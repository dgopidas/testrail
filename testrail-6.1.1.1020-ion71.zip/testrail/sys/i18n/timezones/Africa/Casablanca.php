<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 141263999,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 141264000,
		'to' => 147221999,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 147222000,
		'to' => 199756799,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 199756800,
		'to' => 207701999,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 207702000,
		'to' => 231292799,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 231292800,
		'to' => 244249199,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 244249200,
		'to' => 265507199,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 265507200,
		'to' => 271033199,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 271033200,
		'to' => 448243199,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 448243200,
		'to' => 504917999,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 504918000,
		'to' => 1212278399,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 1212278400,
		'to' => 1220223599,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 1220223600,
		'to' => 1243814399,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 1243814400,
		'to' => 1250809199,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 1250809200,
		'to' => 1272758399,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 1272758400,
		'to' => 1281221999,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 1281222000,
		'to' => 1301788799,
		'offset' => 0,
		'dst' => false
	),
	array(
		'from' => 1301788800,
		'to' => 1312066799,
		'offset' => 3600,
		'dst' => true
	),
	array(
		'from' => 1312066800,
		'to' => 2147483647,
		'offset' => 0,
		'dst' => false
	)
);
