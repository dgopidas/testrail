<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 637970399,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 637970400,
		'to' => 765323999,
		'offset' => 7200,
		'dst' => false
	),
	array(
		'from' => 765324000,
		'to' => 778640399,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 778640400,
		'to' => 796780799,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 796780800,
		'to' => 810089999,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 810090000,
		'to' => 828835199,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 828835200,
		'to' => 841539599,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 841539600,
		'to' => 860284799,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 860284800,
		'to' => 873593999,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 873594000,
		'to' => 891734399,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 891734400,
		'to' => 905043599,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 905043600,
		'to' => 923183999,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 923184000,
		'to' => 936493199,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 936493200,
		'to' => 954633599,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 954633600,
		'to' => 967942799,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 967942800,
		'to' => 986083199,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 986083200,
		'to' => 999392399,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 999392400,
		'to' => 1018137599,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1018137600,
		'to' => 1030841999,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1030842000,
		'to' => 1049587199,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1049587200,
		'to' => 1062896399,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1062896400,
		'to' => 1081036799,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1081036800,
		'to' => 1094345999,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1094346000,
		'to' => 1112486399,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1112486400,
		'to' => 1125795599,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1125795600,
		'to' => 1143935999,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1143936000,
		'to' => 1157245199,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1157245200,
		'to' => 1175385599,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1175385600,
		'to' => 1188694799,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1188694800,
		'to' => 1207439999,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1207440000,
		'to' => 1220749199,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1220749200,
		'to' => 1238889599,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1238889600,
		'to' => 1252198799,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1252198800,
		'to' => 1270339199,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1270339200,
		'to' => 1283648399,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1283648400,
		'to' => 1301788799,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1301788800,
		'to' => 1315097999,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1315098000,
		'to' => 1333238399,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1333238400,
		'to' => 1346547599,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1346547600,
		'to' => 1365292799,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1365292800,
		'to' => 1377997199,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1377997200,
		'to' => 1396742399,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1396742400,
		'to' => 1410051599,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1410051600,
		'to' => 1428191999,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1428192000,
		'to' => 1441501199,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1441501200,
		'to' => 1459641599,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1459641600,
		'to' => 1472950799,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1472950800,
		'to' => 1491091199,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1491091200,
		'to' => 1504400399,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1504400400,
		'to' => 1522540799,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1522540800,
		'to' => 1535849999,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1535850000,
		'to' => 1554595199,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1554595200,
		'to' => 1567299599,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1567299600,
		'to' => 1586044799,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1586044800,
		'to' => 1599353999,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1599354000,
		'to' => 1617494399,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1617494400,
		'to' => 1630803599,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1630803600,
		'to' => 1648943999,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1648944000,
		'to' => 1662253199,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1662253200,
		'to' => 1680393599,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1680393600,
		'to' => 1693702799,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1693702800,
		'to' => 1712447999,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1712448000,
		'to' => 1725152399,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1725152400,
		'to' => 1743897599,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1743897600,
		'to' => 1757206799,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1757206800,
		'to' => 1775347199,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1775347200,
		'to' => 1788656399,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1788656400,
		'to' => 1806796799,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1806796800,
		'to' => 1820105999,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1820106000,
		'to' => 1838246399,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1838246400,
		'to' => 1851555599,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1851555600,
		'to' => 1869695999,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1869696000,
		'to' => 1883005199,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1883005200,
		'to' => 1901750399,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1901750400,
		'to' => 1914454799,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1914454800,
		'to' => 1933199999,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1933200000,
		'to' => 1946509199,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1946509200,
		'to' => 1964649599,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1964649600,
		'to' => 1977958799,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 1977958800,
		'to' => 1996099199,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 1996099200,
		'to' => 2009408399,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 2009408400,
		'to' => 2027548799,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 2027548800,
		'to' => 2040857999,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 2040858000,
		'to' => 2058998399,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 2058998400,
		'to' => 2072307599,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 2072307600,
		'to' => 2091052799,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 2091052800,
		'to' => 2104361999,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 2104362000,
		'to' => 2122502399,
		'offset' => 7200,
		'dst' => true
	),
	array(
		'from' => 2122502400,
		'to' => 2135811599,
		'offset' => 3600,
		'dst' => false
	),
	array(
		'from' => 2135811600,
		'to' => 2147483647,
		'offset' => 7200,
		'dst' => true
	)
);
