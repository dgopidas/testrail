<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 307622400,
		'to' => 788954399,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 788954400,
		'to' => 2147483647,
		'offset' => 50400,
		'dst' => false
	)
);
