<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 1285498799,
		'offset' => -39600,
		'dst' => false
	),
	array(
		'from' => 1285498800,
		'to' => 1301752799,
		'offset' => -36000,
		'dst' => true
	),
	array(
		'from' => 1301752800,
		'to' => 2147483647,
		'offset' => -39600,
		'dst' => false
	)
);
