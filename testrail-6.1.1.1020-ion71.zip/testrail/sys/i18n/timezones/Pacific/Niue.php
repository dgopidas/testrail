<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 276089399,
		'offset' => -41400,
		'dst' => false
	),
	array(
		'from' => 276089400,
		'to' => 2147483647,
		'offset' => -39600,
		'dst' => false
	)
);
