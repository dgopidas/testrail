<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 152632799,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 152632800,
		'to' => 162309599,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 162309600,
		'to' => 183477599,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 183477600,
		'to' => 194968799,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 194968800,
		'to' => 215531999,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 215532000,
		'to' => 226418399,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 226418400,
		'to' => 246981599,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 246981600,
		'to' => 257867999,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 257868000,
		'to' => 278431199,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 278431200,
		'to' => 289317599,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 289317600,
		'to' => 309880799,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 309880800,
		'to' => 320767199,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 320767200,
		'to' => 341330399,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 341330400,
		'to' => 352216799,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 352216800,
		'to' => 372779999,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 372780000,
		'to' => 384271199,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 384271200,
		'to' => 404834399,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 404834400,
		'to' => 415720799,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 415720800,
		'to' => 436283999,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 436284000,
		'to' => 447170399,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 447170400,
		'to' => 467733599,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 467733600,
		'to' => 478619999,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 478620000,
		'to' => 499183199,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 499183200,
		'to' => 510069599,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 510069600,
		'to' => 530632799,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 530632800,
		'to' => 541519199,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 541519200,
		'to' => 562082399,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 562082400,
		'to' => 573573599,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 573573600,
		'to' => 594136799,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 594136800,
		'to' => 605023199,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 605023200,
		'to' => 623771999,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 623772000,
		'to' => 637682399,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 637682400,
		'to' => 655221599,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 655221600,
		'to' => 669131999,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 669132000,
		'to' => 686671199,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 686671200,
		'to' => 700581599,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 700581600,
		'to' => 718120799,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 718120800,
		'to' => 732635999,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 732636000,
		'to' => 749570399,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 749570400,
		'to' => 764085599,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 764085600,
		'to' => 781019999,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 781020000,
		'to' => 795535199,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 795535200,
		'to' => 812469599,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 812469600,
		'to' => 826984799,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 826984800,
		'to' => 844523999,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 844524000,
		'to' => 858434399,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 858434400,
		'to' => 875973599,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 875973600,
		'to' => 889883999,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 889884000,
		'to' => 907423199,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 907423200,
		'to' => 921938399,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 921938400,
		'to' => 938872799,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 938872800,
		'to' => 953387999,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 953388000,
		'to' => 970322399,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 970322400,
		'to' => 984837599,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 984837600,
		'to' => 1002376799,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 1002376800,
		'to' => 1016287199,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 1016287200,
		'to' => 1033826399,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 1033826400,
		'to' => 1047736799,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 1047736800,
		'to' => 1065275999,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 1065276000,
		'to' => 1079791199,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 1079791200,
		'to' => 1096725599,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 1096725600,
		'to' => 1111240799,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 1111240800,
		'to' => 1128175199,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 1128175200,
		'to' => 1142690399,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 1142690400,
		'to' => 1159624799,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 1159624800,
		'to' => 1174139999,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 1174140000,
		'to' => 1191074399,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 1191074400,
		'to' => 1207403999,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 1207404000,
		'to' => 1222523999,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 1222524000,
		'to' => 1238853599,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 1238853600,
		'to' => 1253973599,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 1253973600,
		'to' => 1270303199,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 1270303200,
		'to' => 1285423199,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 1285423200,
		'to' => 1301752799,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 1301752800,
		'to' => 1316872799,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 1316872800,
		'to' => 1333202399,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 1333202400,
		'to' => 1348927199,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 1348927200,
		'to' => 1365256799,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 1365256800,
		'to' => 1380376799,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 1380376800,
		'to' => 1396706399,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 1396706400,
		'to' => 1411826399,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 1411826400,
		'to' => 1428155999,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 1428156000,
		'to' => 1443275999,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 1443276000,
		'to' => 1459605599,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 1459605600,
		'to' => 1474725599,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 1474725600,
		'to' => 1491055199,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 1491055200,
		'to' => 1506175199,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 1506175200,
		'to' => 1522504799,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 1522504800,
		'to' => 1538229599,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 1538229600,
		'to' => 1554559199,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 1554559200,
		'to' => 1569679199,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 1569679200,
		'to' => 1586008799,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 1586008800,
		'to' => 1601128799,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 1601128800,
		'to' => 1617458399,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 1617458400,
		'to' => 1632578399,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 1632578400,
		'to' => 1648907999,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 1648908000,
		'to' => 1664027999,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 1664028000,
		'to' => 1680357599,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 1680357600,
		'to' => 1695477599,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 1695477600,
		'to' => 1712411999,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 1712412000,
		'to' => 1727531999,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 1727532000,
		'to' => 1743861599,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 1743861600,
		'to' => 1758981599,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 1758981600,
		'to' => 1775311199,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 1775311200,
		'to' => 1790431199,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 1790431200,
		'to' => 1806760799,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 1806760800,
		'to' => 1821880799,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 1821880800,
		'to' => 1838210399,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 1838210400,
		'to' => 1853330399,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 1853330400,
		'to' => 1869659999,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 1869660000,
		'to' => 1885384799,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 1885384800,
		'to' => 1901714399,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 1901714400,
		'to' => 1916834399,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 1916834400,
		'to' => 1933163999,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 1933164000,
		'to' => 1948283999,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 1948284000,
		'to' => 1964613599,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 1964613600,
		'to' => 1979733599,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 1979733600,
		'to' => 1996063199,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 1996063200,
		'to' => 2011183199,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 2011183200,
		'to' => 2027512799,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 2027512800,
		'to' => 2042632799,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 2042632800,
		'to' => 2058962399,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 2058962400,
		'to' => 2074687199,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 2074687200,
		'to' => 2091016799,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 2091016800,
		'to' => 2106136799,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 2106136800,
		'to' => 2122466399,
		'offset' => 49500,
		'dst' => true
	),
	array(
		'from' => 2122466400,
		'to' => 2137586399,
		'offset' => 45900,
		'dst' => false
	),
	array(
		'from' => 2137586400,
		'to' => 2147483647,
		'offset' => 49500,
		'dst' => true
	)
);
