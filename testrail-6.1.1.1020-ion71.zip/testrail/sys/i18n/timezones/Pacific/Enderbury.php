<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 307627200,
		'to' => 788957999,
		'offset' => -39600,
		'dst' => false
	),
	array(
		'from' => 788958000,
		'to' => 2147483647,
		'offset' => 46800,
		'dst' => false
	)
);
