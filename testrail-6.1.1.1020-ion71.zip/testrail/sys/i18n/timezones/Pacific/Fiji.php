<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 909842399,
		'offset' => 43200,
		'dst' => false
	),
	array(
		'from' => 909842400,
		'to' => 920123999,
		'offset' => 46800,
		'dst' => true
	),
	array(
		'from' => 920124000,
		'to' => 941896799,
		'offset' => 43200,
		'dst' => false
	),
	array(
		'from' => 941896800,
		'to' => 951573599,
		'offset' => 46800,
		'dst' => true
	),
	array(
		'from' => 951573600,
		'to' => 1259416799,
		'offset' => 43200,
		'dst' => false
	),
	array(
		'from' => 1259416800,
		'to' => 1269698399,
		'offset' => 46800,
		'dst' => true
	),
	array(
		'from' => 1269698400,
		'to' => 1287842399,
		'offset' => 43200,
		'dst' => false
	),
	array(
		'from' => 1287842400,
		'to' => 1299333599,
		'offset' => 46800,
		'dst' => true
	),
	array(
		'from' => 1299333600,
		'to' => 2147483647,
		'offset' => 43200,
		'dst' => false
	)
);
