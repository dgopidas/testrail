<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 915105599,
		'offset' => 43200,
		'dst' => false
	),
	array(
		'from' => 915105600,
		'to' => 2147483647,
		'offset' => 39600,
		'dst' => false
	)
);
