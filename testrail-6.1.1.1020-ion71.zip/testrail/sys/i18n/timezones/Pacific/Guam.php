<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 977493600,
		'to' => 2147483647,
		'offset' => 36000,
		'dst' => false
	)
);
