<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 939214799,
		'offset' => 46800,
		'dst' => false
	),
	array(
		'from' => 939214800,
		'to' => 953384399,
		'offset' => 50400,
		'dst' => true
	),
	array(
		'from' => 953384400,
		'to' => 973342799,
		'offset' => 46800,
		'dst' => false
	),
	array(
		'from' => 973342800,
		'to' => 980596799,
		'offset' => 50400,
		'dst' => true
	),
	array(
		'from' => 980596800,
		'to' => 1004792399,
		'offset' => 46800,
		'dst' => false
	),
	array(
		'from' => 1004792400,
		'to' => 1012046399,
		'offset' => 50400,
		'dst' => true
	),
	array(
		'from' => 1012046400,
		'to' => 2147483647,
		'offset' => 46800,
		'dst' => false
	)
);
