<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 279714600,
		'to' => 289387799,
		'offset' => -34200,
		'dst' => true
	),
	array(
		'from' => 289387800,
		'to' => 309952799,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 309952800,
		'to' => 320837399,
		'offset' => -34200,
		'dst' => true
	),
	array(
		'from' => 320837400,
		'to' => 341402399,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 341402400,
		'to' => 352286999,
		'offset' => -34200,
		'dst' => true
	),
	array(
		'from' => 352287000,
		'to' => 372851999,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 372852000,
		'to' => 384341399,
		'offset' => -34200,
		'dst' => true
	),
	array(
		'from' => 384341400,
		'to' => 404906399,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 404906400,
		'to' => 415790999,
		'offset' => -34200,
		'dst' => true
	),
	array(
		'from' => 415791000,
		'to' => 436355999,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 436356000,
		'to' => 447240599,
		'offset' => -34200,
		'dst' => true
	),
	array(
		'from' => 447240600,
		'to' => 467805599,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 467805600,
		'to' => 478690199,
		'offset' => -34200,
		'dst' => true
	),
	array(
		'from' => 478690200,
		'to' => 499255199,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 499255200,
		'to' => 510139799,
		'offset' => -34200,
		'dst' => true
	),
	array(
		'from' => 510139800,
		'to' => 530704799,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 530704800,
		'to' => 541589399,
		'offset' => -34200,
		'dst' => true
	),
	array(
		'from' => 541589400,
		'to' => 562154399,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 562154400,
		'to' => 573643799,
		'offset' => -34200,
		'dst' => true
	),
	array(
		'from' => 573643800,
		'to' => 594208799,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 594208800,
		'to' => 605093399,
		'offset' => -34200,
		'dst' => true
	),
	array(
		'from' => 605093400,
		'to' => 625658399,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 625658400,
		'to' => 636542999,
		'offset' => -34200,
		'dst' => true
	),
	array(
		'from' => 636543000,
		'to' => 657107999,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 657108000,
		'to' => 667992599,
		'offset' => -34200,
		'dst' => true
	),
	array(
		'from' => 667992600,
		'to' => 2147483647,
		'offset' => -36000,
		'dst' => false
	)
);
