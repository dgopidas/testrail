<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 433256399,
		'offset' => 39600,
		'dst' => false
	),
	array(
		'from' => 433256400,
		'to' => 448977599,
		'offset' => 43200,
		'dst' => true
	),
	array(
		'from' => 448977600,
		'to' => 467297999,
		'offset' => 39600,
		'dst' => false
	),
	array(
		'from' => 467298000,
		'to' => 480427199,
		'offset' => 43200,
		'dst' => true
	),
	array(
		'from' => 480427200,
		'to' => 496760399,
		'offset' => 39600,
		'dst' => false
	),
	array(
		'from' => 496760400,
		'to' => 511876799,
		'offset' => 43200,
		'dst' => true
	),
	array(
		'from' => 511876800,
		'to' => 528209999,
		'offset' => 39600,
		'dst' => false
	),
	array(
		'from' => 528210000,
		'to' => 543931199,
		'offset' => 43200,
		'dst' => true
	),
	array(
		'from' => 543931200,
		'to' => 559659599,
		'offset' => 39600,
		'dst' => false
	),
	array(
		'from' => 559659600,
		'to' => 575380799,
		'offset' => 43200,
		'dst' => true
	),
	array(
		'from' => 575380800,
		'to' => 591109199,
		'offset' => 39600,
		'dst' => false
	),
	array(
		'from' => 591109200,
		'to' => 606830399,
		'offset' => 43200,
		'dst' => true
	),
	array(
		'from' => 606830400,
		'to' => 622558799,
		'offset' => 39600,
		'dst' => false
	),
	array(
		'from' => 622558800,
		'to' => 638279999,
		'offset' => 43200,
		'dst' => true
	),
	array(
		'from' => 638280000,
		'to' => 654008399,
		'offset' => 39600,
		'dst' => false
	),
	array(
		'from' => 654008400,
		'to' => 669729599,
		'offset' => 43200,
		'dst' => true
	),
	array(
		'from' => 669729600,
		'to' => 686062799,
		'offset' => 39600,
		'dst' => false
	),
	array(
		'from' => 686062800,
		'to' => 696340799,
		'offset' => 43200,
		'dst' => true
	),
	array(
		'from' => 696340800,
		'to' => 719931599,
		'offset' => 39600,
		'dst' => false
	),
	array(
		'from' => 719931600,
		'to' => 727790399,
		'offset' => 43200,
		'dst' => true
	),
	array(
		'from' => 727790400,
		'to' => 2147483647,
		'offset' => 39600,
		'dst' => false
	)
);
