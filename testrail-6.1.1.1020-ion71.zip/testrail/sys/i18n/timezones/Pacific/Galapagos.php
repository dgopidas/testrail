<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 504939599,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 504939600,
		'to' => 2147483647,
		'offset' => -21600,
		'dst' => false
	)
);
