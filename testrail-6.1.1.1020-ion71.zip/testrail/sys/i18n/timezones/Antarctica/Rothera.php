<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 218246400,
		'to' => 2147483647,
		'offset' => -10800,
		'dst' => false
	)
);
