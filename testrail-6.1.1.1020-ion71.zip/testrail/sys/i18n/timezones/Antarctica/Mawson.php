<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 1255809599,
		'offset' => 21600,
		'dst' => false
	),
	array(
		'from' => 1255809600,
		'to' => 2147483647,
		'offset' => 18000,
		'dst' => false
	)
);
