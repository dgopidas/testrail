<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 1255805999,
		'offset' => 25200,
		'dst' => false
	),
	array(
		'from' => 1255806000,
		'to' => 1268251199,
		'offset' => 18000,
		'dst' => false
	),
	array(
		'from' => 1268251200,
		'to' => 2147483647,
		'offset' => 25200,
		'dst' => false
	)
);
