<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 1255802399,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 1255802400,
		'to' => 1267714799,
		'offset' => 39600,
		'dst' => false
	),
	array(
		'from' => 1267714800,
		'to' => 2147483647,
		'offset' => 28800,
		'dst' => false
	)
);
