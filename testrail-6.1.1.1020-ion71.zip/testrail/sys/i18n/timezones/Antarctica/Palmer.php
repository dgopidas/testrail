<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 128141999,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 128142000,
		'to' => 136605599,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 136605600,
		'to' => 389069999,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 389070000,
		'to' => 403070399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 403070400,
		'to' => 416372399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 416372400,
		'to' => 434519999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 434520000,
		'to' => 447821999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 447822000,
		'to' => 466574399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 466574400,
		'to' => 479271599,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 479271600,
		'to' => 498023999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 498024000,
		'to' => 510721199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 510721200,
		'to' => 529473599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 529473600,
		'to' => 545194799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 545194800,
		'to' => 560923199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 560923200,
		'to' => 574225199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 574225200,
		'to' => 591767999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 591768000,
		'to' => 605674799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 605674800,
		'to' => 624427199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 624427200,
		'to' => 637729199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 637729200,
		'to' => 653457599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 653457600,
		'to' => 668573999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 668574000,
		'to' => 687326399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 687326400,
		'to' => 700628399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 700628400,
		'to' => 718775999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 718776000,
		'to' => 732077999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 732078000,
		'to' => 750225599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 750225600,
		'to' => 763527599,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 763527600,
		'to' => 781675199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 781675200,
		'to' => 794977199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 794977200,
		'to' => 813729599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 813729600,
		'to' => 826426799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 826426800,
		'to' => 845179199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 845179200,
		'to' => 859690799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 859690800,
		'to' => 876628799,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 876628800,
		'to' => 889930799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 889930800,
		'to' => 906868799,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 906868800,
		'to' => 923194799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 923194800,
		'to' => 939527999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 939528000,
		'to' => 952829999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 952830000,
		'to' => 971582399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 971582400,
		'to' => 984279599,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 984279600,
		'to' => 1003031999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1003032000,
		'to' => 1015729199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1015729200,
		'to' => 1034481599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1034481600,
		'to' => 1047178799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1047178800,
		'to' => 1065931199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1065931200,
		'to' => 1079233199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1079233200,
		'to' => 1097380799,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1097380800,
		'to' => 1110682799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1110682800,
		'to' => 1128830399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1128830400,
		'to' => 1142132399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1142132400,
		'to' => 1160884799,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1160884800,
		'to' => 1173581999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1173582000,
		'to' => 1192334399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1192334400,
		'to' => 1205031599,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1205031600,
		'to' => 1223783999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1223784000,
		'to' => 1237085999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1237086000,
		'to' => 1255233599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1255233600,
		'to' => 1268535599,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1268535600,
		'to' => 1286683199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1286683200,
		'to' => 1299985199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1299985200,
		'to' => 1318132799,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1318132800,
		'to' => 1331434799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1331434800,
		'to' => 1350187199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1350187200,
		'to' => 1362884399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1362884400,
		'to' => 1381636799,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1381636800,
		'to' => 1394333999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1394334000,
		'to' => 1413086399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1413086400,
		'to' => 1426388399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1426388400,
		'to' => 1444535999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1444536000,
		'to' => 1457837999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1457838000,
		'to' => 1475985599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1475985600,
		'to' => 1489287599,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1489287600,
		'to' => 1508039999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1508040000,
		'to' => 1520737199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1520737200,
		'to' => 1539489599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1539489600,
		'to' => 1552186799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1552186800,
		'to' => 1570939199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1570939200,
		'to' => 1584241199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1584241200,
		'to' => 1602388799,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1602388800,
		'to' => 1615690799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1615690800,
		'to' => 1633838399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1633838400,
		'to' => 1647140399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1647140400,
		'to' => 1665287999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1665288000,
		'to' => 1678589999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1678590000,
		'to' => 1697342399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1697342400,
		'to' => 1710039599,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1710039600,
		'to' => 1728791999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1728792000,
		'to' => 1741489199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1741489200,
		'to' => 1760241599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1760241600,
		'to' => 1773543599,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1773543600,
		'to' => 1791691199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1791691200,
		'to' => 1804993199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1804993200,
		'to' => 1823140799,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1823140800,
		'to' => 1836442799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1836442800,
		'to' => 1855195199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1855195200,
		'to' => 1867892399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1867892400,
		'to' => 1886644799,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1886644800,
		'to' => 1899341999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1899342000,
		'to' => 1918094399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1918094400,
		'to' => 1930791599,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1930791600,
		'to' => 1949543999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1949544000,
		'to' => 1962845999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1962846000,
		'to' => 1980993599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1980993600,
		'to' => 1994295599,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1994295600,
		'to' => 2012443199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 2012443200,
		'to' => 2025745199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 2025745200,
		'to' => 2044497599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 2044497600,
		'to' => 2057194799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 2057194800,
		'to' => 2075947199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 2075947200,
		'to' => 2088644399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 2088644400,
		'to' => 2107396799,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 2107396800,
		'to' => 2120698799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 2120698800,
		'to' => 2138846399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 2138846400,
		'to' => 2147483647,
		'offset' => -10800,
		'dst' => true
	)
);
