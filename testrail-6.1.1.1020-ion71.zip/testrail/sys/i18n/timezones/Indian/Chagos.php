<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 820436399,
		'offset' => 18000,
		'dst' => false
	),
	array(
		'from' => 820436400,
		'to' => 2147483647,
		'offset' => 21600,
		'dst' => false
	)
);
