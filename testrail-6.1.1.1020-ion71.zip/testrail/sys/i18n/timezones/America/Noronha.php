<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 499744799,
		'offset' => -7200,
		'dst' => false
	),
	array(
		'from' => 499744800,
		'to' => 511232399,
		'offset' => -3600,
		'dst' => true
	),
	array(
		'from' => 511232400,
		'to' => 530589599,
		'offset' => -7200,
		'dst' => false
	),
	array(
		'from' => 530589600,
		'to' => 540262799,
		'offset' => -3600,
		'dst' => true
	),
	array(
		'from' => 540262800,
		'to' => 562125599,
		'offset' => -7200,
		'dst' => false
	),
	array(
		'from' => 562125600,
		'to' => 571193999,
		'offset' => -3600,
		'dst' => true
	),
	array(
		'from' => 571194000,
		'to' => 592970399,
		'offset' => -7200,
		'dst' => false
	),
	array(
		'from' => 592970400,
		'to' => 602038799,
		'offset' => -3600,
		'dst' => true
	),
	array(
		'from' => 602038800,
		'to' => 624419999,
		'offset' => -7200,
		'dst' => false
	),
	array(
		'from' => 624420000,
		'to' => 634697999,
		'offset' => -3600,
		'dst' => true
	),
	array(
		'from' => 634698000,
		'to' => 938915999,
		'offset' => -7200,
		'dst' => false
	),
	array(
		'from' => 938916000,
		'to' => 951613199,
		'offset' => -3600,
		'dst' => true
	),
	array(
		'from' => 951613200,
		'to' => 970970399,
		'offset' => -7200,
		'dst' => false
	),
	array(
		'from' => 970970400,
		'to' => 971571599,
		'offset' => -3600,
		'dst' => true
	),
	array(
		'from' => 971571600,
		'to' => 1003024799,
		'offset' => -7200,
		'dst' => false
	),
	array(
		'from' => 1003024800,
		'to' => 1013907599,
		'offset' => -3600,
		'dst' => true
	),
	array(
		'from' => 1013907600,
		'to' => 2147483647,
		'offset' => -7200,
		'dst' => false
	)
);
