<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 499748399,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 499748400,
		'to' => 511235999,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 511236000,
		'to' => 530593199,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 530593200,
		'to' => 540266399,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 540266400,
		'to' => 562129199,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 562129200,
		'to' => 571197599,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 571197600,
		'to' => 592973999,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 592974000,
		'to' => 602042399,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 602042400,
		'to' => 624423599,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 624423600,
		'to' => 634701599,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 634701600,
		'to' => 938919599,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 938919600,
		'to' => 951616799,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 951616800,
		'to' => 970973999,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 970974000,
		'to' => 972179999,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 972180000,
		'to' => 1003028399,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1003028400,
		'to' => 1013911199,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1013911200,
		'to' => 2147483647,
		'offset' => -10800,
		'dst' => false
	)
);
