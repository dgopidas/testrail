<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 326001599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 326001600,
		'to' => 544597199,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 544597200,
		'to' => 562132799,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 562132800,
		'to' => 576046799,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 576046800,
		'to' => 594187199,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 594187200,
		'to' => 607496399,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 607496400,
		'to' => 625636799,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 625636800,
		'to' => 638945999,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 638946000,
		'to' => 657086399,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 657086400,
		'to' => 671000399,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 671000400,
		'to' => 688535999,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 688536000,
		'to' => 702449999,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 702450000,
		'to' => 719985599,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 719985600,
		'to' => 733899599,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 733899600,
		'to' => 752039999,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 752040000,
		'to' => 765349199,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 765349200,
		'to' => 783489599,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 783489600,
		'to' => 796798799,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 796798800,
		'to' => 814939199,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 814939200,
		'to' => 828853199,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 828853200,
		'to' => 846388799,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 846388800,
		'to' => 860302799,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 860302800,
		'to' => 877838399,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 877838400,
		'to' => 891752399,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 891752400,
		'to' => 909287999,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 909288000,
		'to' => 923201999,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 923202000,
		'to' => 941342399,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 941342400,
		'to' => 954651599,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 954651600,
		'to' => 972791999,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 972792000,
		'to' => 986101199,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 986101200,
		'to' => 1004241599,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1004241600,
		'to' => 1018155599,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1018155600,
		'to' => 1035691199,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1035691200,
		'to' => 1049605199,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1049605200,
		'to' => 1067140799,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1067140800,
		'to' => 1081054799,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1081054800,
		'to' => 1099195199,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1099195200,
		'to' => 1112504399,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1112504400,
		'to' => 1130644799,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1130644800,
		'to' => 1143953999,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1143954000,
		'to' => 1162094399,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1162094400,
		'to' => 1173589199,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1173589200,
		'to' => 1194148799,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1194148800,
		'to' => 1205038799,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1205038800,
		'to' => 1225598399,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1225598400,
		'to' => 1236488399,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1236488400,
		'to' => 1257047999,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1257048000,
		'to' => 1268542799,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1268542800,
		'to' => 1289102399,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1289102400,
		'to' => 1299992399,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1299992400,
		'to' => 1320551999,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1320552000,
		'to' => 1331441999,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1331442000,
		'to' => 1352001599,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1352001600,
		'to' => 1362891599,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1362891600,
		'to' => 1383451199,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1383451200,
		'to' => 1394341199,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1394341200,
		'to' => 1414900799,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1414900800,
		'to' => 1425790799,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1425790800,
		'to' => 1446350399,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1446350400,
		'to' => 1457845199,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1457845200,
		'to' => 1478404799,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1478404800,
		'to' => 1489294799,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1489294800,
		'to' => 1509854399,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1509854400,
		'to' => 1520744399,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1520744400,
		'to' => 1541303999,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1541304000,
		'to' => 1552193999,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1552194000,
		'to' => 1572753599,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1572753600,
		'to' => 1583643599,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1583643600,
		'to' => 1604203199,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1604203200,
		'to' => 1615697999,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1615698000,
		'to' => 1636257599,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1636257600,
		'to' => 1647147599,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1647147600,
		'to' => 1667707199,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1667707200,
		'to' => 1678597199,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1678597200,
		'to' => 1699156799,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1699156800,
		'to' => 1710046799,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1710046800,
		'to' => 1730606399,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1730606400,
		'to' => 1741496399,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1741496400,
		'to' => 1762055999,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1762056000,
		'to' => 1772945999,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1772946000,
		'to' => 1793505599,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1793505600,
		'to' => 1805000399,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1805000400,
		'to' => 1825559999,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1825560000,
		'to' => 1836449999,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1836450000,
		'to' => 1857009599,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1857009600,
		'to' => 1867899599,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1867899600,
		'to' => 1888459199,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1888459200,
		'to' => 1899349199,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1899349200,
		'to' => 1919908799,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1919908800,
		'to' => 1930798799,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1930798800,
		'to' => 1951358399,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1951358400,
		'to' => 1962853199,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1962853200,
		'to' => 1983412799,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1983412800,
		'to' => 1994302799,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1994302800,
		'to' => 2014862399,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 2014862400,
		'to' => 2025752399,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 2025752400,
		'to' => 2046311999,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 2046312000,
		'to' => 2057201999,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 2057202000,
		'to' => 2077761599,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 2077761600,
		'to' => 2088651599,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 2088651600,
		'to' => 2109211199,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 2109211200,
		'to' => 2120101199,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 2120101200,
		'to' => 2140660799,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 2140660800,
		'to' => 2147483647,
		'offset' => -10800,
		'dst' => false
	)
);
