<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 73472399,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 73472400,
		'to' => 2147483647,
		'offset' => -21600,
		'dst' => false
	)
);
