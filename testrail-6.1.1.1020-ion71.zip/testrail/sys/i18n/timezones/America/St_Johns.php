<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 9955799,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 9955800,
		'to' => 25676999,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 25677000,
		'to' => 41405399,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 41405400,
		'to' => 57731399,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 57731400,
		'to' => 73459799,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 73459800,
		'to' => 89180999,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 89181000,
		'to' => 104909399,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 104909400,
		'to' => 120630599,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 120630600,
		'to' => 136358999,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 136359000,
		'to' => 152080199,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 152080200,
		'to' => 167808599,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 167808600,
		'to' => 183529799,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 183529800,
		'to' => 199258199,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 199258200,
		'to' => 215584199,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 215584200,
		'to' => 230707799,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 230707800,
		'to' => 247033799,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 247033800,
		'to' => 262762199,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 262762200,
		'to' => 278483399,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 278483400,
		'to' => 294211799,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 294211800,
		'to' => 309932999,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 309933000,
		'to' => 325661399,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 325661400,
		'to' => 341382599,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 341382600,
		'to' => 357110999,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 357111000,
		'to' => 372832199,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 372832200,
		'to' => 388560599,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 388560600,
		'to' => 404886599,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 404886600,
		'to' => 420010199,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 420010200,
		'to' => 436336199,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 436336200,
		'to' => 452064599,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 452064600,
		'to' => 467785799,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 467785800,
		'to' => 483514199,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 483514200,
		'to' => 499235399,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 499235400,
		'to' => 514963799,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 514963800,
		'to' => 530684999,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 530685000,
		'to' => 544591859,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 544591860,
		'to' => 562127459,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 562127460,
		'to' => 576041459,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 576041460,
		'to' => 594178259,
		'offset' => -5400,
		'dst' => true
	),
	array(
		'from' => 594178260,
		'to' => 607491059,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 607491060,
		'to' => 625631459,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 625631460,
		'to' => 638940659,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 638940660,
		'to' => 657081059,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 657081060,
		'to' => 670995059,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 670995060,
		'to' => 688530659,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 688530660,
		'to' => 702444659,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 702444660,
		'to' => 719980259,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 719980260,
		'to' => 733894259,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 733894260,
		'to' => 752034659,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 752034660,
		'to' => 765343859,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 765343860,
		'to' => 783484259,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 783484260,
		'to' => 796793459,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 796793460,
		'to' => 814933859,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 814933860,
		'to' => 828847859,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 828847860,
		'to' => 846383459,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 846383460,
		'to' => 860297459,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 860297460,
		'to' => 877833059,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 877833060,
		'to' => 891747059,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 891747060,
		'to' => 909282659,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 909282660,
		'to' => 923196659,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 923196660,
		'to' => 941337059,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 941337060,
		'to' => 954646259,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 954646260,
		'to' => 972786659,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 972786660,
		'to' => 986095859,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 986095860,
		'to' => 1004236259,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 1004236260,
		'to' => 1018150259,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 1018150260,
		'to' => 1035685859,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 1035685860,
		'to' => 1049599859,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 1049599860,
		'to' => 1067135459,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 1067135460,
		'to' => 1081049459,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 1081049460,
		'to' => 1099189859,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 1099189860,
		'to' => 1112499059,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 1112499060,
		'to' => 1130639459,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 1130639460,
		'to' => 1143948659,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 1143948660,
		'to' => 1162089059,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 1162089060,
		'to' => 1173583859,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 1173583860,
		'to' => 1194143459,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 1194143460,
		'to' => 1205033459,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 1205033460,
		'to' => 1225593059,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 1225593060,
		'to' => 1236483059,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 1236483060,
		'to' => 1257042659,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 1257042660,
		'to' => 1268537459,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 1268537460,
		'to' => 1289097059,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 1289097060,
		'to' => 1299987059,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 1299987060,
		'to' => 1320546659,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 1320546660,
		'to' => 1331436659,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 1331436660,
		'to' => 1351996259,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 1351996260,
		'to' => 1362886259,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 1362886260,
		'to' => 1383445859,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 1383445860,
		'to' => 1394335859,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 1394335860,
		'to' => 1414895459,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 1414895460,
		'to' => 1425785459,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 1425785460,
		'to' => 1446345059,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 1446345060,
		'to' => 1457839859,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 1457839860,
		'to' => 1478399459,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 1478399460,
		'to' => 1489289459,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 1489289460,
		'to' => 1509849059,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 1509849060,
		'to' => 1520739059,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 1520739060,
		'to' => 1541298659,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 1541298660,
		'to' => 1552188659,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 1552188660,
		'to' => 1572748259,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 1572748260,
		'to' => 1583638259,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 1583638260,
		'to' => 1604197859,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 1604197860,
		'to' => 1615692659,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 1615692660,
		'to' => 1636252259,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 1636252260,
		'to' => 1647142259,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 1647142260,
		'to' => 1667701859,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 1667701860,
		'to' => 1678591859,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 1678591860,
		'to' => 1699151459,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 1699151460,
		'to' => 1710041459,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 1710041460,
		'to' => 1730601059,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 1730601060,
		'to' => 1741491059,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 1741491060,
		'to' => 1762050659,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 1762050660,
		'to' => 1772940659,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 1772940660,
		'to' => 1793500259,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 1793500260,
		'to' => 1804995059,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 1804995060,
		'to' => 1825554659,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 1825554660,
		'to' => 1836444659,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 1836444660,
		'to' => 1857004259,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 1857004260,
		'to' => 1867894259,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 1867894260,
		'to' => 1888453859,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 1888453860,
		'to' => 1899343859,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 1899343860,
		'to' => 1919903459,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 1919903460,
		'to' => 1930793459,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 1930793460,
		'to' => 1951353059,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 1951353060,
		'to' => 1962847859,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 1962847860,
		'to' => 1983407459,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 1983407460,
		'to' => 1994297459,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 1994297460,
		'to' => 2014857059,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 2014857060,
		'to' => 2025747059,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 2025747060,
		'to' => 2046306659,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 2046306660,
		'to' => 2057196659,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 2057196660,
		'to' => 2077756259,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 2077756260,
		'to' => 2088646259,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 2088646260,
		'to' => 2109205859,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 2109205860,
		'to' => 2120095859,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 2120095860,
		'to' => 2140655459,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 2140655460,
		'to' => 2147483647,
		'offset' => -12600,
		'dst' => false
	)
);
