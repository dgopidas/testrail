<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 9961199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 9961200,
		'to' => 25682399,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 25682400,
		'to' => 41410799,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 41410800,
		'to' => 57736799,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 57736800,
		'to' => 73465199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 73465200,
		'to' => 89186399,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 89186400,
		'to' => 104914799,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 104914800,
		'to' => 120635999,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 120636000,
		'to' => 126687599,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 126687600,
		'to' => 152085599,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 152085600,
		'to' => 162370799,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 162370800,
		'to' => 183535199,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 183535200,
		'to' => 199263599,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 199263600,
		'to' => 215589599,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 215589600,
		'to' => 230713199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 230713200,
		'to' => 247039199,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 247039200,
		'to' => 262767599,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 262767600,
		'to' => 278488799,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 278488800,
		'to' => 294217199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 294217200,
		'to' => 309938399,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 309938400,
		'to' => 325666799,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 325666800,
		'to' => 341387999,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 341388000,
		'to' => 357116399,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 357116400,
		'to' => 372837599,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 372837600,
		'to' => 388565999,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 388566000,
		'to' => 404891999,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 404892000,
		'to' => 420015599,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 420015600,
		'to' => 436341599,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 436341600,
		'to' => 452069999,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 452070000,
		'to' => 467791199,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 467791200,
		'to' => 483519599,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 483519600,
		'to' => 499240799,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 499240800,
		'to' => 514969199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 514969200,
		'to' => 530690399,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 530690400,
		'to' => 544604399,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 544604400,
		'to' => 562139999,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 562140000,
		'to' => 576053999,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 576054000,
		'to' => 594194399,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 594194400,
		'to' => 607503599,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 607503600,
		'to' => 625643999,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 625644000,
		'to' => 638953199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 638953200,
		'to' => 657093599,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 657093600,
		'to' => 671007599,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 671007600,
		'to' => 688543199,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 688543200,
		'to' => 702457199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 702457200,
		'to' => 719992799,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 719992800,
		'to' => 733906799,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 733906800,
		'to' => 752047199,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 752047200,
		'to' => 765356399,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 765356400,
		'to' => 783496799,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 783496800,
		'to' => 796805999,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 796806000,
		'to' => 814946399,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 814946400,
		'to' => 828860399,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 828860400,
		'to' => 846395999,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 846396000,
		'to' => 860309999,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 860310000,
		'to' => 877845599,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 877845600,
		'to' => 891759599,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 891759600,
		'to' => 909295199,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 909295200,
		'to' => 923209199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 923209200,
		'to' => 941349599,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 941349600,
		'to' => 954658799,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 954658800,
		'to' => 972799199,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 972799200,
		'to' => 986108399,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 986108400,
		'to' => 1004248799,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1004248800,
		'to' => 1018162799,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1018162800,
		'to' => 1035698399,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1035698400,
		'to' => 1049612399,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1049612400,
		'to' => 1067147999,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1067148000,
		'to' => 1081061999,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1081062000,
		'to' => 1099202399,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1099202400,
		'to' => 1112511599,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1112511600,
		'to' => 1130651999,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1130652000,
		'to' => 1143961199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1143961200,
		'to' => 1162101599,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1162101600,
		'to' => 1173596399,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1173596400,
		'to' => 1194155999,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1194156000,
		'to' => 1205045999,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1205046000,
		'to' => 1225605599,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1225605600,
		'to' => 1236495599,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1236495600,
		'to' => 1257055199,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1257055200,
		'to' => 1268549999,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1268550000,
		'to' => 1289109599,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1289109600,
		'to' => 1299999599,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1299999600,
		'to' => 1320559199,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1320559200,
		'to' => 1331449199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1331449200,
		'to' => 1352008799,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1352008800,
		'to' => 1362898799,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1362898800,
		'to' => 1383458399,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1383458400,
		'to' => 1394348399,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1394348400,
		'to' => 1414907999,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1414908000,
		'to' => 1425797999,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1425798000,
		'to' => 1446357599,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1446357600,
		'to' => 1457852399,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1457852400,
		'to' => 1478411999,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1478412000,
		'to' => 1489301999,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1489302000,
		'to' => 1509861599,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1509861600,
		'to' => 1520751599,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1520751600,
		'to' => 1541311199,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1541311200,
		'to' => 1552201199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1552201200,
		'to' => 1572760799,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1572760800,
		'to' => 1583650799,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1583650800,
		'to' => 1604210399,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1604210400,
		'to' => 1615705199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1615705200,
		'to' => 1636264799,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1636264800,
		'to' => 1647154799,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1647154800,
		'to' => 1667714399,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1667714400,
		'to' => 1678604399,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1678604400,
		'to' => 1699163999,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1699164000,
		'to' => 1710053999,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1710054000,
		'to' => 1730613599,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1730613600,
		'to' => 1741503599,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1741503600,
		'to' => 1762063199,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1762063200,
		'to' => 1772953199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1772953200,
		'to' => 1793512799,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1793512800,
		'to' => 1805007599,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1805007600,
		'to' => 1825567199,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1825567200,
		'to' => 1836457199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1836457200,
		'to' => 1857016799,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1857016800,
		'to' => 1867906799,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1867906800,
		'to' => 1888466399,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1888466400,
		'to' => 1899356399,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1899356400,
		'to' => 1919915999,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1919916000,
		'to' => 1930805999,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1930806000,
		'to' => 1951365599,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1951365600,
		'to' => 1962860399,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1962860400,
		'to' => 1983419999,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1983420000,
		'to' => 1994309999,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1994310000,
		'to' => 2014869599,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 2014869600,
		'to' => 2025759599,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 2025759600,
		'to' => 2046319199,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 2046319200,
		'to' => 2057209199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 2057209200,
		'to' => 2077768799,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 2077768800,
		'to' => 2088658799,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 2088658800,
		'to' => 2109218399,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 2109218400,
		'to' => 2120108399,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 2120108400,
		'to' => 2140667999,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 2140668000,
		'to' => 2147483647,
		'offset' => -18000,
		'dst' => false
	)
);
