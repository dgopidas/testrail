<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 704869199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 704869200,
		'to' => 733895999,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 733896000,
		'to' => 2147483647,
		'offset' => -18000,
		'dst' => false
	)
);
