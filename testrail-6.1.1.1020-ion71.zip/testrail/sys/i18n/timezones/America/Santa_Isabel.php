<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 199274399,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 199274400,
		'to' => 215600399,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 215600400,
		'to' => 230723999,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 230724000,
		'to' => 247049999,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 247050000,
		'to' => 262778399,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 262778400,
		'to' => 278499599,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 278499600,
		'to' => 294227999,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 294228000,
		'to' => 309949199,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 309949200,
		'to' => 325677599,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 325677600,
		'to' => 341398799,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 341398800,
		'to' => 357127199,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 357127200,
		'to' => 372848399,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 372848400,
		'to' => 388576799,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 388576800,
		'to' => 404902799,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 404902800,
		'to' => 420026399,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 420026400,
		'to' => 436352399,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 436352400,
		'to' => 452080799,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 452080800,
		'to' => 467801999,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 467802000,
		'to' => 483530399,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 483530400,
		'to' => 499251599,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 499251600,
		'to' => 514979999,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 514980000,
		'to' => 530701199,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 530701200,
		'to' => 544615199,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 544615200,
		'to' => 562150799,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 562150800,
		'to' => 576064799,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 576064800,
		'to' => 594205199,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 594205200,
		'to' => 607514399,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 607514400,
		'to' => 625654799,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 625654800,
		'to' => 638963999,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 638964000,
		'to' => 657104399,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 657104400,
		'to' => 671018399,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 671018400,
		'to' => 688553999,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 688554000,
		'to' => 702467999,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 702468000,
		'to' => 720003599,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 720003600,
		'to' => 733917599,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 733917600,
		'to' => 752057999,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 752058000,
		'to' => 765367199,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 765367200,
		'to' => 783507599,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 783507600,
		'to' => 796816799,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 796816800,
		'to' => 814957199,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 814957200,
		'to' => 828871199,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 828871200,
		'to' => 846406799,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 846406800,
		'to' => 860320799,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 860320800,
		'to' => 877856399,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 877856400,
		'to' => 891770399,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 891770400,
		'to' => 909305999,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 909306000,
		'to' => 923219999,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 923220000,
		'to' => 941360399,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 941360400,
		'to' => 954669599,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 954669600,
		'to' => 972809999,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 972810000,
		'to' => 986119199,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 986119200,
		'to' => 1004259599,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1004259600,
		'to' => 1018173599,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1018173600,
		'to' => 1035709199,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1035709200,
		'to' => 1049623199,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1049623200,
		'to' => 1067158799,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1067158800,
		'to' => 1081072799,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1081072800,
		'to' => 1099213199,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1099213200,
		'to' => 1112522399,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1112522400,
		'to' => 1130662799,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1130662800,
		'to' => 1143971999,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1143972000,
		'to' => 1162112399,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1162112400,
		'to' => 1175421599,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1175421600,
		'to' => 1193561999,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1193562000,
		'to' => 1207475999,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1207476000,
		'to' => 1225011599,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1225011600,
		'to' => 1238925599,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1238925600,
		'to' => 1256461199,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1256461200,
		'to' => 1270375199,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1270375200,
		'to' => 1288515599,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1288515600,
		'to' => 1301824799,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1301824800,
		'to' => 1319965199,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1319965200,
		'to' => 1333274399,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1333274400,
		'to' => 1351414799,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1351414800,
		'to' => 1365328799,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1365328800,
		'to' => 1382864399,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1382864400,
		'to' => 1396778399,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1396778400,
		'to' => 1414313999,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1414314000,
		'to' => 1428227999,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1428228000,
		'to' => 1445763599,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1445763600,
		'to' => 1459677599,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1459677600,
		'to' => 1477817999,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1477818000,
		'to' => 1491127199,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1491127200,
		'to' => 1509267599,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1509267600,
		'to' => 1522576799,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1522576800,
		'to' => 1540717199,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1540717200,
		'to' => 1554631199,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1554631200,
		'to' => 1572166799,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1572166800,
		'to' => 1586080799,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1586080800,
		'to' => 1603616399,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1603616400,
		'to' => 1617530399,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1617530400,
		'to' => 1635670799,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1635670800,
		'to' => 1648979999,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1648980000,
		'to' => 1667120399,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1667120400,
		'to' => 1680429599,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1680429600,
		'to' => 1698569999,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1698570000,
		'to' => 1712483999,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1712484000,
		'to' => 1730019599,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1730019600,
		'to' => 1743933599,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1743933600,
		'to' => 1761469199,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1761469200,
		'to' => 1775383199,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1775383200,
		'to' => 1792918799,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1792918800,
		'to' => 1806832799,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1806832800,
		'to' => 1824973199,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1824973200,
		'to' => 1838282399,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1838282400,
		'to' => 1856422799,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1856422800,
		'to' => 1869731999,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1869732000,
		'to' => 1887872399,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1887872400,
		'to' => 1901786399,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1901786400,
		'to' => 1919321999,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1919322000,
		'to' => 1933235999,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1933236000,
		'to' => 1950771599,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1950771600,
		'to' => 1964685599,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1964685600,
		'to' => 1982825999,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1982826000,
		'to' => 1996135199,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1996135200,
		'to' => 2014275599,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 2014275600,
		'to' => 2027584799,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 2027584800,
		'to' => 2045725199,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 2045725200,
		'to' => 2059034399,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 2059034400,
		'to' => 2077174799,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 2077174800,
		'to' => 2091088799,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 2091088800,
		'to' => 2108624399,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 2108624400,
		'to' => 2122538399,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 2122538400,
		'to' => 2140073999,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 2140074000,
		'to' => 2147483647,
		'offset' => -28800,
		'dst' => false
	)
);
