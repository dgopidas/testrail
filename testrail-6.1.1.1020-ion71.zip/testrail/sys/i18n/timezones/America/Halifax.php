<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 9957599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 9957600,
		'to' => 25678799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 25678800,
		'to' => 41407199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 41407200,
		'to' => 57733199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 57733200,
		'to' => 73461599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 73461600,
		'to' => 89182799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 89182800,
		'to' => 104911199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 104911200,
		'to' => 120632399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 120632400,
		'to' => 136360799,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 136360800,
		'to' => 152081999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 152082000,
		'to' => 167810399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 167810400,
		'to' => 183531599,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 183531600,
		'to' => 199259999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 199260000,
		'to' => 215585999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 215586000,
		'to' => 230709599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 230709600,
		'to' => 247035599,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 247035600,
		'to' => 262763999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 262764000,
		'to' => 278485199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 278485200,
		'to' => 294213599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 294213600,
		'to' => 309934799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 309934800,
		'to' => 325663199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 325663200,
		'to' => 341384399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 341384400,
		'to' => 357112799,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 357112800,
		'to' => 372833999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 372834000,
		'to' => 388562399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 388562400,
		'to' => 404888399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 404888400,
		'to' => 420011999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 420012000,
		'to' => 436337999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 436338000,
		'to' => 452066399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 452066400,
		'to' => 467787599,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 467787600,
		'to' => 483515999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 483516000,
		'to' => 499237199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 499237200,
		'to' => 514965599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 514965600,
		'to' => 530686799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 530686800,
		'to' => 544600799,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 544600800,
		'to' => 562136399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 562136400,
		'to' => 576050399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 576050400,
		'to' => 594190799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 594190800,
		'to' => 607499999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 607500000,
		'to' => 625640399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 625640400,
		'to' => 638949599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 638949600,
		'to' => 657089999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 657090000,
		'to' => 671003999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 671004000,
		'to' => 688539599,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 688539600,
		'to' => 702453599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 702453600,
		'to' => 719989199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 719989200,
		'to' => 733903199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 733903200,
		'to' => 752043599,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 752043600,
		'to' => 765352799,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 765352800,
		'to' => 783493199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 783493200,
		'to' => 796802399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 796802400,
		'to' => 814942799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 814942800,
		'to' => 828856799,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 828856800,
		'to' => 846392399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 846392400,
		'to' => 860306399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 860306400,
		'to' => 877841999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 877842000,
		'to' => 891755999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 891756000,
		'to' => 909291599,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 909291600,
		'to' => 923205599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 923205600,
		'to' => 941345999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 941346000,
		'to' => 954655199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 954655200,
		'to' => 972795599,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 972795600,
		'to' => 986104799,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 986104800,
		'to' => 1004245199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1004245200,
		'to' => 1018159199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1018159200,
		'to' => 1035694799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1035694800,
		'to' => 1049608799,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1049608800,
		'to' => 1067144399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1067144400,
		'to' => 1081058399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1081058400,
		'to' => 1099198799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1099198800,
		'to' => 1112507999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1112508000,
		'to' => 1130648399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1130648400,
		'to' => 1143957599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1143957600,
		'to' => 1162097999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1162098000,
		'to' => 1173592799,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1173592800,
		'to' => 1194152399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1194152400,
		'to' => 1205042399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1205042400,
		'to' => 1225601999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1225602000,
		'to' => 1236491999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1236492000,
		'to' => 1257051599,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1257051600,
		'to' => 1268546399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1268546400,
		'to' => 1289105999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1289106000,
		'to' => 1299995999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1299996000,
		'to' => 1320555599,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1320555600,
		'to' => 1331445599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1331445600,
		'to' => 1352005199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1352005200,
		'to' => 1362895199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1362895200,
		'to' => 1383454799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1383454800,
		'to' => 1394344799,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1394344800,
		'to' => 1414904399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1414904400,
		'to' => 1425794399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1425794400,
		'to' => 1446353999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1446354000,
		'to' => 1457848799,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1457848800,
		'to' => 1478408399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1478408400,
		'to' => 1489298399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1489298400,
		'to' => 1509857999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1509858000,
		'to' => 1520747999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1520748000,
		'to' => 1541307599,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1541307600,
		'to' => 1552197599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1552197600,
		'to' => 1572757199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1572757200,
		'to' => 1583647199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1583647200,
		'to' => 1604206799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1604206800,
		'to' => 1615701599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1615701600,
		'to' => 1636261199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1636261200,
		'to' => 1647151199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1647151200,
		'to' => 1667710799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1667710800,
		'to' => 1678600799,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1678600800,
		'to' => 1699160399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1699160400,
		'to' => 1710050399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1710050400,
		'to' => 1730609999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1730610000,
		'to' => 1741499999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1741500000,
		'to' => 1762059599,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1762059600,
		'to' => 1772949599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1772949600,
		'to' => 1793509199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1793509200,
		'to' => 1805003999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1805004000,
		'to' => 1825563599,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1825563600,
		'to' => 1836453599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1836453600,
		'to' => 1857013199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1857013200,
		'to' => 1867903199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1867903200,
		'to' => 1888462799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1888462800,
		'to' => 1899352799,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1899352800,
		'to' => 1919912399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1919912400,
		'to' => 1930802399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1930802400,
		'to' => 1951361999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1951362000,
		'to' => 1962856799,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1962856800,
		'to' => 1983416399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1983416400,
		'to' => 1994306399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1994306400,
		'to' => 2014865999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 2014866000,
		'to' => 2025755999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 2025756000,
		'to' => 2046315599,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 2046315600,
		'to' => 2057205599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 2057205600,
		'to' => 2077765199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 2077765200,
		'to' => 2088655199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 2088655200,
		'to' => 2109214799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 2109214800,
		'to' => 2120104799,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 2120104800,
		'to' => 2140664399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 2140664400,
		'to' => 2147483647,
		'offset' => -14400,
		'dst' => false
	)
);
