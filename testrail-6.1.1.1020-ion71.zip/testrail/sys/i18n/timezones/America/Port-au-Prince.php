<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 421217999,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 421218000,
		'to' => 436334399,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 436334400,
		'to' => 452062799,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 452062800,
		'to' => 467783999,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 467784000,
		'to' => 483512399,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 483512400,
		'to' => 499233599,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 499233600,
		'to' => 514961999,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 514962000,
		'to' => 530683199,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 530683200,
		'to' => 546411599,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 546411600,
		'to' => 562132799,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 562132800,
		'to' => 576050399,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 576050400,
		'to' => 594194399,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 594194400,
		'to' => 607499999,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 607500000,
		'to' => 625643999,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 625644000,
		'to' => 638949599,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 638949600,
		'to' => 657093599,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 657093600,
		'to' => 671003999,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 671004000,
		'to' => 688543199,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 688543200,
		'to' => 702453599,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 702453600,
		'to' => 719992799,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 719992800,
		'to' => 733903199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 733903200,
		'to' => 752047199,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 752047200,
		'to' => 765352799,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 765352800,
		'to' => 783496799,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 783496800,
		'to' => 796802399,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 796802400,
		'to' => 814946399,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 814946400,
		'to' => 828856799,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 828856800,
		'to' => 846395999,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 846396000,
		'to' => 860306399,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 860306400,
		'to' => 877845599,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 877845600,
		'to' => 1112504399,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1112504400,
		'to' => 1130644799,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1130644800,
		'to' => 1143953999,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1143954000,
		'to' => 1162094399,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1162094400,
		'to' => 2147483647,
		'offset' => -18000,
		'dst' => false
	)
);
