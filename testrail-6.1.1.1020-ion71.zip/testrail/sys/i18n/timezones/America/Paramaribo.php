<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 185686199,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 185686200,
		'to' => 465449399,
		'offset' => -12600,
		'dst' => false
	),
	array(
		'from' => 465449400,
		'to' => 2147483647,
		'offset' => -10800,
		'dst' => false
	)
);
