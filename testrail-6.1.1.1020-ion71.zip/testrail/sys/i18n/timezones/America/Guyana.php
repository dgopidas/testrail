<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 176010299,
		'offset' => -13500,
		'dst' => false
	),
	array(
		'from' => 176010300,
		'to' => 662698799,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 662698800,
		'to' => 2147483647,
		'offset' => -14400,
		'dst' => false
	)
);
