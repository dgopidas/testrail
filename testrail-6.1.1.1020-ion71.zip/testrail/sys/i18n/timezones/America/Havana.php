<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 9953999,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 9954000,
		'to' => 25675199,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 25675200,
		'to' => 41403599,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 41403600,
		'to' => 57729599,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 57729600,
		'to' => 73457999,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 73458000,
		'to' => 87364799,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 87364800,
		'to' => 104907599,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 104907600,
		'to' => 118900799,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 118900800,
		'to' => 136357199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 136357200,
		'to' => 150436799,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 150436800,
		'to' => 167806799,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 167806800,
		'to' => 183527999,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 183528000,
		'to' => 199256399,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 199256400,
		'to' => 215582399,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 215582400,
		'to' => 230705999,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 230706000,
		'to' => 247031999,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 247032000,
		'to' => 263365199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 263365200,
		'to' => 276667199,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 276667200,
		'to' => 290581199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 290581200,
		'to' => 308721599,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 308721600,
		'to' => 322030799,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 322030800,
		'to' => 340171199,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 340171200,
		'to' => 358318799,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 358318800,
		'to' => 371620799,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 371620800,
		'to' => 389768399,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 389768400,
		'to' => 403070399,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 403070400,
		'to' => 421217999,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 421218000,
		'to' => 434519999,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 434520000,
		'to' => 452667599,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 452667600,
		'to' => 466574399,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 466574400,
		'to' => 484117199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 484117200,
		'to' => 498023999,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 498024000,
		'to' => 511333199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 511333200,
		'to' => 529473599,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 529473600,
		'to' => 542782799,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 542782800,
		'to' => 560923199,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 560923200,
		'to' => 574837199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 574837200,
		'to' => 592372799,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 592372800,
		'to' => 606286799,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 606286800,
		'to' => 623822399,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 623822400,
		'to' => 638945999,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 638946000,
		'to' => 655876799,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 655876800,
		'to' => 671000399,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 671000400,
		'to' => 687329999,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 687330000,
		'to' => 702449999,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 702450000,
		'to' => 718779599,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 718779600,
		'to' => 733899599,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 733899600,
		'to' => 750229199,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 750229200,
		'to' => 765349199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 765349200,
		'to' => 781678799,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 781678800,
		'to' => 796798799,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 796798800,
		'to' => 813128399,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 813128400,
		'to' => 828853199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 828853200,
		'to' => 844577999,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 844578000,
		'to' => 860302799,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 860302800,
		'to' => 876632399,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 876632400,
		'to' => 891147599,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 891147600,
		'to' => 909291599,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 909291600,
		'to' => 922597199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 922597200,
		'to' => 941345999,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 941346000,
		'to' => 954651599,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 954651600,
		'to' => 972795599,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 972795600,
		'to' => 986101199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 986101200,
		'to' => 1004245199,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1004245200,
		'to' => 1018155599,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1018155600,
		'to' => 1035694799,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1035694800,
		'to' => 1049605199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1049605200,
		'to' => 1067144399,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1067144400,
		'to' => 1081054799,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1081054800,
		'to' => 1162097999,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1162098000,
		'to' => 1173589199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1173589200,
		'to' => 1193547599,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1193547600,
		'to' => 1205643599,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1205643600,
		'to' => 1224997199,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1224997200,
		'to' => 1236488399,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1236488400,
		'to' => 1256446799,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1256446800,
		'to' => 1268542799,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1268542800,
		'to' => 1288501199,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1288501200,
		'to' => 1300597199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1300597200,
		'to' => 1319950799,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1319950800,
		'to' => 1331441999,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1331442000,
		'to' => 1351400399,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1351400400,
		'to' => 1362891599,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1362891600,
		'to' => 1382849999,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1382850000,
		'to' => 1394341199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1394341200,
		'to' => 1414299599,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1414299600,
		'to' => 1425790799,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1425790800,
		'to' => 1445749199,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1445749200,
		'to' => 1457845199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1457845200,
		'to' => 1477803599,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1477803600,
		'to' => 1489294799,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1489294800,
		'to' => 1509253199,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1509253200,
		'to' => 1520744399,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1520744400,
		'to' => 1540702799,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1540702800,
		'to' => 1552193999,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1552194000,
		'to' => 1572152399,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1572152400,
		'to' => 1583643599,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1583643600,
		'to' => 1603601999,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1603602000,
		'to' => 1615697999,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1615698000,
		'to' => 1635656399,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1635656400,
		'to' => 1647147599,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1647147600,
		'to' => 1667105999,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1667106000,
		'to' => 1678597199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1678597200,
		'to' => 1698555599,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1698555600,
		'to' => 1710046799,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1710046800,
		'to' => 1730005199,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1730005200,
		'to' => 1741496399,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1741496400,
		'to' => 1761454799,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1761454800,
		'to' => 1772945999,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1772946000,
		'to' => 1792904399,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1792904400,
		'to' => 1805000399,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1805000400,
		'to' => 1824958799,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1824958800,
		'to' => 1836449999,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1836450000,
		'to' => 1856408399,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1856408400,
		'to' => 1867899599,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1867899600,
		'to' => 1887857999,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1887858000,
		'to' => 1899349199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1899349200,
		'to' => 1919307599,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1919307600,
		'to' => 1930798799,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1930798800,
		'to' => 1950757199,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1950757200,
		'to' => 1962853199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1962853200,
		'to' => 1982811599,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1982811600,
		'to' => 1994302799,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1994302800,
		'to' => 2014261199,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 2014261200,
		'to' => 2025752399,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 2025752400,
		'to' => 2045710799,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 2045710800,
		'to' => 2057201999,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 2057202000,
		'to' => 2077160399,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 2077160400,
		'to' => 2088651599,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 2088651600,
		'to' => 2108609999,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 2108610000,
		'to' => 2120101199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 2120101200,
		'to' => 2140059599,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 2140059600,
		'to' => 2147483647,
		'offset' => -18000,
		'dst' => false
	)
);
