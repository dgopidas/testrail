<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 576057599,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 576057600,
		'to' => 594197999,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 594198000,
		'to' => 828863999,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 828864000,
		'to' => 846399599,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 846399600,
		'to' => 860313599,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 860313600,
		'to' => 877849199,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 877849200,
		'to' => 891763199,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 891763200,
		'to' => 909298799,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 909298800,
		'to' => 923212799,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 923212800,
		'to' => 941353199,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 941353200,
		'to' => 954662399,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 954662400,
		'to' => 972802799,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 972802800,
		'to' => 989135999,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 989136000,
		'to' => 1001833199,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1001833200,
		'to' => 1018166399,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1018166400,
		'to' => 1035701999,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1035702000,
		'to' => 1049615999,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1049616000,
		'to' => 1067151599,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1067151600,
		'to' => 1081065599,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1081065600,
		'to' => 1099205999,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1099206000,
		'to' => 1112515199,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1112515200,
		'to' => 1130655599,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1130655600,
		'to' => 1143964799,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1143964800,
		'to' => 1162105199,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1162105200,
		'to' => 1175414399,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1175414400,
		'to' => 1193554799,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1193554800,
		'to' => 1207468799,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1207468800,
		'to' => 1225004399,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1225004400,
		'to' => 1238918399,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1238918400,
		'to' => 1256453999,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1256454000,
		'to' => 1268553599,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1268553600,
		'to' => 1289113199,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1289113200,
		'to' => 1300003199,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1300003200,
		'to' => 1320562799,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1320562800,
		'to' => 1331452799,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1331452800,
		'to' => 1352012399,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1352012400,
		'to' => 1362902399,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1362902400,
		'to' => 1383461999,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1383462000,
		'to' => 1394351999,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1394352000,
		'to' => 1414911599,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1414911600,
		'to' => 1425801599,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1425801600,
		'to' => 1446361199,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1446361200,
		'to' => 1457855999,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1457856000,
		'to' => 1478415599,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1478415600,
		'to' => 1489305599,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1489305600,
		'to' => 1509865199,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1509865200,
		'to' => 1520755199,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1520755200,
		'to' => 1541314799,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1541314800,
		'to' => 1552204799,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1552204800,
		'to' => 1572764399,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1572764400,
		'to' => 1583654399,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1583654400,
		'to' => 1604213999,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1604214000,
		'to' => 1615708799,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1615708800,
		'to' => 1636268399,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1636268400,
		'to' => 1647158399,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1647158400,
		'to' => 1667717999,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1667718000,
		'to' => 1678607999,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1678608000,
		'to' => 1699167599,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1699167600,
		'to' => 1710057599,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1710057600,
		'to' => 1730617199,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1730617200,
		'to' => 1741507199,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1741507200,
		'to' => 1762066799,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1762066800,
		'to' => 1772956799,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1772956800,
		'to' => 1793516399,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1793516400,
		'to' => 1805011199,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1805011200,
		'to' => 1825570799,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1825570800,
		'to' => 1836460799,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1836460800,
		'to' => 1857020399,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1857020400,
		'to' => 1867910399,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1867910400,
		'to' => 1888469999,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1888470000,
		'to' => 1899359999,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1899360000,
		'to' => 1919919599,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1919919600,
		'to' => 1930809599,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1930809600,
		'to' => 1951369199,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1951369200,
		'to' => 1962863999,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1962864000,
		'to' => 1983423599,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1983423600,
		'to' => 1994313599,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1994313600,
		'to' => 2014873199,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 2014873200,
		'to' => 2025763199,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 2025763200,
		'to' => 2046322799,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 2046322800,
		'to' => 2057212799,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 2057212800,
		'to' => 2077772399,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 2077772400,
		'to' => 2088662399,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 2088662400,
		'to' => 2109221999,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 2109222000,
		'to' => 2120111999,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 2120112000,
		'to' => 2140671599,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 2140671600,
		'to' => 2147483647,
		'offset' => -21600,
		'dst' => false
	)
);
