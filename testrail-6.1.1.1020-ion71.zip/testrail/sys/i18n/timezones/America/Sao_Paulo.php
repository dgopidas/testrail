<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 499748399,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 499748400,
		'to' => 511235999,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 511236000,
		'to' => 530593199,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 530593200,
		'to' => 540266399,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 540266400,
		'to' => 562129199,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 562129200,
		'to' => 571197599,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 571197600,
		'to' => 592973999,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 592974000,
		'to' => 602042399,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 602042400,
		'to' => 624423599,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 624423600,
		'to' => 634701599,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 634701600,
		'to' => 656477999,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 656478000,
		'to' => 666755999,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 666756000,
		'to' => 687927599,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 687927600,
		'to' => 697600799,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 697600800,
		'to' => 719981999,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 719982000,
		'to' => 728445599,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 728445600,
		'to' => 750826799,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 750826800,
		'to' => 761709599,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 761709600,
		'to' => 782276399,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 782276400,
		'to' => 793159199,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 793159200,
		'to' => 813725999,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 813726000,
		'to' => 824003999,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 824004000,
		'to' => 844570799,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 844570800,
		'to' => 856058399,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 856058400,
		'to' => 876106799,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 876106800,
		'to' => 888717599,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 888717600,
		'to' => 908074799,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 908074800,
		'to' => 919562399,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 919562400,
		'to' => 938919599,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 938919600,
		'to' => 951616799,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 951616800,
		'to' => 970973999,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 970974000,
		'to' => 982461599,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 982461600,
		'to' => 1003028399,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1003028400,
		'to' => 1013911199,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1013911200,
		'to' => 1036292399,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1036292400,
		'to' => 1045360799,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1045360800,
		'to' => 1066532399,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1066532400,
		'to' => 1076810399,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1076810400,
		'to' => 1099364399,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1099364400,
		'to' => 1108864799,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1108864800,
		'to' => 1129431599,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1129431600,
		'to' => 1140314399,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1140314400,
		'to' => 1162695599,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1162695600,
		'to' => 1172368799,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1172368800,
		'to' => 1192330799,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1192330800,
		'to' => 1203213599,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1203213600,
		'to' => 1224385199,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1224385200,
		'to' => 1234663199,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1234663200,
		'to' => 1255834799,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1255834800,
		'to' => 1266717599,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1266717600,
		'to' => 1287284399,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1287284400,
		'to' => 1298167199,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1298167200,
		'to' => 1318733999,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1318734000,
		'to' => 1330221599,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1330221600,
		'to' => 1350788399,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1350788400,
		'to' => 1361066399,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1361066400,
		'to' => 1382237999,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1382238000,
		'to' => 1392515999,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1392516000,
		'to' => 1413687599,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1413687600,
		'to' => 1424570399,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1424570400,
		'to' => 1445137199,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1445137200,
		'to' => 1456019999,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1456020000,
		'to' => 1476586799,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1476586800,
		'to' => 1487469599,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1487469600,
		'to' => 1508036399,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1508036400,
		'to' => 1518919199,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1518919200,
		'to' => 1540090799,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1540090800,
		'to' => 1550368799,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1550368800,
		'to' => 1571540399,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1571540400,
		'to' => 1581818399,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1581818400,
		'to' => 1602989999,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1602990000,
		'to' => 1613872799,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1613872800,
		'to' => 1634439599,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1634439600,
		'to' => 1645322399,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1645322400,
		'to' => 1665889199,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1665889200,
		'to' => 1677376799,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1677376800,
		'to' => 1697338799,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1697338800,
		'to' => 1708221599,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1708221600,
		'to' => 1729393199,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1729393200,
		'to' => 1739671199,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1739671200,
		'to' => 1760842799,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1760842800,
		'to' => 1771725599,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1771725600,
		'to' => 1792292399,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1792292400,
		'to' => 1803175199,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1803175200,
		'to' => 1823741999,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1823742000,
		'to' => 1834624799,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1834624800,
		'to' => 1855191599,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1855191600,
		'to' => 1866074399,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1866074400,
		'to' => 1887245999,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1887246000,
		'to' => 1897523999,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1897524000,
		'to' => 1918695599,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1918695600,
		'to' => 1928973599,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1928973600,
		'to' => 1950145199,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1950145200,
		'to' => 1960423199,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1960423200,
		'to' => 1981594799,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1981594800,
		'to' => 1992477599,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1992477600,
		'to' => 2013044399,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 2013044400,
		'to' => 2024531999,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 2024532000,
		'to' => 2044493999,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 2044494000,
		'to' => 2055376799,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 2055376800,
		'to' => 2076548399,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 2076548400,
		'to' => 2086826399,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 2086826400,
		'to' => 2107997999,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 2107998000,
		'to' => 2118880799,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 2118880800,
		'to' => 2139447599,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 2139447600,
		'to' => 2147483647,
		'offset' => -7200,
		'dst' => true
	)
);
