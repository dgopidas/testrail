<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 499751999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 499752000,
		'to' => 511239599,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 511239600,
		'to' => 530596799,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 530596800,
		'to' => 540269999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 540270000,
		'to' => 562132799,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 562132800,
		'to' => 571201199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 571201200,
		'to' => 592977599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 592977600,
		'to' => 602045999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 602046000,
		'to' => 624427199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 624427200,
		'to' => 634705199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 634705200,
		'to' => 656481599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 656481600,
		'to' => 666759599,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 666759600,
		'to' => 687931199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 687931200,
		'to' => 697604399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 697604400,
		'to' => 719985599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 719985600,
		'to' => 728449199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 728449200,
		'to' => 750830399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 750830400,
		'to' => 761713199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 761713200,
		'to' => 782279999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 782280000,
		'to' => 793162799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 793162800,
		'to' => 813729599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 813729600,
		'to' => 824007599,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 824007600,
		'to' => 844574399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 844574400,
		'to' => 856061999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 856062000,
		'to' => 876110399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 876110400,
		'to' => 888721199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 888721200,
		'to' => 908078399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 908078400,
		'to' => 919565999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 919566000,
		'to' => 938923199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 938923200,
		'to' => 951620399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 951620400,
		'to' => 970977599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 970977600,
		'to' => 982465199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 982465200,
		'to' => 1003031999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1003032000,
		'to' => 1013914799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1013914800,
		'to' => 1036295999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1036296000,
		'to' => 1045364399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1045364400,
		'to' => 1099367999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1099368000,
		'to' => 1108868399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1108868400,
		'to' => 1129435199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1129435200,
		'to' => 1140317999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1140318000,
		'to' => 1162699199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1162699200,
		'to' => 1172372399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1172372400,
		'to' => 1192334399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1192334400,
		'to' => 1203217199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1203217200,
		'to' => 1224388799,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1224388800,
		'to' => 1234666799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1234666800,
		'to' => 1255838399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1255838400,
		'to' => 1266721199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1266721200,
		'to' => 1287287999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1287288000,
		'to' => 1298170799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1298170800,
		'to' => 1318737599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1318737600,
		'to' => 1330225199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1330225200,
		'to' => 1350791999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1350792000,
		'to' => 1361069999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1361070000,
		'to' => 1382241599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1382241600,
		'to' => 1392519599,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1392519600,
		'to' => 1413691199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1413691200,
		'to' => 1424573999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1424574000,
		'to' => 1445140799,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1445140800,
		'to' => 1456023599,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1456023600,
		'to' => 1476590399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1476590400,
		'to' => 1487473199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1487473200,
		'to' => 1508039999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1508040000,
		'to' => 1518922799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1518922800,
		'to' => 1540094399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1540094400,
		'to' => 1550372399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1550372400,
		'to' => 1571543999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1571544000,
		'to' => 1581821999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1581822000,
		'to' => 1602993599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1602993600,
		'to' => 1613876399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1613876400,
		'to' => 1634443199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1634443200,
		'to' => 1645325999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1645326000,
		'to' => 1665892799,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1665892800,
		'to' => 1677380399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1677380400,
		'to' => 1697342399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1697342400,
		'to' => 1708225199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1708225200,
		'to' => 1729396799,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1729396800,
		'to' => 1739674799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1739674800,
		'to' => 1760846399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1760846400,
		'to' => 1771729199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1771729200,
		'to' => 1792295999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1792296000,
		'to' => 1803178799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1803178800,
		'to' => 1823745599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1823745600,
		'to' => 1834628399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1834628400,
		'to' => 1855195199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1855195200,
		'to' => 1866077999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1866078000,
		'to' => 1887249599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1887249600,
		'to' => 1897527599,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1897527600,
		'to' => 1918699199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1918699200,
		'to' => 1928977199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1928977200,
		'to' => 1950148799,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1950148800,
		'to' => 1960426799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1960426800,
		'to' => 1981598399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1981598400,
		'to' => 1992481199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1992481200,
		'to' => 2013047999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 2013048000,
		'to' => 2024535599,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 2024535600,
		'to' => 2044497599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 2044497600,
		'to' => 2055380399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 2055380400,
		'to' => 2076551999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 2076552000,
		'to' => 2086829999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 2086830000,
		'to' => 2108001599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 2108001600,
		'to' => 2118884399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 2118884400,
		'to' => 2139451199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 2139451200,
		'to' => 2147483647,
		'offset' => -10800,
		'dst' => true
	)
);
