<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 9982799,
		'offset' => -39600,
		'dst' => false
	),
	array(
		'from' => 9982800,
		'to' => 25703999,
		'offset' => -36000,
		'dst' => true
	),
	array(
		'from' => 25704000,
		'to' => 41432399,
		'offset' => -39600,
		'dst' => false
	),
	array(
		'from' => 41432400,
		'to' => 57758399,
		'offset' => -36000,
		'dst' => true
	),
	array(
		'from' => 57758400,
		'to' => 73486799,
		'offset' => -39600,
		'dst' => false
	),
	array(
		'from' => 73486800,
		'to' => 89207999,
		'offset' => -36000,
		'dst' => true
	),
	array(
		'from' => 89208000,
		'to' => 104936399,
		'offset' => -39600,
		'dst' => false
	),
	array(
		'from' => 104936400,
		'to' => 120657599,
		'offset' => -36000,
		'dst' => true
	),
	array(
		'from' => 120657600,
		'to' => 126709199,
		'offset' => -39600,
		'dst' => false
	),
	array(
		'from' => 126709200,
		'to' => 152107199,
		'offset' => -36000,
		'dst' => true
	),
	array(
		'from' => 152107200,
		'to' => 162392399,
		'offset' => -39600,
		'dst' => false
	),
	array(
		'from' => 162392400,
		'to' => 183556799,
		'offset' => -36000,
		'dst' => true
	),
	array(
		'from' => 183556800,
		'to' => 199285199,
		'offset' => -39600,
		'dst' => false
	),
	array(
		'from' => 199285200,
		'to' => 215611199,
		'offset' => -36000,
		'dst' => true
	),
	array(
		'from' => 215611200,
		'to' => 230734799,
		'offset' => -39600,
		'dst' => false
	),
	array(
		'from' => 230734800,
		'to' => 247060799,
		'offset' => -36000,
		'dst' => true
	),
	array(
		'from' => 247060800,
		'to' => 262789199,
		'offset' => -39600,
		'dst' => false
	),
	array(
		'from' => 262789200,
		'to' => 278510399,
		'offset' => -36000,
		'dst' => true
	),
	array(
		'from' => 278510400,
		'to' => 294238799,
		'offset' => -39600,
		'dst' => false
	),
	array(
		'from' => 294238800,
		'to' => 309959999,
		'offset' => -36000,
		'dst' => true
	),
	array(
		'from' => 309960000,
		'to' => 325688399,
		'offset' => -39600,
		'dst' => false
	),
	array(
		'from' => 325688400,
		'to' => 341409599,
		'offset' => -36000,
		'dst' => true
	),
	array(
		'from' => 341409600,
		'to' => 357137999,
		'offset' => -39600,
		'dst' => false
	),
	array(
		'from' => 357138000,
		'to' => 372859199,
		'offset' => -36000,
		'dst' => true
	),
	array(
		'from' => 372859200,
		'to' => 388587599,
		'offset' => -39600,
		'dst' => false
	),
	array(
		'from' => 388587600,
		'to' => 404913599,
		'offset' => -36000,
		'dst' => true
	),
	array(
		'from' => 404913600,
		'to' => 420037199,
		'offset' => -39600,
		'dst' => false
	),
	array(
		'from' => 420037200,
		'to' => 436363199,
		'offset' => -36000,
		'dst' => true
	),
	array(
		'from' => 436363200,
		'to' => 439030799,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 439030800,
		'to' => 452084399,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 452084400,
		'to' => 467805599,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 467805600,
		'to' => 483533999,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 483534000,
		'to' => 499255199,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 499255200,
		'to' => 514983599,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 514983600,
		'to' => 530704799,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 530704800,
		'to' => 544618799,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 544618800,
		'to' => 562154399,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 562154400,
		'to' => 576068399,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 576068400,
		'to' => 594208799,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 594208800,
		'to' => 607517999,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 607518000,
		'to' => 625658399,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 625658400,
		'to' => 638967599,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 638967600,
		'to' => 657107999,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 657108000,
		'to' => 671021999,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 671022000,
		'to' => 688557599,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 688557600,
		'to' => 702471599,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 702471600,
		'to' => 720007199,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 720007200,
		'to' => 733921199,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 733921200,
		'to' => 752061599,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 752061600,
		'to' => 765370799,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 765370800,
		'to' => 783511199,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 783511200,
		'to' => 796820399,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 796820400,
		'to' => 814960799,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 814960800,
		'to' => 828874799,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 828874800,
		'to' => 846410399,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 846410400,
		'to' => 860324399,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 860324400,
		'to' => 877859999,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 877860000,
		'to' => 891773999,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 891774000,
		'to' => 909309599,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 909309600,
		'to' => 923223599,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 923223600,
		'to' => 941363999,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 941364000,
		'to' => 954673199,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 954673200,
		'to' => 972813599,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 972813600,
		'to' => 986122799,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 986122800,
		'to' => 1004263199,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1004263200,
		'to' => 1018177199,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1018177200,
		'to' => 1035712799,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1035712800,
		'to' => 1049626799,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1049626800,
		'to' => 1067162399,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1067162400,
		'to' => 1081076399,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1081076400,
		'to' => 1099216799,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1099216800,
		'to' => 1112525999,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1112526000,
		'to' => 1130666399,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1130666400,
		'to' => 1143975599,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1143975600,
		'to' => 1162115999,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1162116000,
		'to' => 1173610799,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1173610800,
		'to' => 1194170399,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1194170400,
		'to' => 1205060399,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1205060400,
		'to' => 1225619999,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1225620000,
		'to' => 1236509999,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1236510000,
		'to' => 1257069599,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1257069600,
		'to' => 1268564399,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1268564400,
		'to' => 1289123999,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1289124000,
		'to' => 1300013999,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1300014000,
		'to' => 1320573599,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1320573600,
		'to' => 1331463599,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1331463600,
		'to' => 1352023199,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1352023200,
		'to' => 1362913199,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1362913200,
		'to' => 1383472799,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1383472800,
		'to' => 1394362799,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1394362800,
		'to' => 1414922399,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1414922400,
		'to' => 1425812399,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1425812400,
		'to' => 1446371999,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1446372000,
		'to' => 1457866799,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1457866800,
		'to' => 1478426399,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1478426400,
		'to' => 1489316399,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1489316400,
		'to' => 1509875999,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1509876000,
		'to' => 1520765999,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1520766000,
		'to' => 1541325599,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1541325600,
		'to' => 1552215599,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1552215600,
		'to' => 1572775199,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1572775200,
		'to' => 1583665199,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1583665200,
		'to' => 1604224799,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1604224800,
		'to' => 1615719599,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1615719600,
		'to' => 1636279199,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1636279200,
		'to' => 1647169199,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1647169200,
		'to' => 1667728799,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1667728800,
		'to' => 1678618799,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1678618800,
		'to' => 1699178399,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1699178400,
		'to' => 1710068399,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1710068400,
		'to' => 1730627999,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1730628000,
		'to' => 1741517999,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1741518000,
		'to' => 1762077599,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1762077600,
		'to' => 1772967599,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1772967600,
		'to' => 1793527199,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1793527200,
		'to' => 1805021999,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1805022000,
		'to' => 1825581599,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1825581600,
		'to' => 1836471599,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1836471600,
		'to' => 1857031199,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1857031200,
		'to' => 1867921199,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1867921200,
		'to' => 1888480799,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1888480800,
		'to' => 1899370799,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1899370800,
		'to' => 1919930399,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1919930400,
		'to' => 1930820399,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1930820400,
		'to' => 1951379999,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1951380000,
		'to' => 1962874799,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1962874800,
		'to' => 1983434399,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1983434400,
		'to' => 1994324399,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1994324400,
		'to' => 2014883999,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 2014884000,
		'to' => 2025773999,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 2025774000,
		'to' => 2046333599,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 2046333600,
		'to' => 2057223599,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 2057223600,
		'to' => 2077783199,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 2077783200,
		'to' => 2088673199,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 2088673200,
		'to' => 2109232799,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 2109232800,
		'to' => 2120122799,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 2120122800,
		'to' => 2140682399,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 2140682400,
		'to' => 2147483647,
		'offset' => -32400,
		'dst' => false
	)
);
