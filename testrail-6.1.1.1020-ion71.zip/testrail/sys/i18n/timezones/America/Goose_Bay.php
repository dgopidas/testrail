<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 9957599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 9957600,
		'to' => 25678799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 25678800,
		'to' => 41407199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 41407200,
		'to' => 57733199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 57733200,
		'to' => 73461599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 73461600,
		'to' => 89182799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 89182800,
		'to' => 104911199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 104911200,
		'to' => 120632399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 120632400,
		'to' => 136360799,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 136360800,
		'to' => 152081999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 152082000,
		'to' => 167810399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 167810400,
		'to' => 183531599,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 183531600,
		'to' => 199259999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 199260000,
		'to' => 215585999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 215586000,
		'to' => 230709599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 230709600,
		'to' => 247035599,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 247035600,
		'to' => 262763999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 262764000,
		'to' => 278485199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 278485200,
		'to' => 294213599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 294213600,
		'to' => 309934799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 309934800,
		'to' => 325663199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 325663200,
		'to' => 341384399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 341384400,
		'to' => 357112799,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 357112800,
		'to' => 372833999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 372834000,
		'to' => 388562399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 388562400,
		'to' => 404888399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 404888400,
		'to' => 420011999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 420012000,
		'to' => 436337999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 436338000,
		'to' => 452066399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 452066400,
		'to' => 467787599,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 467787600,
		'to' => 483515999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 483516000,
		'to' => 499237199,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 499237200,
		'to' => 514965599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 514965600,
		'to' => 530686799,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 530686800,
		'to' => 544593659,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 544593660,
		'to' => 562129259,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 562129260,
		'to' => 576043259,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 576043260,
		'to' => 594180059,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 594180060,
		'to' => 607492859,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 607492860,
		'to' => 625633259,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 625633260,
		'to' => 638942459,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 638942460,
		'to' => 657082859,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 657082860,
		'to' => 670996859,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 670996860,
		'to' => 688532459,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 688532460,
		'to' => 702446459,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 702446460,
		'to' => 719982059,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 719982060,
		'to' => 733896059,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 733896060,
		'to' => 752036459,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 752036460,
		'to' => 765345659,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 765345660,
		'to' => 783486059,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 783486060,
		'to' => 796795259,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 796795260,
		'to' => 814935659,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 814935660,
		'to' => 828849659,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 828849660,
		'to' => 846385259,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 846385260,
		'to' => 860299259,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 860299260,
		'to' => 877834859,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 877834860,
		'to' => 891748859,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 891748860,
		'to' => 909284459,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 909284460,
		'to' => 923198459,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 923198460,
		'to' => 941338859,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 941338860,
		'to' => 954648059,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 954648060,
		'to' => 972788459,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 972788460,
		'to' => 986097659,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 986097660,
		'to' => 1004238059,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1004238060,
		'to' => 1018152059,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1018152060,
		'to' => 1035687659,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1035687660,
		'to' => 1049601659,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1049601660,
		'to' => 1067137259,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1067137260,
		'to' => 1081051259,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1081051260,
		'to' => 1099191659,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1099191660,
		'to' => 1112500859,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1112500860,
		'to' => 1130641259,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1130641260,
		'to' => 1143950459,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1143950460,
		'to' => 1162090859,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1162090860,
		'to' => 1173585659,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1173585660,
		'to' => 1194145259,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1194145260,
		'to' => 1205035259,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1205035260,
		'to' => 1225594859,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1225594860,
		'to' => 1236484859,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1236484860,
		'to' => 1257044459,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1257044460,
		'to' => 1268539259,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1268539260,
		'to' => 1289098859,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1289098860,
		'to' => 1299988859,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1299988860,
		'to' => 1320548459,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1320548460,
		'to' => 1331438459,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1331438460,
		'to' => 1351998059,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1351998060,
		'to' => 1362888059,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1362888060,
		'to' => 1383447659,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1383447660,
		'to' => 1394337659,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1394337660,
		'to' => 1414897259,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1414897260,
		'to' => 1425787259,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1425787260,
		'to' => 1446346859,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1446346860,
		'to' => 1457841659,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1457841660,
		'to' => 1478401259,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1478401260,
		'to' => 1489291259,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1489291260,
		'to' => 1509850859,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1509850860,
		'to' => 1520740859,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1520740860,
		'to' => 1541300459,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1541300460,
		'to' => 1552190459,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1552190460,
		'to' => 1572750059,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1572750060,
		'to' => 1583640059,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1583640060,
		'to' => 1604199659,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1604199660,
		'to' => 1615694459,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1615694460,
		'to' => 1636254059,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1636254060,
		'to' => 1647144059,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1647144060,
		'to' => 1667703659,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1667703660,
		'to' => 1678593659,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1678593660,
		'to' => 1699153259,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1699153260,
		'to' => 1710043259,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1710043260,
		'to' => 1730602859,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1730602860,
		'to' => 1741492859,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1741492860,
		'to' => 1762052459,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1762052460,
		'to' => 1772942459,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1772942460,
		'to' => 1793502059,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1793502060,
		'to' => 1804996859,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1804996860,
		'to' => 1825556459,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1825556460,
		'to' => 1836446459,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1836446460,
		'to' => 1857006059,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1857006060,
		'to' => 1867896059,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1867896060,
		'to' => 1888455659,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1888455660,
		'to' => 1899345659,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1899345660,
		'to' => 1919905259,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1919905260,
		'to' => 1930795259,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1930795260,
		'to' => 1951354859,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1951354860,
		'to' => 1962849659,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1962849660,
		'to' => 1983409259,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 1983409260,
		'to' => 1994299259,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1994299260,
		'to' => 2014858859,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 2014858860,
		'to' => 2025748859,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 2025748860,
		'to' => 2046308459,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 2046308460,
		'to' => 2057198459,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 2057198460,
		'to' => 2077758059,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 2077758060,
		'to' => 2088648059,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 2088648060,
		'to' => 2109207659,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 2109207660,
		'to' => 2120097659,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 2120097660,
		'to' => 2140657259,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 2140657260,
		'to' => 2147483647,
		'offset' => -14400,
		'dst' => false
	)
);
