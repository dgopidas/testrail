<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 9971999,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 9972000,
		'to' => 25693199,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 25693200,
		'to' => 41421599,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 41421600,
		'to' => 57747599,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 57747600,
		'to' => 73475999,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 73476000,
		'to' => 89197199,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 89197200,
		'to' => 104925599,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 104925600,
		'to' => 120646799,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 120646800,
		'to' => 126698399,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 126698400,
		'to' => 152096399,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 152096400,
		'to' => 162381599,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 162381600,
		'to' => 183545999,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 183546000,
		'to' => 199274399,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 199274400,
		'to' => 215600399,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 215600400,
		'to' => 230723999,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 230724000,
		'to' => 247049999,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 247050000,
		'to' => 262778399,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 262778400,
		'to' => 278499599,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 278499600,
		'to' => 294227999,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 294228000,
		'to' => 309949199,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 309949200,
		'to' => 325677599,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 325677600,
		'to' => 341398799,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 341398800,
		'to' => 357127199,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 357127200,
		'to' => 372848399,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 372848400,
		'to' => 388576799,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 388576800,
		'to' => 404902799,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 404902800,
		'to' => 420026399,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 420026400,
		'to' => 436352399,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 436352400,
		'to' => 452080799,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 452080800,
		'to' => 467801999,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 467802000,
		'to' => 483530399,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 483530400,
		'to' => 499251599,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 499251600,
		'to' => 514979999,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 514980000,
		'to' => 530701199,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 530701200,
		'to' => 544615199,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 544615200,
		'to' => 562150799,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 562150800,
		'to' => 576064799,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 576064800,
		'to' => 594205199,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 594205200,
		'to' => 607514399,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 607514400,
		'to' => 625654799,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 625654800,
		'to' => 638963999,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 638964000,
		'to' => 657104399,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 657104400,
		'to' => 671018399,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 671018400,
		'to' => 688553999,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 688554000,
		'to' => 702467999,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 702468000,
		'to' => 720003599,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 720003600,
		'to' => 733917599,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 733917600,
		'to' => 752057999,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 752058000,
		'to' => 765367199,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 765367200,
		'to' => 783507599,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 783507600,
		'to' => 796816799,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 796816800,
		'to' => 814957199,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 814957200,
		'to' => 828871199,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 828871200,
		'to' => 846406799,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 846406800,
		'to' => 860320799,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 860320800,
		'to' => 877856399,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 877856400,
		'to' => 891770399,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 891770400,
		'to' => 909305999,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 909306000,
		'to' => 923219999,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 923220000,
		'to' => 941360399,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 941360400,
		'to' => 954669599,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 954669600,
		'to' => 972809999,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 972810000,
		'to' => 986119199,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 986119200,
		'to' => 1004259599,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1004259600,
		'to' => 1018173599,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1018173600,
		'to' => 1035709199,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1035709200,
		'to' => 1049623199,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1049623200,
		'to' => 1067158799,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1067158800,
		'to' => 1081072799,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1081072800,
		'to' => 1099213199,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1099213200,
		'to' => 1112522399,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1112522400,
		'to' => 1130662799,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1130662800,
		'to' => 1143971999,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1143972000,
		'to' => 1162112399,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1162112400,
		'to' => 1173607199,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1173607200,
		'to' => 1194166799,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1194166800,
		'to' => 1205056799,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1205056800,
		'to' => 1225616399,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1225616400,
		'to' => 1236506399,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1236506400,
		'to' => 1257065999,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1257066000,
		'to' => 1268560799,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1268560800,
		'to' => 1289120399,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1289120400,
		'to' => 1300010399,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1300010400,
		'to' => 1320569999,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1320570000,
		'to' => 1331459999,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1331460000,
		'to' => 1352019599,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1352019600,
		'to' => 1362909599,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1362909600,
		'to' => 1383469199,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1383469200,
		'to' => 1394359199,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1394359200,
		'to' => 1414918799,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1414918800,
		'to' => 1425808799,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1425808800,
		'to' => 1446368399,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1446368400,
		'to' => 1457863199,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1457863200,
		'to' => 1478422799,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1478422800,
		'to' => 1489312799,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1489312800,
		'to' => 1509872399,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1509872400,
		'to' => 1520762399,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1520762400,
		'to' => 1541321999,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1541322000,
		'to' => 1552211999,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1552212000,
		'to' => 1572771599,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1572771600,
		'to' => 1583661599,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1583661600,
		'to' => 1604221199,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1604221200,
		'to' => 1615715999,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1615716000,
		'to' => 1636275599,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1636275600,
		'to' => 1647165599,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1647165600,
		'to' => 1667725199,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1667725200,
		'to' => 1678615199,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1678615200,
		'to' => 1699174799,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1699174800,
		'to' => 1710064799,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1710064800,
		'to' => 1730624399,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1730624400,
		'to' => 1741514399,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1741514400,
		'to' => 1762073999,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1762074000,
		'to' => 1772963999,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1772964000,
		'to' => 1793523599,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1793523600,
		'to' => 1805018399,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1805018400,
		'to' => 1825577999,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1825578000,
		'to' => 1836467999,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1836468000,
		'to' => 1857027599,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1857027600,
		'to' => 1867917599,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1867917600,
		'to' => 1888477199,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1888477200,
		'to' => 1899367199,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1899367200,
		'to' => 1919926799,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1919926800,
		'to' => 1930816799,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1930816800,
		'to' => 1951376399,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1951376400,
		'to' => 1962871199,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1962871200,
		'to' => 1983430799,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 1983430800,
		'to' => 1994320799,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 1994320800,
		'to' => 2014880399,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 2014880400,
		'to' => 2025770399,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 2025770400,
		'to' => 2046329999,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 2046330000,
		'to' => 2057219999,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 2057220000,
		'to' => 2077779599,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 2077779600,
		'to' => 2088669599,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 2088669600,
		'to' => 2109229199,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 2109229200,
		'to' => 2120119199,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 2120119200,
		'to' => 2140678799,
		'offset' => -25200,
		'dst' => true
	),
	array(
		'from' => 2140678800,
		'to' => 2147483647,
		'offset' => -28800,
		'dst' => false
	)
);
