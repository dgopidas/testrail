<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 4422599,
		'offset' => -16200,
		'dst' => true
	),
	array(
		'from' => 4422600,
		'to' => 25678799,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 25678800,
		'to' => 33193799,
		'offset' => -16200,
		'dst' => true
	),
	array(
		'from' => 33193800,
		'to' => 57733199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 57733200,
		'to' => 64816199,
		'offset' => -16200,
		'dst' => true
	),
	array(
		'from' => 64816200,
		'to' => 89182799,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 89182800,
		'to' => 96438599,
		'offset' => -16200,
		'dst' => true
	),
	array(
		'from' => 96438600,
		'to' => 120632399,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 120632400,
		'to' => 127974599,
		'offset' => -16200,
		'dst' => true
	),
	array(
		'from' => 127974600,
		'to' => 152081999,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 152082000,
		'to' => 972799199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 972799200,
		'to' => 975823199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 975823200,
		'to' => 2147483647,
		'offset' => -14400,
		'dst' => false
	)
);
