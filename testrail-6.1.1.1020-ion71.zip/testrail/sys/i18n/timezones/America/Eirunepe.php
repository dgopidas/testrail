<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 499755599,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 499755600,
		'to' => 511243199,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 511243200,
		'to' => 530600399,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 530600400,
		'to' => 540273599,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 540273600,
		'to' => 562136399,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 562136400,
		'to' => 571204799,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 571204800,
		'to' => 750833999,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 750834000,
		'to' => 761716799,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 761716800,
		'to' => 1214283599,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1214283600,
		'to' => 2147483647,
		'offset' => -14400,
		'dst' => false
	)
);
