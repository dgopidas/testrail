<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 123055199,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 123055200,
		'to' => 130913999,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 130914000,
		'to' => 422344799,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 422344800,
		'to' => 433054799,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 433054800,
		'to' => 669707999,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 669708000,
		'to' => 684219599,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 684219600,
		'to' => 1146376799,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1146376800,
		'to' => 1159678799,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1159678800,
		'to' => 2147483647,
		'offset' => -21600,
		'dst' => false
	)
);
