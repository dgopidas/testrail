<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 323841599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 323841600,
		'to' => 338957999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 338958000,
		'to' => 2147483647,
		'offset' => -14400,
		'dst' => false
	)
);
