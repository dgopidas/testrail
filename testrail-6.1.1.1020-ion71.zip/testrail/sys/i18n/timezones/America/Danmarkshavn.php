<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 323845199,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 323845200,
		'to' => 338950799,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 338950800,
		'to' => 354675599,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 354675600,
		'to' => 370400399,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 370400400,
		'to' => 386125199,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 386125200,
		'to' => 401849999,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 401850000,
		'to' => 417574799,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 417574800,
		'to' => 433299599,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 433299600,
		'to' => 449024399,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 449024400,
		'to' => 465353999,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 465354000,
		'to' => 481078799,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 481078800,
		'to' => 496803599,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 496803600,
		'to' => 512528399,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 512528400,
		'to' => 528253199,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 528253200,
		'to' => 543977999,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 543978000,
		'to' => 559702799,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 559702800,
		'to' => 575427599,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 575427600,
		'to' => 591152399,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 591152400,
		'to' => 606877199,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 606877200,
		'to' => 622601999,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 622602000,
		'to' => 638326799,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 638326800,
		'to' => 654656399,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 654656400,
		'to' => 670381199,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 670381200,
		'to' => 686105999,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 686106000,
		'to' => 701830799,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 701830800,
		'to' => 717555599,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 717555600,
		'to' => 733280399,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 733280400,
		'to' => 749005199,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 749005200,
		'to' => 764729999,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 764730000,
		'to' => 780454799,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 780454800,
		'to' => 796179599,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 796179600,
		'to' => 811904399,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 811904400,
		'to' => 820465199,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 820465200,
		'to' => 2147483647,
		'offset' => 0,
		'dst' => false
	)
);
