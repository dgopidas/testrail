<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 377935199,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 377935200,
		'to' => 828860399,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 828860400,
		'to' => 846395999,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 846396000,
		'to' => 860309999,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 860310000,
		'to' => 877845599,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 877845600,
		'to' => 891759599,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 891759600,
		'to' => 902037599,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 902037600,
		'to' => 909298799,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 909298800,
		'to' => 923212799,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 923212800,
		'to' => 941353199,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 941353200,
		'to' => 954662399,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 954662400,
		'to' => 972802799,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 972802800,
		'to' => 989135999,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 989136000,
		'to' => 1001833199,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1001833200,
		'to' => 1018166399,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1018166400,
		'to' => 1035701999,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1035702000,
		'to' => 1049615999,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1049616000,
		'to' => 1067151599,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1067151600,
		'to' => 1081065599,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1081065600,
		'to' => 1099205999,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1099206000,
		'to' => 1112515199,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1112515200,
		'to' => 1130655599,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1130655600,
		'to' => 1143964799,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1143964800,
		'to' => 1162105199,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1162105200,
		'to' => 1175414399,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1175414400,
		'to' => 1193554799,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1193554800,
		'to' => 1207468799,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1207468800,
		'to' => 1225004399,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1225004400,
		'to' => 1238918399,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1238918400,
		'to' => 1256453999,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1256454000,
		'to' => 1270367999,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1270368000,
		'to' => 1288508399,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1288508400,
		'to' => 1301817599,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1301817600,
		'to' => 1319957999,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1319958000,
		'to' => 1333267199,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1333267200,
		'to' => 1351407599,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1351407600,
		'to' => 1365321599,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1365321600,
		'to' => 1382857199,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1382857200,
		'to' => 1396771199,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1396771200,
		'to' => 1414306799,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1414306800,
		'to' => 1428220799,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1428220800,
		'to' => 1445756399,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1445756400,
		'to' => 1459670399,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1459670400,
		'to' => 1477810799,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1477810800,
		'to' => 1491119999,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1491120000,
		'to' => 1509260399,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1509260400,
		'to' => 1522569599,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1522569600,
		'to' => 1540709999,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1540710000,
		'to' => 1554623999,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1554624000,
		'to' => 1572159599,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1572159600,
		'to' => 1586073599,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1586073600,
		'to' => 1603609199,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1603609200,
		'to' => 1617523199,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1617523200,
		'to' => 1635663599,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1635663600,
		'to' => 1648972799,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1648972800,
		'to' => 1667113199,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1667113200,
		'to' => 1680422399,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1680422400,
		'to' => 1698562799,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1698562800,
		'to' => 1712476799,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1712476800,
		'to' => 1730012399,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1730012400,
		'to' => 1743926399,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1743926400,
		'to' => 1761461999,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1761462000,
		'to' => 1775375999,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1775376000,
		'to' => 1792911599,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1792911600,
		'to' => 1806825599,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1806825600,
		'to' => 1824965999,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1824966000,
		'to' => 1838275199,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1838275200,
		'to' => 1856415599,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1856415600,
		'to' => 1869724799,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1869724800,
		'to' => 1887865199,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1887865200,
		'to' => 1901779199,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1901779200,
		'to' => 1919314799,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1919314800,
		'to' => 1933228799,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1933228800,
		'to' => 1950764399,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1950764400,
		'to' => 1964678399,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1964678400,
		'to' => 1982818799,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1982818800,
		'to' => 1996127999,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1996128000,
		'to' => 2014268399,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 2014268400,
		'to' => 2027577599,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 2027577600,
		'to' => 2045717999,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 2045718000,
		'to' => 2059027199,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 2059027200,
		'to' => 2077167599,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 2077167600,
		'to' => 2091081599,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 2091081600,
		'to' => 2108617199,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 2108617200,
		'to' => 2122531199,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 2122531200,
		'to' => 2140066799,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 2140066800,
		'to' => 2147483647,
		'offset' => -21600,
		'dst' => false
	)
);
