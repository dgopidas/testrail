<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 499748399,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 499748400,
		'to' => 511235999,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 511236000,
		'to' => 530593199,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 530593200,
		'to' => 540266399,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 540266400,
		'to' => 562129199,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 562129200,
		'to' => 571197599,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 571197600,
		'to' => 2147483647,
		'offset' => -10800,
		'dst' => false
	)
);
