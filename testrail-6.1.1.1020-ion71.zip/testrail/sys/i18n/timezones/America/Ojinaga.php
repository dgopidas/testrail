<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 828863999,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 828864000,
		'to' => 846399599,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 846399600,
		'to' => 860313599,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 860313600,
		'to' => 877849199,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 877849200,
		'to' => 891766799,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 891766800,
		'to' => 909302399,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 909302400,
		'to' => 923216399,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 923216400,
		'to' => 941356799,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 941356800,
		'to' => 954665999,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 954666000,
		'to' => 972806399,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 972806400,
		'to' => 989139599,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 989139600,
		'to' => 1001836799,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1001836800,
		'to' => 1018169999,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1018170000,
		'to' => 1035705599,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1035705600,
		'to' => 1049619599,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1049619600,
		'to' => 1067155199,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1067155200,
		'to' => 1081069199,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1081069200,
		'to' => 1099209599,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1099209600,
		'to' => 1112518799,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1112518800,
		'to' => 1130659199,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1130659200,
		'to' => 1143968399,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1143968400,
		'to' => 1162108799,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1162108800,
		'to' => 1175417999,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1175418000,
		'to' => 1193558399,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1193558400,
		'to' => 1207472399,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1207472400,
		'to' => 1225007999,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1225008000,
		'to' => 1238921999,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1238922000,
		'to' => 1256457599,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1256457600,
		'to' => 1268557199,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1268557200,
		'to' => 1289116799,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1289116800,
		'to' => 1300006799,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1300006800,
		'to' => 1320566399,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1320566400,
		'to' => 1331456399,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1331456400,
		'to' => 1352015999,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1352016000,
		'to' => 1362905999,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1362906000,
		'to' => 1383465599,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1383465600,
		'to' => 1394355599,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1394355600,
		'to' => 1414915199,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1414915200,
		'to' => 1425805199,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1425805200,
		'to' => 1446364799,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1446364800,
		'to' => 1457859599,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1457859600,
		'to' => 1478419199,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1478419200,
		'to' => 1489309199,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1489309200,
		'to' => 1509868799,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1509868800,
		'to' => 1520758799,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1520758800,
		'to' => 1541318399,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1541318400,
		'to' => 1552208399,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1552208400,
		'to' => 1572767999,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1572768000,
		'to' => 1583657999,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1583658000,
		'to' => 1604217599,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1604217600,
		'to' => 1615712399,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1615712400,
		'to' => 1636271999,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1636272000,
		'to' => 1647161999,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1647162000,
		'to' => 1667721599,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1667721600,
		'to' => 1678611599,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1678611600,
		'to' => 1699171199,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1699171200,
		'to' => 1710061199,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1710061200,
		'to' => 1730620799,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1730620800,
		'to' => 1741510799,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1741510800,
		'to' => 1762070399,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1762070400,
		'to' => 1772960399,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1772960400,
		'to' => 1793519999,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1793520000,
		'to' => 1805014799,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1805014800,
		'to' => 1825574399,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1825574400,
		'to' => 1836464399,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1836464400,
		'to' => 1857023999,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1857024000,
		'to' => 1867913999,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1867914000,
		'to' => 1888473599,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1888473600,
		'to' => 1899363599,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1899363600,
		'to' => 1919923199,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1919923200,
		'to' => 1930813199,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1930813200,
		'to' => 1951372799,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1951372800,
		'to' => 1962867599,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1962867600,
		'to' => 1983427199,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1983427200,
		'to' => 1994317199,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1994317200,
		'to' => 2014876799,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 2014876800,
		'to' => 2025766799,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 2025766800,
		'to' => 2046326399,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 2046326400,
		'to' => 2057216399,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 2057216400,
		'to' => 2077775999,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 2077776000,
		'to' => 2088665999,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 2088666000,
		'to' => 2109225599,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 2109225600,
		'to' => 2120115599,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 2120115600,
		'to' => 2140675199,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 2140675200,
		'to' => 2147483647,
		'offset' => -25200,
		'dst' => false
	)
);
