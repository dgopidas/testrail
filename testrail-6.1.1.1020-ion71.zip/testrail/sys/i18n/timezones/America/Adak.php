<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 9982799,
		'offset' => -39600,
		'dst' => false
	),
	array(
		'from' => 9982800,
		'to' => 25703999,
		'offset' => -36000,
		'dst' => true
	),
	array(
		'from' => 25704000,
		'to' => 41432399,
		'offset' => -39600,
		'dst' => false
	),
	array(
		'from' => 41432400,
		'to' => 57758399,
		'offset' => -36000,
		'dst' => true
	),
	array(
		'from' => 57758400,
		'to' => 73486799,
		'offset' => -39600,
		'dst' => false
	),
	array(
		'from' => 73486800,
		'to' => 89207999,
		'offset' => -36000,
		'dst' => true
	),
	array(
		'from' => 89208000,
		'to' => 104936399,
		'offset' => -39600,
		'dst' => false
	),
	array(
		'from' => 104936400,
		'to' => 120657599,
		'offset' => -36000,
		'dst' => true
	),
	array(
		'from' => 120657600,
		'to' => 126709199,
		'offset' => -39600,
		'dst' => false
	),
	array(
		'from' => 126709200,
		'to' => 152107199,
		'offset' => -36000,
		'dst' => true
	),
	array(
		'from' => 152107200,
		'to' => 162392399,
		'offset' => -39600,
		'dst' => false
	),
	array(
		'from' => 162392400,
		'to' => 183556799,
		'offset' => -36000,
		'dst' => true
	),
	array(
		'from' => 183556800,
		'to' => 199285199,
		'offset' => -39600,
		'dst' => false
	),
	array(
		'from' => 199285200,
		'to' => 215611199,
		'offset' => -36000,
		'dst' => true
	),
	array(
		'from' => 215611200,
		'to' => 230734799,
		'offset' => -39600,
		'dst' => false
	),
	array(
		'from' => 230734800,
		'to' => 247060799,
		'offset' => -36000,
		'dst' => true
	),
	array(
		'from' => 247060800,
		'to' => 262789199,
		'offset' => -39600,
		'dst' => false
	),
	array(
		'from' => 262789200,
		'to' => 278510399,
		'offset' => -36000,
		'dst' => true
	),
	array(
		'from' => 278510400,
		'to' => 294238799,
		'offset' => -39600,
		'dst' => false
	),
	array(
		'from' => 294238800,
		'to' => 309959999,
		'offset' => -36000,
		'dst' => true
	),
	array(
		'from' => 309960000,
		'to' => 325688399,
		'offset' => -39600,
		'dst' => false
	),
	array(
		'from' => 325688400,
		'to' => 341409599,
		'offset' => -36000,
		'dst' => true
	),
	array(
		'from' => 341409600,
		'to' => 357137999,
		'offset' => -39600,
		'dst' => false
	),
	array(
		'from' => 357138000,
		'to' => 372859199,
		'offset' => -36000,
		'dst' => true
	),
	array(
		'from' => 372859200,
		'to' => 388587599,
		'offset' => -39600,
		'dst' => false
	),
	array(
		'from' => 388587600,
		'to' => 404913599,
		'offset' => -36000,
		'dst' => true
	),
	array(
		'from' => 404913600,
		'to' => 420037199,
		'offset' => -39600,
		'dst' => false
	),
	array(
		'from' => 420037200,
		'to' => 436363199,
		'offset' => -36000,
		'dst' => true
	),
	array(
		'from' => 436363200,
		'to' => 439034399,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 439034400,
		'to' => 452087999,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 452088000,
		'to' => 467809199,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 467809200,
		'to' => 483537599,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 483537600,
		'to' => 499258799,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 499258800,
		'to' => 514987199,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 514987200,
		'to' => 530708399,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 530708400,
		'to' => 544622399,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 544622400,
		'to' => 562157999,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 562158000,
		'to' => 576071999,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 576072000,
		'to' => 594212399,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 594212400,
		'to' => 607521599,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 607521600,
		'to' => 625661999,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 625662000,
		'to' => 638971199,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 638971200,
		'to' => 657111599,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 657111600,
		'to' => 671025599,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 671025600,
		'to' => 688561199,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 688561200,
		'to' => 702475199,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 702475200,
		'to' => 720010799,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 720010800,
		'to' => 733924799,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 733924800,
		'to' => 752065199,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 752065200,
		'to' => 765374399,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 765374400,
		'to' => 783514799,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 783514800,
		'to' => 796823999,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 796824000,
		'to' => 814964399,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 814964400,
		'to' => 828878399,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 828878400,
		'to' => 846413999,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 846414000,
		'to' => 860327999,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 860328000,
		'to' => 877863599,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 877863600,
		'to' => 891777599,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 891777600,
		'to' => 909313199,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 909313200,
		'to' => 923227199,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 923227200,
		'to' => 941367599,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 941367600,
		'to' => 954676799,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 954676800,
		'to' => 972817199,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 972817200,
		'to' => 986126399,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 986126400,
		'to' => 1004266799,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 1004266800,
		'to' => 1018180799,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 1018180800,
		'to' => 1035716399,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 1035716400,
		'to' => 1049630399,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 1049630400,
		'to' => 1067165999,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 1067166000,
		'to' => 1081079999,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 1081080000,
		'to' => 1099220399,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 1099220400,
		'to' => 1112529599,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 1112529600,
		'to' => 1130669999,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 1130670000,
		'to' => 1143979199,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 1143979200,
		'to' => 1162119599,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 1162119600,
		'to' => 1173614399,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 1173614400,
		'to' => 1194173999,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 1194174000,
		'to' => 1205063999,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 1205064000,
		'to' => 1225623599,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 1225623600,
		'to' => 1236513599,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 1236513600,
		'to' => 1257073199,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 1257073200,
		'to' => 1268567999,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 1268568000,
		'to' => 1289127599,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 1289127600,
		'to' => 1300017599,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 1300017600,
		'to' => 1320577199,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 1320577200,
		'to' => 1331467199,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 1331467200,
		'to' => 1352026799,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 1352026800,
		'to' => 1362916799,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 1362916800,
		'to' => 1383476399,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 1383476400,
		'to' => 1394366399,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 1394366400,
		'to' => 1414925999,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 1414926000,
		'to' => 1425815999,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 1425816000,
		'to' => 1446375599,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 1446375600,
		'to' => 1457870399,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 1457870400,
		'to' => 1478429999,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 1478430000,
		'to' => 1489319999,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 1489320000,
		'to' => 1509879599,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 1509879600,
		'to' => 1520769599,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 1520769600,
		'to' => 1541329199,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 1541329200,
		'to' => 1552219199,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 1552219200,
		'to' => 1572778799,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 1572778800,
		'to' => 1583668799,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 1583668800,
		'to' => 1604228399,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 1604228400,
		'to' => 1615723199,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 1615723200,
		'to' => 1636282799,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 1636282800,
		'to' => 1647172799,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 1647172800,
		'to' => 1667732399,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 1667732400,
		'to' => 1678622399,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 1678622400,
		'to' => 1699181999,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 1699182000,
		'to' => 1710071999,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 1710072000,
		'to' => 1730631599,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 1730631600,
		'to' => 1741521599,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 1741521600,
		'to' => 1762081199,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 1762081200,
		'to' => 1772971199,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 1772971200,
		'to' => 1793530799,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 1793530800,
		'to' => 1805025599,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 1805025600,
		'to' => 1825585199,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 1825585200,
		'to' => 1836475199,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 1836475200,
		'to' => 1857034799,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 1857034800,
		'to' => 1867924799,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 1867924800,
		'to' => 1888484399,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 1888484400,
		'to' => 1899374399,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 1899374400,
		'to' => 1919933999,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 1919934000,
		'to' => 1930823999,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 1930824000,
		'to' => 1951383599,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 1951383600,
		'to' => 1962878399,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 1962878400,
		'to' => 1983437999,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 1983438000,
		'to' => 1994327999,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 1994328000,
		'to' => 2014887599,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 2014887600,
		'to' => 2025777599,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 2025777600,
		'to' => 2046337199,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 2046337200,
		'to' => 2057227199,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 2057227200,
		'to' => 2077786799,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 2077786800,
		'to' => 2088676799,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 2088676800,
		'to' => 2109236399,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 2109236400,
		'to' => 2120126399,
		'offset' => -36000,
		'dst' => false
	),
	array(
		'from' => 2120126400,
		'to' => 2140685999,
		'offset' => -32400,
		'dst' => true
	),
	array(
		'from' => 2140686000,
		'to' => 2147483647,
		'offset' => -36000,
		'dst' => false
	)
);
