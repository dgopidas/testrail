<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 128141999,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 128142000,
		'to' => 136605599,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 136605600,
		'to' => 596948399,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 596948400,
		'to' => 605066399,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 605066400,
		'to' => 624423599,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 624423600,
		'to' => 636515999,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 636516000,
		'to' => 656477999,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 656478000,
		'to' => 667965599,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 667965600,
		'to' => 687931199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 687931200,
		'to' => 699415199,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 699415200,
		'to' => 719377199,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 719377200,
		'to' => 731469599,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 731469600,
		'to' => 938919599,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 938919600,
		'to' => 952052399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 952052400,
		'to' => 1086058799,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1086058800,
		'to' => 1087099199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1087099200,
		'to' => 1198983599,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1198983600,
		'to' => 1205632799,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1205632800,
		'to' => 1224385199,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1224385200,
		'to' => 1237082399,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1237082400,
		'to' => 2147483647,
		'offset' => -10800,
		'dst' => false
	)
);
