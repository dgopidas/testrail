<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 234943199,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 234943200,
		'to' => 244616399,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 244616400,
		'to' => 261554399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 261554400,
		'to' => 276065999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 276066000,
		'to' => 293003999,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 293004000,
		'to' => 307515599,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 307515600,
		'to' => 325058399,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 325058400,
		'to' => 338705999,
		'offset' => -10800,
		'dst' => true
	),
	array(
		'from' => 338706000,
		'to' => 2147483647,
		'offset' => -14400,
		'dst' => false
	)
);
