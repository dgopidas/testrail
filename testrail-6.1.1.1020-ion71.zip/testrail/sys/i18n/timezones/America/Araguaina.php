<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 499748399,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 499748400,
		'to' => 511235999,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 511236000,
		'to' => 530593199,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 530593200,
		'to' => 540266399,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 540266400,
		'to' => 562129199,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 562129200,
		'to' => 571197599,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 571197600,
		'to' => 592973999,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 592974000,
		'to' => 602042399,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 602042400,
		'to' => 624423599,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 624423600,
		'to' => 634701599,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 634701600,
		'to' => 813725999,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 813726000,
		'to' => 824003999,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 824004000,
		'to' => 844570799,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 844570800,
		'to' => 856058399,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 856058400,
		'to' => 876106799,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 876106800,
		'to' => 888717599,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 888717600,
		'to' => 908074799,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 908074800,
		'to' => 919562399,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 919562400,
		'to' => 938919599,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 938919600,
		'to' => 951616799,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 951616800,
		'to' => 970973999,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 970974000,
		'to' => 982461599,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 982461600,
		'to' => 1003028399,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1003028400,
		'to' => 1013911199,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1013911200,
		'to' => 1036292399,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1036292400,
		'to' => 1045360799,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1045360800,
		'to' => 2147483647,
		'offset' => -10800,
		'dst' => false
	)
);
