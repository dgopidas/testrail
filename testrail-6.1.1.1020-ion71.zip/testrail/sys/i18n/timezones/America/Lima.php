<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 504939599,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 504939600,
		'to' => 512711999,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 512712000,
		'to' => 536475599,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 536475600,
		'to' => 544247999,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 544248000,
		'to' => 631169999,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 631170000,
		'to' => 638942399,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 638942400,
		'to' => 757400399,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 757400400,
		'to' => 765172799,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 765172800,
		'to' => 2147483647,
		'offset' => -18000,
		'dst' => false
	)
);
