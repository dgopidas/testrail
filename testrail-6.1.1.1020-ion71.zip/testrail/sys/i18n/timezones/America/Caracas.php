<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 1197183599,
		'offset' => -14400,
		'dst' => false
	),
	array(
		'from' => 1197183600,
		'to' => 2147483647,
		'offset' => -16200,
		'dst' => false
	)
);
