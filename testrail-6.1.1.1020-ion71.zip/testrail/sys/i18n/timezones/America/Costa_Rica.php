<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 288770399,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 288770400,
		'to' => 297233999,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 297234000,
		'to' => 320219999,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 320220000,
		'to' => 328683599,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 328683600,
		'to' => 664264799,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 664264800,
		'to' => 678344399,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 678344400,
		'to' => 695714399,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 695714400,
		'to' => 700635599,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 700635600,
		'to' => 2147483647,
		'offset' => -21600,
		'dst' => false
	)
);
