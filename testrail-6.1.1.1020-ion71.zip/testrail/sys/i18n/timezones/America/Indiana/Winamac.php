<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 9961199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 9961200,
		'to' => 25682399,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 25682400,
		'to' => 1143961199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1143961200,
		'to' => 1162105199,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1162105200,
		'to' => 1173599999,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1173600000,
		'to' => 1194155999,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1194156000,
		'to' => 1205045999,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1205046000,
		'to' => 1225605599,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1225605600,
		'to' => 1236495599,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1236495600,
		'to' => 1257055199,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1257055200,
		'to' => 1268549999,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1268550000,
		'to' => 1289109599,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1289109600,
		'to' => 1299999599,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1299999600,
		'to' => 1320559199,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1320559200,
		'to' => 1331449199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1331449200,
		'to' => 1352008799,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1352008800,
		'to' => 1362898799,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1362898800,
		'to' => 1383458399,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1383458400,
		'to' => 1394348399,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1394348400,
		'to' => 1414907999,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1414908000,
		'to' => 1425797999,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1425798000,
		'to' => 1446357599,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1446357600,
		'to' => 1457852399,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1457852400,
		'to' => 1478411999,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1478412000,
		'to' => 1489301999,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1489302000,
		'to' => 1509861599,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1509861600,
		'to' => 1520751599,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1520751600,
		'to' => 1541311199,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1541311200,
		'to' => 1552201199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1552201200,
		'to' => 1572760799,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1572760800,
		'to' => 1583650799,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1583650800,
		'to' => 1604210399,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1604210400,
		'to' => 1615705199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1615705200,
		'to' => 1636264799,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1636264800,
		'to' => 1647154799,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1647154800,
		'to' => 1667714399,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1667714400,
		'to' => 1678604399,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1678604400,
		'to' => 1699163999,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1699164000,
		'to' => 1710053999,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1710054000,
		'to' => 1730613599,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1730613600,
		'to' => 1741503599,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1741503600,
		'to' => 1762063199,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1762063200,
		'to' => 1772953199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1772953200,
		'to' => 1793512799,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1793512800,
		'to' => 1805007599,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1805007600,
		'to' => 1825567199,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1825567200,
		'to' => 1836457199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1836457200,
		'to' => 1857016799,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1857016800,
		'to' => 1867906799,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1867906800,
		'to' => 1888466399,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1888466400,
		'to' => 1899356399,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1899356400,
		'to' => 1919915999,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1919916000,
		'to' => 1930805999,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1930806000,
		'to' => 1951365599,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1951365600,
		'to' => 1962860399,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1962860400,
		'to' => 1983419999,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 1983420000,
		'to' => 1994309999,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 1994310000,
		'to' => 2014869599,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 2014869600,
		'to' => 2025759599,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 2025759600,
		'to' => 2046319199,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 2046319200,
		'to' => 2057209199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 2057209200,
		'to' => 2077768799,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 2077768800,
		'to' => 2088658799,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 2088658800,
		'to' => 2109218399,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 2109218400,
		'to' => 2120108399,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 2120108400,
		'to' => 2140667999,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 2140668000,
		'to' => 2147483647,
		'offset' => -18000,
		'dst' => false
	)
);
