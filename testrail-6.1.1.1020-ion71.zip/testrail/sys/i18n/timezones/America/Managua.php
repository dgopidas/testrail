<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 105083999,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 105084000,
		'to' => 161758799,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 161758800,
		'to' => 290584799,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 290584800,
		'to' => 299134799,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 299134800,
		'to' => 322034399,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 322034400,
		'to' => 330584399,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 330584400,
		'to' => 694259999,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 694260000,
		'to' => 717310799,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 717310800,
		'to' => 725867999,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 725868000,
		'to' => 852094799,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 852094800,
		'to' => 1113112799,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1113112800,
		'to' => 1128229199,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1128229200,
		'to' => 1146383999,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1146384000,
		'to' => 1159682399,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1159682400,
		'to' => 2147483647,
		'offset' => -21600,
		'dst' => false
	)
);
