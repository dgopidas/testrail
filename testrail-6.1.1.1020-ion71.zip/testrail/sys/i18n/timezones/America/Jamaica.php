<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 136364399,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 136364400,
		'to' => 152085599,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 152085600,
		'to' => 162370799,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 162370800,
		'to' => 183535199,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 183535200,
		'to' => 199263599,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 199263600,
		'to' => 215589599,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 215589600,
		'to' => 230713199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 230713200,
		'to' => 247039199,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 247039200,
		'to' => 262767599,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 262767600,
		'to' => 278488799,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 278488800,
		'to' => 294217199,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 294217200,
		'to' => 309938399,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 309938400,
		'to' => 325666799,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 325666800,
		'to' => 341387999,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 341388000,
		'to' => 357116399,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 357116400,
		'to' => 372837599,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 372837600,
		'to' => 388565999,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 388566000,
		'to' => 404891999,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 404892000,
		'to' => 420015599,
		'offset' => -18000,
		'dst' => false
	),
	array(
		'from' => 420015600,
		'to' => 436341599,
		'offset' => -14400,
		'dst' => true
	),
	array(
		'from' => 436341600,
		'to' => 2147483647,
		'offset' => -18000,
		'dst' => false
	)
);
