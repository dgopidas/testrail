<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 12625199,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 12625200,
		'to' => 28952999,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 28953000,
		'to' => 72932399,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 72932400,
		'to' => 82691999,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 82692000,
		'to' => 132116399,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 132116400,
		'to' => 156911399,
		'offset' => -9000,
		'dst' => true
	),
	array(
		'from' => 156911400,
		'to' => 212983199,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 212983200,
		'to' => 250052399,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 250052400,
		'to' => 260243999,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 260244000,
		'to' => 307594799,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 307594800,
		'to' => 325994399,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 325994400,
		'to' => 566449199,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 566449200,
		'to' => 574307999,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 574308000,
		'to' => 597812399,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 597812400,
		'to' => 605671199,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 605671200,
		'to' => 625633199,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 625633200,
		'to' => 636515999,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 636516000,
		'to' => 656477999,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 656478000,
		'to' => 667965599,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 667965600,
		'to' => 688532399,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 688532400,
		'to' => 699415199,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 699415200,
		'to' => 719377199,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 719377200,
		'to' => 730864799,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 730864800,
		'to' => 1095562799,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1095562800,
		'to' => 1111895999,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1111896000,
		'to' => 1128833999,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1128834000,
		'to' => 1142135999,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1142136000,
		'to' => 1159678799,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1159678800,
		'to' => 1173585599,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1173585600,
		'to' => 1191733199,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1191733200,
		'to' => 1205035199,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1205035200,
		'to' => 1223182799,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1223182800,
		'to' => 1236484799,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1236484800,
		'to' => 1254632399,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1254632400,
		'to' => 1268539199,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1268539200,
		'to' => 1286081999,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1286082000,
		'to' => 1299988799,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1299988800,
		'to' => 1317531599,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1317531600,
		'to' => 1331438399,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1331438400,
		'to' => 1349585999,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1349586000,
		'to' => 1362887999,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1362888000,
		'to' => 1381035599,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1381035600,
		'to' => 1394337599,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1394337600,
		'to' => 1412485199,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1412485200,
		'to' => 1425787199,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1425787200,
		'to' => 1443934799,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1443934800,
		'to' => 1457841599,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1457841600,
		'to' => 1475384399,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1475384400,
		'to' => 1489291199,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1489291200,
		'to' => 1506833999,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1506834000,
		'to' => 1520740799,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1520740800,
		'to' => 1538888399,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1538888400,
		'to' => 1552190399,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1552190400,
		'to' => 1570337999,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1570338000,
		'to' => 1583639999,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1583640000,
		'to' => 1601787599,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1601787600,
		'to' => 1615694399,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1615694400,
		'to' => 1633237199,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1633237200,
		'to' => 1647143999,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1647144000,
		'to' => 1664686799,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1664686800,
		'to' => 1678593599,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1678593600,
		'to' => 1696136399,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1696136400,
		'to' => 1710043199,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1710043200,
		'to' => 1728190799,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1728190800,
		'to' => 1741492799,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1741492800,
		'to' => 1759640399,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1759640400,
		'to' => 1772942399,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1772942400,
		'to' => 1791089999,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1791090000,
		'to' => 1804996799,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1804996800,
		'to' => 1822539599,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1822539600,
		'to' => 1836446399,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1836446400,
		'to' => 1853989199,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1853989200,
		'to' => 1867895999,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1867896000,
		'to' => 1886043599,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1886043600,
		'to' => 1899345599,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1899345600,
		'to' => 1917493199,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1917493200,
		'to' => 1930795199,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1930795200,
		'to' => 1948942799,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1948942800,
		'to' => 1962849599,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1962849600,
		'to' => 1980392399,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 1980392400,
		'to' => 1994299199,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 1994299200,
		'to' => 2011841999,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 2011842000,
		'to' => 2025748799,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 2025748800,
		'to' => 2043291599,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 2043291600,
		'to' => 2057198399,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 2057198400,
		'to' => 2075345999,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 2075346000,
		'to' => 2088647999,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 2088648000,
		'to' => 2106795599,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 2106795600,
		'to' => 2120097599,
		'offset' => -7200,
		'dst' => true
	),
	array(
		'from' => 2120097600,
		'to' => 2138245199,
		'offset' => -10800,
		'dst' => false
	),
	array(
		'from' => 2138245200,
		'to' => 2147483647,
		'offset' => -7200,
		'dst' => true
	)
);
