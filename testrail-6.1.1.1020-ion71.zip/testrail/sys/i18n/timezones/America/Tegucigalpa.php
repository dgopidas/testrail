<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 547019999,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 547020000,
		'to' => 559717199,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 559717200,
		'to' => 578469599,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 578469600,
		'to' => 591166799,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 591166800,
		'to' => 1146981599,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1146981600,
		'to' => 1154926799,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1154926800,
		'to' => 2147483647,
		'offset' => -21600,
		'dst' => false
	)
);
