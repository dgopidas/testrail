<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 828863999,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 828864000,
		'to' => 846399599,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 846399600,
		'to' => 860313599,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 860313600,
		'to' => 877849199,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 877849200,
		'to' => 891766799,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 891766800,
		'to' => 909302399,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 909302400,
		'to' => 923216399,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 923216400,
		'to' => 941356799,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 941356800,
		'to' => 954665999,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 954666000,
		'to' => 972806399,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 972806400,
		'to' => 989139599,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 989139600,
		'to' => 1001836799,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1001836800,
		'to' => 1018169999,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1018170000,
		'to' => 1035705599,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1035705600,
		'to' => 1049619599,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1049619600,
		'to' => 1067155199,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1067155200,
		'to' => 1081069199,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1081069200,
		'to' => 1099209599,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1099209600,
		'to' => 1112518799,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1112518800,
		'to' => 1130659199,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1130659200,
		'to' => 1143968399,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1143968400,
		'to' => 1162108799,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1162108800,
		'to' => 1175417999,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1175418000,
		'to' => 1193558399,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1193558400,
		'to' => 1207472399,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1207472400,
		'to' => 1225007999,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1225008000,
		'to' => 1238921999,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1238922000,
		'to' => 1256457599,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1256457600,
		'to' => 1270371599,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1270371600,
		'to' => 1288511999,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1288512000,
		'to' => 1301821199,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1301821200,
		'to' => 1319961599,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1319961600,
		'to' => 1333270799,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1333270800,
		'to' => 1351411199,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1351411200,
		'to' => 1365325199,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1365325200,
		'to' => 1382860799,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1382860800,
		'to' => 1396774799,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1396774800,
		'to' => 1414310399,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1414310400,
		'to' => 1428224399,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1428224400,
		'to' => 1445759999,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1445760000,
		'to' => 1459673999,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1459674000,
		'to' => 1477814399,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1477814400,
		'to' => 1491123599,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1491123600,
		'to' => 1509263999,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1509264000,
		'to' => 1522573199,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1522573200,
		'to' => 1540713599,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1540713600,
		'to' => 1554627599,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1554627600,
		'to' => 1572163199,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1572163200,
		'to' => 1586077199,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1586077200,
		'to' => 1603612799,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1603612800,
		'to' => 1617526799,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1617526800,
		'to' => 1635667199,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1635667200,
		'to' => 1648976399,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1648976400,
		'to' => 1667116799,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1667116800,
		'to' => 1680425999,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1680426000,
		'to' => 1698566399,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1698566400,
		'to' => 1712480399,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1712480400,
		'to' => 1730015999,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1730016000,
		'to' => 1743929999,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1743930000,
		'to' => 1761465599,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1761465600,
		'to' => 1775379599,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1775379600,
		'to' => 1792915199,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1792915200,
		'to' => 1806829199,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1806829200,
		'to' => 1824969599,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1824969600,
		'to' => 1838278799,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1838278800,
		'to' => 1856419199,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1856419200,
		'to' => 1869728399,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1869728400,
		'to' => 1887868799,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1887868800,
		'to' => 1901782799,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1901782800,
		'to' => 1919318399,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1919318400,
		'to' => 1933232399,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1933232400,
		'to' => 1950767999,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1950768000,
		'to' => 1964681999,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1964682000,
		'to' => 1982822399,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1982822400,
		'to' => 1996131599,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1996131600,
		'to' => 2014271999,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 2014272000,
		'to' => 2027581199,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 2027581200,
		'to' => 2045721599,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 2045721600,
		'to' => 2059030799,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 2059030800,
		'to' => 2077171199,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 2077171200,
		'to' => 2091085199,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 2091085200,
		'to' => 2108620799,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 2108620800,
		'to' => 2122534799,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 2122534800,
		'to' => 2140070399,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 2140070400,
		'to' => 2147483647,
		'offset' => -25200,
		'dst' => false
	)
);
