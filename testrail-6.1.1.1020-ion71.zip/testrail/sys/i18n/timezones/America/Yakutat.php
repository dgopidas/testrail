<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 9975599,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 9975600,
		'to' => 25696799,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 25696800,
		'to' => 41425199,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 41425200,
		'to' => 57751199,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 57751200,
		'to' => 73479599,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 73479600,
		'to' => 89200799,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 89200800,
		'to' => 104929199,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 104929200,
		'to' => 120650399,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 120650400,
		'to' => 126701999,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 126702000,
		'to' => 152099999,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 152100000,
		'to' => 162385199,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 162385200,
		'to' => 183549599,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 183549600,
		'to' => 199277999,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 199278000,
		'to' => 215603999,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 215604000,
		'to' => 230727599,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 230727600,
		'to' => 247053599,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 247053600,
		'to' => 262781999,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 262782000,
		'to' => 278503199,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 278503200,
		'to' => 294231599,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 294231600,
		'to' => 309952799,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 309952800,
		'to' => 325681199,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 325681200,
		'to' => 341402399,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 341402400,
		'to' => 357130799,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 357130800,
		'to' => 372851999,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 372852000,
		'to' => 388580399,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 388580400,
		'to' => 404906399,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 404906400,
		'to' => 420029999,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 420030000,
		'to' => 436355999,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 436356000,
		'to' => 439030799,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 439030800,
		'to' => 452084399,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 452084400,
		'to' => 467805599,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 467805600,
		'to' => 483533999,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 483534000,
		'to' => 499255199,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 499255200,
		'to' => 514983599,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 514983600,
		'to' => 530704799,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 530704800,
		'to' => 544618799,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 544618800,
		'to' => 562154399,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 562154400,
		'to' => 576068399,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 576068400,
		'to' => 594208799,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 594208800,
		'to' => 607517999,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 607518000,
		'to' => 625658399,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 625658400,
		'to' => 638967599,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 638967600,
		'to' => 657107999,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 657108000,
		'to' => 671021999,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 671022000,
		'to' => 688557599,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 688557600,
		'to' => 702471599,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 702471600,
		'to' => 720007199,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 720007200,
		'to' => 733921199,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 733921200,
		'to' => 752061599,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 752061600,
		'to' => 765370799,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 765370800,
		'to' => 783511199,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 783511200,
		'to' => 796820399,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 796820400,
		'to' => 814960799,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 814960800,
		'to' => 828874799,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 828874800,
		'to' => 846410399,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 846410400,
		'to' => 860324399,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 860324400,
		'to' => 877859999,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 877860000,
		'to' => 891773999,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 891774000,
		'to' => 909309599,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 909309600,
		'to' => 923223599,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 923223600,
		'to' => 941363999,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 941364000,
		'to' => 954673199,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 954673200,
		'to' => 972813599,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 972813600,
		'to' => 986122799,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 986122800,
		'to' => 1004263199,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1004263200,
		'to' => 1018177199,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1018177200,
		'to' => 1035712799,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1035712800,
		'to' => 1049626799,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1049626800,
		'to' => 1067162399,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1067162400,
		'to' => 1081076399,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1081076400,
		'to' => 1099216799,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1099216800,
		'to' => 1112525999,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1112526000,
		'to' => 1130666399,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1130666400,
		'to' => 1143975599,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1143975600,
		'to' => 1162115999,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1162116000,
		'to' => 1173610799,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1173610800,
		'to' => 1194170399,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1194170400,
		'to' => 1205060399,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1205060400,
		'to' => 1225619999,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1225620000,
		'to' => 1236509999,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1236510000,
		'to' => 1257069599,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1257069600,
		'to' => 1268564399,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1268564400,
		'to' => 1289123999,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1289124000,
		'to' => 1300013999,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1300014000,
		'to' => 1320573599,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1320573600,
		'to' => 1331463599,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1331463600,
		'to' => 1352023199,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1352023200,
		'to' => 1362913199,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1362913200,
		'to' => 1383472799,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1383472800,
		'to' => 1394362799,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1394362800,
		'to' => 1414922399,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1414922400,
		'to' => 1425812399,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1425812400,
		'to' => 1446371999,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1446372000,
		'to' => 1457866799,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1457866800,
		'to' => 1478426399,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1478426400,
		'to' => 1489316399,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1489316400,
		'to' => 1509875999,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1509876000,
		'to' => 1520765999,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1520766000,
		'to' => 1541325599,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1541325600,
		'to' => 1552215599,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1552215600,
		'to' => 1572775199,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1572775200,
		'to' => 1583665199,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1583665200,
		'to' => 1604224799,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1604224800,
		'to' => 1615719599,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1615719600,
		'to' => 1636279199,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1636279200,
		'to' => 1647169199,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1647169200,
		'to' => 1667728799,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1667728800,
		'to' => 1678618799,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1678618800,
		'to' => 1699178399,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1699178400,
		'to' => 1710068399,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1710068400,
		'to' => 1730627999,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1730628000,
		'to' => 1741517999,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1741518000,
		'to' => 1762077599,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1762077600,
		'to' => 1772967599,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1772967600,
		'to' => 1793527199,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1793527200,
		'to' => 1805021999,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1805022000,
		'to' => 1825581599,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1825581600,
		'to' => 1836471599,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1836471600,
		'to' => 1857031199,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1857031200,
		'to' => 1867921199,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1867921200,
		'to' => 1888480799,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1888480800,
		'to' => 1899370799,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1899370800,
		'to' => 1919930399,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1919930400,
		'to' => 1930820399,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1930820400,
		'to' => 1951379999,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1951380000,
		'to' => 1962874799,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1962874800,
		'to' => 1983434399,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 1983434400,
		'to' => 1994324399,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 1994324400,
		'to' => 2014883999,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 2014884000,
		'to' => 2025773999,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 2025774000,
		'to' => 2046333599,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 2046333600,
		'to' => 2057223599,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 2057223600,
		'to' => 2077783199,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 2077783200,
		'to' => 2088673199,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 2088673200,
		'to' => 2109232799,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 2109232800,
		'to' => 2120122799,
		'offset' => -32400,
		'dst' => false
	),
	array(
		'from' => 2120122800,
		'to' => 2140682399,
		'offset' => -28800,
		'dst' => true
	),
	array(
		'from' => 2140682400,
		'to' => 2147483647,
		'offset' => -32400,
		'dst' => false
	)
);
