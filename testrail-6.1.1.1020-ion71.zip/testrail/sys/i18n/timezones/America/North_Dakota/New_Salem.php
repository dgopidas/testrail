<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 9968399,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 9968400,
		'to' => 25689599,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 25689600,
		'to' => 41417999,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 41418000,
		'to' => 57743999,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 57744000,
		'to' => 73472399,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 73472400,
		'to' => 89193599,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 89193600,
		'to' => 104921999,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 104922000,
		'to' => 120643199,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 120643200,
		'to' => 126694799,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 126694800,
		'to' => 152092799,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 152092800,
		'to' => 162377999,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 162378000,
		'to' => 183542399,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 183542400,
		'to' => 199270799,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 199270800,
		'to' => 215596799,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 215596800,
		'to' => 230720399,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 230720400,
		'to' => 247046399,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 247046400,
		'to' => 262774799,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 262774800,
		'to' => 278495999,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 278496000,
		'to' => 294224399,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 294224400,
		'to' => 309945599,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 309945600,
		'to' => 325673999,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 325674000,
		'to' => 341395199,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 341395200,
		'to' => 357123599,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 357123600,
		'to' => 372844799,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 372844800,
		'to' => 388573199,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 388573200,
		'to' => 404899199,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 404899200,
		'to' => 420022799,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 420022800,
		'to' => 436348799,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 436348800,
		'to' => 452077199,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 452077200,
		'to' => 467798399,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 467798400,
		'to' => 483526799,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 483526800,
		'to' => 499247999,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 499248000,
		'to' => 514976399,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 514976400,
		'to' => 530697599,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 530697600,
		'to' => 544611599,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 544611600,
		'to' => 562147199,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 562147200,
		'to' => 576061199,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 576061200,
		'to' => 594201599,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 594201600,
		'to' => 607510799,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 607510800,
		'to' => 625651199,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 625651200,
		'to' => 638960399,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 638960400,
		'to' => 657100799,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 657100800,
		'to' => 671014799,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 671014800,
		'to' => 688550399,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 688550400,
		'to' => 702464399,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 702464400,
		'to' => 719999999,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 720000000,
		'to' => 733913999,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 733914000,
		'to' => 752054399,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 752054400,
		'to' => 765363599,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 765363600,
		'to' => 783503999,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 783504000,
		'to' => 796813199,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 796813200,
		'to' => 814953599,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 814953600,
		'to' => 828867599,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 828867600,
		'to' => 846403199,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 846403200,
		'to' => 860317199,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 860317200,
		'to' => 877852799,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 877852800,
		'to' => 891766799,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 891766800,
		'to' => 909302399,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 909302400,
		'to' => 923216399,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 923216400,
		'to' => 941356799,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 941356800,
		'to' => 954665999,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 954666000,
		'to' => 972806399,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 972806400,
		'to' => 986115599,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 986115600,
		'to' => 1004255999,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1004256000,
		'to' => 1018169999,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1018170000,
		'to' => 1035705599,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1035705600,
		'to' => 1049619599,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 1049619600,
		'to' => 1067155199,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 1067155200,
		'to' => 1081065599,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1081065600,
		'to' => 1099205999,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1099206000,
		'to' => 1112515199,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1112515200,
		'to' => 1130655599,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1130655600,
		'to' => 1143964799,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1143964800,
		'to' => 1162105199,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1162105200,
		'to' => 1173599999,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1173600000,
		'to' => 1194159599,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1194159600,
		'to' => 1205049599,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1205049600,
		'to' => 1225609199,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1225609200,
		'to' => 1236499199,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1236499200,
		'to' => 1257058799,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1257058800,
		'to' => 1268553599,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1268553600,
		'to' => 1289113199,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1289113200,
		'to' => 1300003199,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1300003200,
		'to' => 1320562799,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1320562800,
		'to' => 1331452799,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1331452800,
		'to' => 1352012399,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1352012400,
		'to' => 1362902399,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1362902400,
		'to' => 1383461999,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1383462000,
		'to' => 1394351999,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1394352000,
		'to' => 1414911599,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1414911600,
		'to' => 1425801599,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1425801600,
		'to' => 1446361199,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1446361200,
		'to' => 1457855999,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1457856000,
		'to' => 1478415599,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1478415600,
		'to' => 1489305599,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1489305600,
		'to' => 1509865199,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1509865200,
		'to' => 1520755199,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1520755200,
		'to' => 1541314799,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1541314800,
		'to' => 1552204799,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1552204800,
		'to' => 1572764399,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1572764400,
		'to' => 1583654399,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1583654400,
		'to' => 1604213999,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1604214000,
		'to' => 1615708799,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1615708800,
		'to' => 1636268399,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1636268400,
		'to' => 1647158399,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1647158400,
		'to' => 1667717999,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1667718000,
		'to' => 1678607999,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1678608000,
		'to' => 1699167599,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1699167600,
		'to' => 1710057599,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1710057600,
		'to' => 1730617199,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1730617200,
		'to' => 1741507199,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1741507200,
		'to' => 1762066799,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1762066800,
		'to' => 1772956799,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1772956800,
		'to' => 1793516399,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1793516400,
		'to' => 1805011199,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1805011200,
		'to' => 1825570799,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1825570800,
		'to' => 1836460799,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1836460800,
		'to' => 1857020399,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1857020400,
		'to' => 1867910399,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1867910400,
		'to' => 1888469999,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1888470000,
		'to' => 1899359999,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1899360000,
		'to' => 1919919599,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1919919600,
		'to' => 1930809599,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1930809600,
		'to' => 1951369199,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1951369200,
		'to' => 1962863999,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1962864000,
		'to' => 1983423599,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 1983423600,
		'to' => 1994313599,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 1994313600,
		'to' => 2014873199,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 2014873200,
		'to' => 2025763199,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 2025763200,
		'to' => 2046322799,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 2046322800,
		'to' => 2057212799,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 2057212800,
		'to' => 2077772399,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 2077772400,
		'to' => 2088662399,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 2088662400,
		'to' => 2109221999,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 2109222000,
		'to' => 2120111999,
		'offset' => -21600,
		'dst' => false
	),
	array(
		'from' => 2120112000,
		'to' => 2140671599,
		'offset' => -18000,
		'dst' => true
	),
	array(
		'from' => 2140671600,
		'to' => 2147483647,
		'offset' => -21600,
		'dst' => false
	)
);
