<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 28799,
		'offset' => -28800,
		'dst' => false
	),
	array(
		'from' => 28800,
		'to' => 828867599,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 828867600,
		'to' => 846403199,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 846403200,
		'to' => 860317199,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 860317200,
		'to' => 877852799,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 877852800,
		'to' => 891766799,
		'offset' => -25200,
		'dst' => false
	),
	array(
		'from' => 891766800,
		'to' => 909302399,
		'offset' => -21600,
		'dst' => true
	),
	array(
		'from' => 909302400,
		'to' => 2147483647,
		'offset' => -25200,
		'dst' => false
	)
);
