<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 5673599,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 5673600,
		'to' => 25631999,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 25632000,
		'to' => 37727999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 37728000,
		'to' => 57686399,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 57686400,
		'to' => 67967999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 67968000,
		'to' => 89135999,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 89136000,
		'to' => 100022399,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 100022400,
		'to' => 120585599,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 120585600,
		'to' => 131471999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 131472000,
		'to' => 152035199,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 152035200,
		'to' => 162921599,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 162921600,
		'to' => 183484799,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 183484800,
		'to' => 194975999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 194976000,
		'to' => 215539199,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 215539200,
		'to' => 226425599,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 226425600,
		'to' => 246988799,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 246988800,
		'to' => 257875199,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 257875200,
		'to' => 278438399,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 278438400,
		'to' => 289324799,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 289324800,
		'to' => 309887999,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 309888000,
		'to' => 320774399,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 320774400,
		'to' => 341337599,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 341337600,
		'to' => 352223999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 352224000,
		'to' => 372787199,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 372787200,
		'to' => 386092799,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 386092800,
		'to' => 404841599,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 404841600,
		'to' => 417542399,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 417542400,
		'to' => 436291199,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 436291200,
		'to' => 447177599,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 447177600,
		'to' => 467740799,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 467740800,
		'to' => 478627199,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 478627200,
		'to' => 499190399,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 499190400,
		'to' => 510076799,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 510076800,
		'to' => 530035199,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 530035200,
		'to' => 542735999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 542736000,
		'to' => 562089599,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 562089600,
		'to' => 574790399,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 574790400,
		'to' => 594143999,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 594144000,
		'to' => 606239999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 606240000,
		'to' => 625593599,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 625593600,
		'to' => 637689599,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 637689600,
		'to' => 657043199,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 657043200,
		'to' => 670348799,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 670348800,
		'to' => 686678399,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 686678400,
		'to' => 701798399,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 701798400,
		'to' => 718127999,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 718128000,
		'to' => 733247999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 733248000,
		'to' => 749577599,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 749577600,
		'to' => 764697599,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 764697600,
		'to' => 781027199,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 781027200,
		'to' => 796147199,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 796147200,
		'to' => 812476799,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 812476800,
		'to' => 828201599,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 828201600,
		'to' => 844531199,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 844531200,
		'to' => 859651199,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 859651200,
		'to' => 875980799,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 875980800,
		'to' => 891100799,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 891100800,
		'to' => 907430399,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 907430400,
		'to' => 922550399,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 922550400,
		'to' => 938879999,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 938880000,
		'to' => 953999999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 954000000,
		'to' => 967305599,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 967305600,
		'to' => 985449599,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 985449600,
		'to' => 1002383999,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1002384000,
		'to' => 1017503999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1017504000,
		'to' => 1033833599,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1033833600,
		'to' => 1048953599,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1048953600,
		'to' => 1065283199,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1065283200,
		'to' => 1080403199,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1080403200,
		'to' => 1096732799,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1096732800,
		'to' => 1111852799,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1111852800,
		'to' => 1128182399,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1128182400,
		'to' => 1143907199,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1143907200,
		'to' => 1159631999,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1159632000,
		'to' => 1174751999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1174752000,
		'to' => 1191686399,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1191686400,
		'to' => 1207411199,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1207411200,
		'to' => 1223135999,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1223136000,
		'to' => 1238860799,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1238860800,
		'to' => 1254585599,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1254585600,
		'to' => 1270310399,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1270310400,
		'to' => 1286035199,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1286035200,
		'to' => 1301759999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1301760000,
		'to' => 1317484799,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1317484800,
		'to' => 1333209599,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1333209600,
		'to' => 1349539199,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1349539200,
		'to' => 1365263999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1365264000,
		'to' => 1380988799,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1380988800,
		'to' => 1396713599,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1396713600,
		'to' => 1412438399,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1412438400,
		'to' => 1428163199,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1428163200,
		'to' => 1443887999,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1443888000,
		'to' => 1459612799,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1459612800,
		'to' => 1475337599,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1475337600,
		'to' => 1491062399,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1491062400,
		'to' => 1506787199,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1506787200,
		'to' => 1522511999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1522512000,
		'to' => 1538841599,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1538841600,
		'to' => 1554566399,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1554566400,
		'to' => 1570291199,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1570291200,
		'to' => 1586015999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1586016000,
		'to' => 1601740799,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1601740800,
		'to' => 1617465599,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1617465600,
		'to' => 1633190399,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1633190400,
		'to' => 1648915199,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1648915200,
		'to' => 1664639999,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1664640000,
		'to' => 1680364799,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1680364800,
		'to' => 1696089599,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1696089600,
		'to' => 1712419199,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1712419200,
		'to' => 1728143999,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1728144000,
		'to' => 1743868799,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1743868800,
		'to' => 1759593599,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1759593600,
		'to' => 1775318399,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1775318400,
		'to' => 1791043199,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1791043200,
		'to' => 1806767999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1806768000,
		'to' => 1822492799,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1822492800,
		'to' => 1838217599,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1838217600,
		'to' => 1853942399,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1853942400,
		'to' => 1869667199,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1869667200,
		'to' => 1885996799,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1885996800,
		'to' => 1901721599,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1901721600,
		'to' => 1917446399,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1917446400,
		'to' => 1933171199,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1933171200,
		'to' => 1948895999,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1948896000,
		'to' => 1964620799,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1964620800,
		'to' => 1980345599,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1980345600,
		'to' => 1996070399,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1996070400,
		'to' => 2011795199,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 2011795200,
		'to' => 2027519999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 2027520000,
		'to' => 2043244799,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 2043244800,
		'to' => 2058969599,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 2058969600,
		'to' => 2075299199,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 2075299200,
		'to' => 2091023999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 2091024000,
		'to' => 2106748799,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 2106748800,
		'to' => 2122473599,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 2122473600,
		'to' => 2138198399,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 2138198400,
		'to' => 2147483647,
		'offset' => 39600,
		'dst' => true
	)
);
