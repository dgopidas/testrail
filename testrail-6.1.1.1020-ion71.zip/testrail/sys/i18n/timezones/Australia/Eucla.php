<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 152039699,
		'offset' => 31500,
		'dst' => false
	),
	array(
		'from' => 152039700,
		'to' => 162926099,
		'offset' => 35100,
		'dst' => true
	),
	array(
		'from' => 162926100,
		'to' => 436295699,
		'offset' => 31500,
		'dst' => false
	),
	array(
		'from' => 436295700,
		'to' => 447182099,
		'offset' => 35100,
		'dst' => true
	),
	array(
		'from' => 447182100,
		'to' => 690311699,
		'offset' => 31500,
		'dst' => false
	),
	array(
		'from' => 690311700,
		'to' => 699383699,
		'offset' => 35100,
		'dst' => true
	),
	array(
		'from' => 699383700,
		'to' => 1165079699,
		'offset' => 31500,
		'dst' => false
	),
	array(
		'from' => 1165079700,
		'to' => 1174756499,
		'offset' => 35100,
		'dst' => true
	),
	array(
		'from' => 1174756500,
		'to' => 1193505299,
		'offset' => 31500,
		'dst' => false
	),
	array(
		'from' => 1193505300,
		'to' => 1206810899,
		'offset' => 35100,
		'dst' => true
	),
	array(
		'from' => 1206810900,
		'to' => 1224954899,
		'offset' => 31500,
		'dst' => false
	),
	array(
		'from' => 1224954900,
		'to' => 1238260499,
		'offset' => 35100,
		'dst' => true
	),
	array(
		'from' => 1238260500,
		'to' => 2147483647,
		'offset' => 31500,
		'dst' => false
	)
);
