<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 352216800,
		'to' => 372785399,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 372785400,
		'to' => 384272999,
		'offset' => 41400,
		'dst' => true
	),
	array(
		'from' => 384273000,
		'to' => 404839799,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 404839800,
		'to' => 415722599,
		'offset' => 41400,
		'dst' => true
	),
	array(
		'from' => 415722600,
		'to' => 436289399,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 436289400,
		'to' => 447172199,
		'offset' => 41400,
		'dst' => true
	),
	array(
		'from' => 447172200,
		'to' => 467738999,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 467739000,
		'to' => 478621799,
		'offset' => 41400,
		'dst' => true
	),
	array(
		'from' => 478621800,
		'to' => 499188599,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 499188600,
		'to' => 511282799,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 511282800,
		'to' => 530033399,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 530033400,
		'to' => 542732399,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 542732400,
		'to' => 562087799,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 562087800,
		'to' => 574786799,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 574786800,
		'to' => 594142199,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 594142200,
		'to' => 606236399,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 606236400,
		'to' => 625591799,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 625591800,
		'to' => 636476399,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 636476400,
		'to' => 657041399,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 657041400,
		'to' => 667925999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 667926000,
		'to' => 688490999,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 688491000,
		'to' => 699375599,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 699375600,
		'to' => 719940599,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 719940600,
		'to' => 731429999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 731430000,
		'to' => 751994999,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 751995000,
		'to' => 762879599,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 762879600,
		'to' => 783444599,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 783444600,
		'to' => 794329199,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 794329200,
		'to' => 814894199,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 814894200,
		'to' => 828197999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 828198000,
		'to' => 846343799,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 846343800,
		'to' => 859647599,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 859647600,
		'to' => 877793399,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 877793400,
		'to' => 891097199,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 891097200,
		'to' => 909242999,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 909243000,
		'to' => 922546799,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 922546800,
		'to' => 941297399,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 941297400,
		'to' => 953996399,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 953996400,
		'to' => 967303799,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 967303800,
		'to' => 985445999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 985446000,
		'to' => 1004196599,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 1004196600,
		'to' => 1017500399,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1017500400,
		'to' => 1035646199,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 1035646200,
		'to' => 1048949999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1048950000,
		'to' => 1067095799,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 1067095800,
		'to' => 1080399599,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1080399600,
		'to' => 1099150199,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 1099150200,
		'to' => 1111849199,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1111849200,
		'to' => 1130599799,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 1130599800,
		'to' => 1143903599,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1143903600,
		'to' => 1162049399,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 1162049400,
		'to' => 1174748399,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1174748400,
		'to' => 1193498999,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 1193499000,
		'to' => 1207407599,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1207407600,
		'to' => 1223134199,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 1223134200,
		'to' => 1238857199,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1238857200,
		'to' => 1254583799,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 1254583800,
		'to' => 1270306799,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1270306800,
		'to' => 1286033399,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 1286033400,
		'to' => 1301756399,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1301756400,
		'to' => 1317482999,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 1317483000,
		'to' => 1333205999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1333206000,
		'to' => 1349537399,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 1349537400,
		'to' => 1365260399,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1365260400,
		'to' => 1380986999,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 1380987000,
		'to' => 1396709999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1396710000,
		'to' => 1412436599,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 1412436600,
		'to' => 1428159599,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1428159600,
		'to' => 1443886199,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 1443886200,
		'to' => 1459609199,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1459609200,
		'to' => 1475335799,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 1475335800,
		'to' => 1491058799,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1491058800,
		'to' => 1506785399,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 1506785400,
		'to' => 1522508399,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1522508400,
		'to' => 1538839799,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 1538839800,
		'to' => 1554562799,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1554562800,
		'to' => 1570289399,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 1570289400,
		'to' => 1586012399,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1586012400,
		'to' => 1601738999,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 1601739000,
		'to' => 1617461999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1617462000,
		'to' => 1633188599,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 1633188600,
		'to' => 1648911599,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1648911600,
		'to' => 1664638199,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 1664638200,
		'to' => 1680361199,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1680361200,
		'to' => 1696087799,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 1696087800,
		'to' => 1712415599,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1712415600,
		'to' => 1728142199,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 1728142200,
		'to' => 1743865199,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1743865200,
		'to' => 1759591799,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 1759591800,
		'to' => 1775314799,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1775314800,
		'to' => 1791041399,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 1791041400,
		'to' => 1806764399,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1806764400,
		'to' => 1822490999,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 1822491000,
		'to' => 1838213999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1838214000,
		'to' => 1853940599,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 1853940600,
		'to' => 1869663599,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1869663600,
		'to' => 1885994999,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 1885995000,
		'to' => 1901717999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1901718000,
		'to' => 1917444599,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 1917444600,
		'to' => 1933167599,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1933167600,
		'to' => 1948894199,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 1948894200,
		'to' => 1964617199,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1964617200,
		'to' => 1980343799,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 1980343800,
		'to' => 1996066799,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1996066800,
		'to' => 2011793399,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 2011793400,
		'to' => 2027516399,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 2027516400,
		'to' => 2043242999,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 2043243000,
		'to' => 2058965999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 2058966000,
		'to' => 2075297399,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 2075297400,
		'to' => 2091020399,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 2091020400,
		'to' => 2106746999,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 2106747000,
		'to' => 2122469999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 2122470000,
		'to' => 2138196599,
		'offset' => 37800,
		'dst' => false
	),
	array(
		'from' => 2138196600,
		'to' => 2147483647,
		'offset' => 39600,
		'dst' => true
	)
);
