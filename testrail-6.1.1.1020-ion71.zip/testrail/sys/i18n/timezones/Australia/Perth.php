<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 152042399,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 152042400,
		'to' => 162928799,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 162928800,
		'to' => 436298399,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 436298400,
		'to' => 447184799,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 447184800,
		'to' => 690314399,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 690314400,
		'to' => 699386399,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 699386400,
		'to' => 1165082399,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 1165082400,
		'to' => 1174759199,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 1174759200,
		'to' => 1193507999,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 1193508000,
		'to' => 1206813599,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 1206813600,
		'to' => 1224957599,
		'offset' => 28800,
		'dst' => false
	),
	array(
		'from' => 1224957600,
		'to' => 1238263199,
		'offset' => 32400,
		'dst' => true
	),
	array(
		'from' => 1238263200,
		'to' => 2147483647,
		'offset' => 28800,
		'dst' => false
	)
);
