<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 57686399,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 57686400,
		'to' => 67967999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 67968000,
		'to' => 625593599,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 625593600,
		'to' => 636479999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 636480000,
		'to' => 657043199,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 657043200,
		'to' => 667929599,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 667929600,
		'to' => 688492799,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 688492800,
		'to' => 699379199,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 699379200,
		'to' => 709912799,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 709912800,
		'to' => 719942399,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 719942400,
		'to' => 731433599,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 731433600,
		'to' => 751996799,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 751996800,
		'to' => 762883199,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 762883200,
		'to' => 2147483647,
		'offset' => 36000,
		'dst' => false
	)
);
