<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 57686399,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 57686400,
		'to' => 67967999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 67968000,
		'to' => 89135999,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 89136000,
		'to' => 100022399,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 100022400,
		'to' => 120585599,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 120585600,
		'to' => 131471999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 131472000,
		'to' => 152035199,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 152035200,
		'to' => 162921599,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 162921600,
		'to' => 183484799,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 183484800,
		'to' => 194975999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 194976000,
		'to' => 215539199,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 215539200,
		'to' => 226425599,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 226425600,
		'to' => 246988799,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 246988800,
		'to' => 257875199,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 257875200,
		'to' => 278438399,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 278438400,
		'to' => 289324799,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 289324800,
		'to' => 309887999,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 309888000,
		'to' => 320774399,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 320774400,
		'to' => 341337599,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 341337600,
		'to' => 352223999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 352224000,
		'to' => 372787199,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 372787200,
		'to' => 384278399,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 384278400,
		'to' => 404841599,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 404841600,
		'to' => 415727999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 415728000,
		'to' => 436291199,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 436291200,
		'to' => 447177599,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 447177600,
		'to' => 467740799,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 467740800,
		'to' => 478627199,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 478627200,
		'to' => 499190399,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 499190400,
		'to' => 511286399,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 511286400,
		'to' => 530035199,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 530035200,
		'to' => 542735999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 542736000,
		'to' => 561484799,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 561484800,
		'to' => 574790399,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 574790400,
		'to' => 594143999,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 594144000,
		'to' => 606239999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 606240000,
		'to' => 625593599,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 625593600,
		'to' => 637689599,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 637689600,
		'to' => 657043199,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 657043200,
		'to' => 667929599,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 667929600,
		'to' => 688492799,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 688492800,
		'to' => 699379199,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 699379200,
		'to' => 719942399,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 719942400,
		'to' => 731433599,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 731433600,
		'to' => 751996799,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 751996800,
		'to' => 762883199,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 762883200,
		'to' => 783446399,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 783446400,
		'to' => 796147199,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 796147200,
		'to' => 814895999,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 814896000,
		'to' => 828201599,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 828201600,
		'to' => 846345599,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 846345600,
		'to' => 859651199,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 859651200,
		'to' => 877795199,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 877795200,
		'to' => 891100799,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 891100800,
		'to' => 909244799,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 909244800,
		'to' => 922550399,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 922550400,
		'to' => 941299199,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 941299200,
		'to' => 953999999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 954000000,
		'to' => 967305599,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 967305600,
		'to' => 985449599,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 985449600,
		'to' => 1004198399,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1004198400,
		'to' => 1017503999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1017504000,
		'to' => 1035647999,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1035648000,
		'to' => 1048953599,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1048953600,
		'to' => 1067097599,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1067097600,
		'to' => 1080403199,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1080403200,
		'to' => 1099151999,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1099152000,
		'to' => 1111852799,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1111852800,
		'to' => 1130601599,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1130601600,
		'to' => 1143907199,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1143907200,
		'to' => 1162051199,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1162051200,
		'to' => 1174751999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1174752000,
		'to' => 1193500799,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1193500800,
		'to' => 1207411199,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1207411200,
		'to' => 1223135999,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1223136000,
		'to' => 1238860799,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1238860800,
		'to' => 1254585599,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1254585600,
		'to' => 1270310399,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1270310400,
		'to' => 1286035199,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1286035200,
		'to' => 1301759999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1301760000,
		'to' => 1317484799,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1317484800,
		'to' => 1333209599,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1333209600,
		'to' => 1349539199,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1349539200,
		'to' => 1365263999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1365264000,
		'to' => 1380988799,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1380988800,
		'to' => 1396713599,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1396713600,
		'to' => 1412438399,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1412438400,
		'to' => 1428163199,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1428163200,
		'to' => 1443887999,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1443888000,
		'to' => 1459612799,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1459612800,
		'to' => 1475337599,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1475337600,
		'to' => 1491062399,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1491062400,
		'to' => 1506787199,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1506787200,
		'to' => 1522511999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1522512000,
		'to' => 1538841599,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1538841600,
		'to' => 1554566399,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1554566400,
		'to' => 1570291199,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1570291200,
		'to' => 1586015999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1586016000,
		'to' => 1601740799,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1601740800,
		'to' => 1617465599,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1617465600,
		'to' => 1633190399,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1633190400,
		'to' => 1648915199,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1648915200,
		'to' => 1664639999,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1664640000,
		'to' => 1680364799,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1680364800,
		'to' => 1696089599,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1696089600,
		'to' => 1712419199,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1712419200,
		'to' => 1728143999,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1728144000,
		'to' => 1743868799,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1743868800,
		'to' => 1759593599,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1759593600,
		'to' => 1775318399,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1775318400,
		'to' => 1791043199,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1791043200,
		'to' => 1806767999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1806768000,
		'to' => 1822492799,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1822492800,
		'to' => 1838217599,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1838217600,
		'to' => 1853942399,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1853942400,
		'to' => 1869667199,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1869667200,
		'to' => 1885996799,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1885996800,
		'to' => 1901721599,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1901721600,
		'to' => 1917446399,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1917446400,
		'to' => 1933171199,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1933171200,
		'to' => 1948895999,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1948896000,
		'to' => 1964620799,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1964620800,
		'to' => 1980345599,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 1980345600,
		'to' => 1996070399,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 1996070400,
		'to' => 2011795199,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 2011795200,
		'to' => 2027519999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 2027520000,
		'to' => 2043244799,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 2043244800,
		'to' => 2058969599,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 2058969600,
		'to' => 2075299199,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 2075299200,
		'to' => 2091023999,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 2091024000,
		'to' => 2106748799,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 2106748800,
		'to' => 2122473599,
		'offset' => 39600,
		'dst' => true
	),
	array(
		'from' => 2122473600,
		'to' => 2138198399,
		'offset' => 36000,
		'dst' => false
	),
	array(
		'from' => 2138198400,
		'to' => 2147483647,
		'offset' => 39600,
		'dst' => true
	)
);
