<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 57688199,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 57688200,
		'to' => 67969799,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 67969800,
		'to' => 89137799,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 89137800,
		'to' => 100024199,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 100024200,
		'to' => 120587399,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 120587400,
		'to' => 131473799,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 131473800,
		'to' => 152036999,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 152037000,
		'to' => 162923399,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 162923400,
		'to' => 183486599,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 183486600,
		'to' => 194977799,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 194977800,
		'to' => 215540999,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 215541000,
		'to' => 226427399,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 226427400,
		'to' => 246990599,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 246990600,
		'to' => 257876999,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 257877000,
		'to' => 278440199,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 278440200,
		'to' => 289326599,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 289326600,
		'to' => 309889799,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 309889800,
		'to' => 320776199,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 320776200,
		'to' => 341339399,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 341339400,
		'to' => 352225799,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 352225800,
		'to' => 372788999,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 372789000,
		'to' => 384280199,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 384280200,
		'to' => 404843399,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 404843400,
		'to' => 415729799,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 415729800,
		'to' => 436292999,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 436293000,
		'to' => 447179399,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 447179400,
		'to' => 467742599,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 467742600,
		'to' => 478628999,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 478629000,
		'to' => 499192199,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 499192200,
		'to' => 511288199,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 511288200,
		'to' => 530036999,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 530037000,
		'to' => 542737799,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 542737800,
		'to' => 562091399,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 562091400,
		'to' => 574792199,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 574792200,
		'to' => 594145799,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 594145800,
		'to' => 606241799,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 606241800,
		'to' => 625595399,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 625595400,
		'to' => 637691399,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 637691400,
		'to' => 657044999,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 657045000,
		'to' => 667931399,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 667931400,
		'to' => 688494599,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 688494600,
		'to' => 701195399,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 701195400,
		'to' => 719944199,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 719944200,
		'to' => 731435399,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 731435400,
		'to' => 751998599,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 751998600,
		'to' => 764094599,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 764094600,
		'to' => 783448199,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 783448200,
		'to' => 796148999,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 796149000,
		'to' => 814897799,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 814897800,
		'to' => 828203399,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 828203400,
		'to' => 846347399,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 846347400,
		'to' => 859652999,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 859653000,
		'to' => 877796999,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 877797000,
		'to' => 891102599,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 891102600,
		'to' => 909246599,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 909246600,
		'to' => 922552199,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 922552200,
		'to' => 941300999,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 941301000,
		'to' => 954001799,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 954001800,
		'to' => 972750599,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 972750600,
		'to' => 985451399,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 985451400,
		'to' => 1004200199,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 1004200200,
		'to' => 1017505799,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 1017505800,
		'to' => 1035649799,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 1035649800,
		'to' => 1048955399,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 1048955400,
		'to' => 1067099399,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 1067099400,
		'to' => 1080404999,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 1080405000,
		'to' => 1099153799,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 1099153800,
		'to' => 1111854599,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 1111854600,
		'to' => 1130603399,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 1130603400,
		'to' => 1143908999,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 1143909000,
		'to' => 1162052999,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 1162053000,
		'to' => 1174753799,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 1174753800,
		'to' => 1193502599,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 1193502600,
		'to' => 1207412999,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 1207413000,
		'to' => 1223137799,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 1223137800,
		'to' => 1238862599,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 1238862600,
		'to' => 1254587399,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 1254587400,
		'to' => 1270312199,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 1270312200,
		'to' => 1286036999,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 1286037000,
		'to' => 1301761799,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 1301761800,
		'to' => 1317486599,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 1317486600,
		'to' => 1333211399,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 1333211400,
		'to' => 1349540999,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 1349541000,
		'to' => 1365265799,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 1365265800,
		'to' => 1380990599,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 1380990600,
		'to' => 1396715399,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 1396715400,
		'to' => 1412440199,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 1412440200,
		'to' => 1428164999,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 1428165000,
		'to' => 1443889799,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 1443889800,
		'to' => 1459614599,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 1459614600,
		'to' => 1475339399,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 1475339400,
		'to' => 1491064199,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 1491064200,
		'to' => 1506788999,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 1506789000,
		'to' => 1522513799,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 1522513800,
		'to' => 1538843399,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 1538843400,
		'to' => 1554568199,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 1554568200,
		'to' => 1570292999,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 1570293000,
		'to' => 1586017799,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 1586017800,
		'to' => 1601742599,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 1601742600,
		'to' => 1617467399,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 1617467400,
		'to' => 1633192199,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 1633192200,
		'to' => 1648916999,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 1648917000,
		'to' => 1664641799,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 1664641800,
		'to' => 1680366599,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 1680366600,
		'to' => 1696091399,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 1696091400,
		'to' => 1712420999,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 1712421000,
		'to' => 1728145799,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 1728145800,
		'to' => 1743870599,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 1743870600,
		'to' => 1759595399,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 1759595400,
		'to' => 1775320199,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 1775320200,
		'to' => 1791044999,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 1791045000,
		'to' => 1806769799,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 1806769800,
		'to' => 1822494599,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 1822494600,
		'to' => 1838219399,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 1838219400,
		'to' => 1853944199,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 1853944200,
		'to' => 1869668999,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 1869669000,
		'to' => 1885998599,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 1885998600,
		'to' => 1901723399,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 1901723400,
		'to' => 1917448199,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 1917448200,
		'to' => 1933172999,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 1933173000,
		'to' => 1948897799,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 1948897800,
		'to' => 1964622599,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 1964622600,
		'to' => 1980347399,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 1980347400,
		'to' => 1996072199,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 1996072200,
		'to' => 2011796999,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 2011797000,
		'to' => 2027521799,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 2027521800,
		'to' => 2043246599,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 2043246600,
		'to' => 2058971399,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 2058971400,
		'to' => 2075300999,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 2075301000,
		'to' => 2091025799,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 2091025800,
		'to' => 2106750599,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 2106750600,
		'to' => 2122475399,
		'offset' => 37800,
		'dst' => true
	),
	array(
		'from' => 2122475400,
		'to' => 2138200199,
		'offset' => 34200,
		'dst' => false
	),
	array(
		'from' => 2138200200,
		'to' => 2147483647,
		'offset' => 37800,
		'dst' => true
	)
);
