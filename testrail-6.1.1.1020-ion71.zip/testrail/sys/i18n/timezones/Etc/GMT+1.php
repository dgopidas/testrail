<?php if (!defined('ROOTPATH')) exit('No direct script access allowed'); ?>
<?php
$transitions = array(
	array(
		'from' => 0,
		'to' => 2147483647,
		'offset' => -3600,
		'dst' => false
	)
);
